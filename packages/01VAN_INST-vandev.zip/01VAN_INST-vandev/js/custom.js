(function(){
"use strict";
"use strict";

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

(function () {
  "use strict";
  "use strict";

  var app = angular.module('viewCustom', ['angularLoad', 'customActions']);

  /** Start JWT work **/

  app.controller('prmSearchBarAfterController', ['$location', function ($location) {
    var userSessionManagerService = this.parentCtrl.$scope.$root.$$childHead.$ctrl.userSessionManagerService;
    var result = userSessionManagerService.jwtUtilService.jwtHelper.decodeToken(userSessionManagerService.getJwt());
    console.log(result);
  }]);

  app.component('prmOpacAfter', {
    bindings: { parentCtrl: '<' },
    controller: 'prmSearchBarAfterController',
    template: '<span> hello </span>'
  });

  /** End JWT work **/

  /** Show development environment **/

  /**
  app.component('prmSearchBarAfter', {
    bindings: {},
    template: '<div class="hello-world"><span>Development Environment</span></div>'
  }});
  **/

  /** End show development environment **/

  /** Browzine Logo **/

  app.component('prmAtozSearchBarAfter', {
    bindings: {
      parentCtrl: '<'
    },
    template: '<div tabindex="-1" role="search" layout="row" class="layout-row"><div id="browzinelogo"> <a href="http://browzine.com.proxy.library.vanderbilt.edu/libraries/519/subjects" class="md-primoExplore-theme" ><img src="https://apps.library.vanderbilt.edu/images/browzinetop.png" width="141px" height="50px" target="_new"></a></div></div>'
  });

  /** End Browzine Logo **/
  /** Working with the image **/

  app.component('prmLogoAfter', {
    bindings: {
      parentCtrl: '<'
    },
    template: '<a href="https://www.library.vanderbilt.edu" class="md-primoExplore-theme" ><div class="product-logo-local"  id="banner" aria-label="Library home page">  </div></a>'
  });

  /** End image work **/

  /** Start Custom SMS **/

  /**  SMS form **/

  app.component('prmActionListAfter', {
    bindings: { parentCtrl: '<' },
    controller: 'FormServiceController',
    template: "<custom-action name=\"text_me\"\n                            label=\"Text Me\"\n                            index=0\n                            icon=\"ic_smartphone_24px\"\n                            icon-set=\"hardware\"\n                            link=\"https://library2018.library.vanderbilt.edu/forms/textme.php?call={{$ctrl.callNumber}}&location={{$ctrl.localCode}}&title={pnx.display.title}\" />"
  });

  /** End Custom SMS **/

  /** Local Source record **/
  app.component('prmServiceDetailsAfter', {
    bindings: { parentCtrl: '<' },
    controller: 'FormServiceController',
    template: '<hr/><span> <a href=\"https://apps.library.vanderbilt.edu/services/source/rec.php?akey={{$ctrl.recordid}}" target=_new> View Source Record </a></span>'
  });
  /** End Local Source record **/

  /** basic form **/
  /**
  app.component('prmRequestServicesAfter',{
  	**/

  /**
  	app.component('prmLocationItemAfter',{
      bindings: {parentCtrl: '<'},
      controller: 'FormServiceController',
  	template: ' <span class="formbutton"> \
  	<form ng-if="$ctrl.localCode === \'ANNEX\'"  method="post" action="https://www.library.vanderbilt.edu/forms/custannex.php" target="_blank"> \
  	<input type="hidden" name="lang" value="en_US">\
      <input type="hidden" value="{{$ctrl.title}}" name="title">\
      <input type="hidden" value="{{$ctrl.localName}}" name="location">\
      <input type="hidden" value="{{$ctrl.callNumber}}" name="call"> \
  	<input type="submit" name="submit" class="formbutton" value="Request from Annex"> </form> \
  	<form ng-if="$ctrl.localCode === \'SPEC-COLL\'"  method="post" action="https://www.library.vanderbilt.edu/forms/archives.php" target="_blank"> \
  	<input type="hidden" name="lang" value="en_US">\
      <input type="hidden" value="{{$ctrl.title}}" name="title">\
      <input type="hidden" value="{{$ctrl.localName}}" name="location">\
      <input type="hidden" value="{{$ctrl.callNumber}}" name="call"> \
  	<input type="submit" name="submit"  class="formbutton" value="Request for Use in the Reading Room"> </form> \
  	<form ng-if="$ctrl.localCode === \'21NORTH\'"  method="post" action="https://www.library.vanderbilt.edu/forms/archives.php" target="_blank"> \
  	<input type="hidden" name="lang" value="en_US">\
      <input type="hidden" value="{{$ctrl.title}}" name="title">\
      <input type="hidden" value="{{$ctrl.localName}}" name="location">\
      <input type="hidden" value="{{$ctrl.callNumber}}" name="call"> \
  	<input type="submit" name="submit" class="formbutton" value="Request for Use in the Reading Room"> </form> </span> \
  	'});
  **/

  app.controller('FormServiceController', [function () {
    var vm = this;
    vm.url = document.location || '';
    var pnx = vm.parentCtrl.item.pnx || false;
    vm.callNumber = vm.parentCtrl.item.delivery.bestlocation.callNumber;
    vm.localName = vm.parentCtrl.item.delivery.bestlocation.mainLocation;
    vm.localCode = vm.parentCtrl.item.delivery.bestlocation.libraryCode;
    vm.format = pnx.display.type[0] || '';
    /** if(vm.format === 'article'){
        vm.source = pnx.display.ispartof[0]+' by '+pnx.addata.au[0];
    } else {
        vm.source = 'Published by '+pnx.addata.pub[0]+' and authored by '+pnx.addata.au[0]+' in '+pnx.addata.date[0];
    }
    **/
    vm.title = pnx.display.title[0] || '';
    vm.url = document.location || '';
    vm.recordid = pnx.control.recordid;

    vm.$onInit = function () {};
  }]);

  /** End basic Form **/

  /** Start Orbis **/

  /**Start custom actions **/

  'use strict';

  angular.module('customActions', []);

  /* eslint-disable max-len */
  angular.module('customActions').component('customAction', {
    bindings: {
      name: '@',
      label: '@',
      icon: '@',
      iconSet: '@',
      link: '@',
      index: '<'
    },
    require: {
      prmActionCtrl: '^prmActionList'
    },
    controller: ['customActions', function (customActions) {
      var _this = this;

      this.$onInit = function () {
        _this.action = {
          name: _this.name,
          label: _this.label,
          index: _this.index,
          icon: {
            icon: _this.icon,
            iconSet: _this.iconSet,
            type: 'svg'
          },
          onToggle: customActions.processLinkTemplate(_this.link, _this.prmActionCtrl.item)
        };
        customActions.addAction(_this.action, _this.prmActionCtrl);
      };
      this.$onDestroy = function () {
        return customActions.removeAction(_this.action, _this.prmActionCtrl);
      };
    }]
  });

  /* eslint-disable max-len */

  angular.module('customActions').factory('customActions', function () {
    return {
      /**
       * Adds an action to the actions menu, including its icon.
       * @param  {object} action  action object
       * @param  {object} ctrl    instance of prmActionCtrl
       */
      // TODO coerce action.index to be <= requiredActionsList.length
      addAction: function addAction(action, ctrl) {
        if (!this.actionExists(action, ctrl)) {
          this.addActionIcon(action, ctrl);
          ctrl.actionListService.requiredActionsList.splice(action.index, 0, action.name);
          ctrl.actionListService.actionsToIndex[action.name] = action.index;
          ctrl.actionListService.onToggle[action.name] = action.onToggle;
          ctrl.actionListService.actionsToDisplay.unshift(action.name);
        }
      },
      /**
       * Removes an action from the actions menu, including its icon.
       * @param  {object} action  action object
       * @param  {object} ctrl    instance of prmActionCtrl
       */
      removeAction: function removeAction(action, ctrl) {
        if (this.actionExists(action, ctrl)) {
          this.removeActionIcon(action, ctrl);
          delete ctrl.actionListService.actionsToIndex[action.name];
          delete ctrl.actionListService.onToggle[action.name];
          var i = ctrl.actionListService.actionsToDisplay.indexOf(action.name);
          ctrl.actionListService.actionsToDisplay.splice(i, 1);
          i = ctrl.actionListService.requiredActionsList.indexOf(action.name);
          ctrl.actionListService.requiredActionsList.splice(i, 1);
        }
      },
      /**
       * Registers an action's icon.
       * Called internally by addAction().
       * @param  {object} action  action object
       * @param  {object} ctrl    instance of prmActionCtrl
       */
      addActionIcon: function addActionIcon(action, ctrl) {
        ctrl.actionLabelNamesMap[action.name] = action.label;
        ctrl.actionIconNamesMap[action.name] = action.name;
        ctrl.actionIcons[action.name] = action.icon;
      },
      /**
       * Deregisters an action's icon.
       * Called internally by removeAction().
       * @param  {object} action  action object
       * @param  {object} ctrl    instance of prmActionCtrl
       */
      removeActionIcon: function removeActionIcon(action, ctrl) {
        delete ctrl.actionLabelNamesMap[action.name];
        delete ctrl.actionIconNamesMap[action.name];
        delete ctrl.actionIcons[action.name];
      },
      /**
       * Check if an action exists.
       * Returns true if action is part of actionsToIndex.
       * @param  {object} action  action object
       * @param  {object} ctrl    instance of prmActionCtrl
       * @return {bool}
       */
      actionExists: function actionExists(action, ctrl) {
        return ctrl.actionListService.actionsToIndex.hasOwnProperty(action.name);
      },
      /**
       * Process a link into a function to call when the action is clicked.
       * The function will open the processed link in a new tab.
       * Will replace {pnx.xxx.xxx} expressions with properties from the item.
       * @param  {string}    link    the original link string from the html
       * @param  {object}    item    the item object obtained from the controller
       * @return {function}          function to call when the action is clicked
       */
      processLinkTemplate: function processLinkTemplate(link, item) {
        var processedLink = link;
        var pnxProperties = link.match(/\{(pnx\..*?)\}/g) || [];
        pnxProperties.forEach(function (property) {
          var value = property.replace(/[{}]/g, '').split('.').reduce(function (o, i) {
            try {
              var h = /(.*)(\[\d\])/.exec(i);
              if (h instanceof Array) {
                return o[h[1]][h[2].replace(/[^\d]/g, '')];
              }
              return o[i];
            } catch (e) {
              return '';
            }
          }, item);
          processedLink = processedLink.replace(property, value);
        });

        return function () {
          return window.open(processedLink, '_blank');
        };
      }
    };
  });

  /** End custom actions **/

  /** End Orbis **/

  /** Start Altmetrics **/
  /** Altmetrics **/
  app.controller('FullViewAfterController', ['angularLoad', '$http', '$scope', '$element', '$timeout', '$window', function (angularLoad, $http, $scope, $element, $timeout, $window) {
    var vm = this;
    this.$http = $http;
    this.$element = $element;
    this.$scope = $scope;
    this.$window = $window;

    vm.$onInit = function () //wait for all the bindings to be initialised
    {

      vm.parentElement = this.$element.parent()[0]; //the prm-full-view container

      try {
        vm.doi = vm.parentCtrl.item.pnx.addata.doi[0] || '';
      } catch (e) {
        return;
      }

      if (vm.doi) {
        //If we've got a doi to work with check whether altmetrics has data for it.
        //If so, make our div visible and create a new Altmetrics service
        $timeout(function () {
          $http.get('https://api.altmetric.com/v1/doi/' + vm.doi).then(function () {
            try {
              //Get the altmetrics widget
              angularLoad.loadScript('https://d1bxh8uas1mnw7.cloudfront.net/assets/embed.js?' + Date.now()).then(function () {});
              //Create our new Primo service
              var altmetricsSection = {
                scrollId: "altmetrics",
                serviceName: "altmetrics",
                title: "brief.results.tabs.Altmetrics"
              };
              vm.parentCtrl.services.splice(vm.parentCtrl.services.length, 0, altmetricsSection);
            } catch (e) {
              console.log(e);
            }
          }).catch(function (e) {
            return;
          });
        }, 3000);
      }

      //move the altmetrics widget into the new Altmetrics service section
      var unbindWatcher = this.$scope.$watch(function () {
        return vm.parentElement.querySelector('h4[translate="brief.results.tabs.Altmetrics"]');
      }, function (newVal, oldVal) {
        if (newVal) {
          //Get the section body associated with the value we're watching
          var altContainer = newVal.parentElement.parentElement.parentElement.parentElement.children[1];
          var almt1 = vm.parentElement.children[1].children[0];
          if (altContainer && altContainer.appendChild && altm1) {
            altContainer.appendChild(altm1);
          }
          unbindWatcher();
        }
      });
    }; // end of $onInit


    //You'd also need to look at removing the various css/js scripts loaded by this.
    //refer to: https://github.com/Det-Kongelige-Bibliotek/primo-explore-rex
    vm.$onDestroy = function () {
      if (this.$window._altmetric) {
        delete this.$window._altmetric;
      }

      if (this.$window._altmetric_embed_init) {
        delete this.$window._altmetric_embed_init;
      }

      if (this.$window.AltmetricTemplates) {
        delete this.$window.AltmetricTemplates;
      }
    };
  }]);

  app.component('prmFullViewAfter', {
    bindings: { parentCtrl: '<' },
    controller: 'FullViewAfterController',
    template: '<div id="altm1" ng-if="$ctrl.doi" class="altmetric-embed" data-hide-no-mentions="true"  data-link-target="new" data-badge-type="medium-donut" data-badge-details="right" data-doi="{{$ctrl.doi}}"></div>'
  });
  /** Altmetrics **/

  /** End Altmetrics **/

  /** Start Browzine **/

  /** Start Browzine **/
  window.browzine = {
    api: "https://public-api.thirdiron.com/public/v1/libraries/519",
    apiKey: "a38db48a-1772-44f3-b8e3-df9f826cf881",
    primoJournalBrowZineWebLinkText: "Browse Journal Contents",
    primoArticleBrowZineWebLinkText: "Browse Issue Contents"
  };

  browzine.script = document.createElement("script");
  browzine.script.src = "https://s3.amazonaws.com/browzine-adapters/primo/browzine-primo-adapter.js";
  document.head.appendChild(browzine.script);

  app.controller('prmSearchResultAvailabilityLineAfterController', function ($scope) {
    window.browzine.primo.searchResult($scope);
  });

  app.component('prmSearchResultAvailabilityLineAfter', {
    bindings: { parentCtrl: '<' },
    controller: 'prmSearchResultAvailabilityLineAfterController'
  });

  /** End Browzine **/
  /** End Browzine **/

  /** Start Libchat (based Laura Guy's solution) **/

  /** 
   angular
    .module('chat', ['angularLoad'])
    .component('addChat', {
        controller: ['angularLoad', function (angularLoad) {
            this.$onInit = function () {
              angularLoad.loadScript('https://v2.libanswers.com/load_chat.php?hash=c58be3a8ecd194602bebd50fcfe6d49b')
            }
        }]
    })
   **/

  (function () {

    var lc = document.createElement('script');lc.type = 'text/javascript';lc.async = 'true';
    lc.src = 'https://v2.libanswers.com/load_chat.php?hash=c58be3a8ecd194602bebd50fcfe6d49b';
    var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(lc, s);
  })();

  /** Ask a librarian only **/
  /**
  
  (function() {
  
  var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = 'true';
     lc.src =  'https://api2.libanswers.com/1.0/widgets/8299';
     var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);
     })();
  **/
  /** End ask a librarian only**/

  /** End Libchat **/

  /** Close function from line 1 **/
})();
(function e(t, n, r) {
  function s(o, u) {
    if (!n[o]) {
      if (!t[o]) {
        var a = typeof require == "function" && require;if (!u && a) return a(o, !0);if (i) return i(o, !0);var f = new Error("Cannot find module '" + o + "'");throw f.code = "MODULE_NOT_FOUND", f;
      }var l = n[o] = { exports: {} };t[o][0].call(l.exports, function (e) {
        var n = t[o][1][e];return s(n ? n : e);
      }, l, l.exports, e, t, n, r);
    }return n[o].exports;
  }var i = typeof require == "function" && require;for (var o = 0; o < r.length; o++) {
    s(r[o]);
  }return s;
})({ 1: [function (require, module, exports) {
    (function (global) {
      "use strict";

      require("core-js/shim");

      require("regenerator-runtime/runtime");

      require("core-js/fn/regexp/escape");

      if (global._babelPolyfill) {
        throw new Error("only one instance of babel-polyfill is allowed");
      }
      global._babelPolyfill = true;

      var DEFINE_PROPERTY = "defineProperty";
      function define(O, key, value) {
        O[key] || Object[DEFINE_PROPERTY](O, key, {
          writable: true,
          configurable: true,
          value: value
        });
      }

      define(String.prototype, "padLeft", "".padStart);
      define(String.prototype, "padRight", "".padEnd);

      "pop,reverse,shift,keys,values,entries,indexOf,every,some,forEach,map,filter,find,findIndex,includes,join,slice,concat,push,splice,unshift,sort,lastIndexOf,reduce,reduceRight,copyWithin,fill".split(",").forEach(function (key) {
        [][key] && define(Array, key, Function.call.bind([][key]));
      });
    }).call(this, typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {});
  }, { "core-js/fn/regexp/escape": 2, "core-js/shim": 295, "regenerator-runtime/runtime": 296 }], 2: [function (require, module, exports) {
    require('../../modules/core.regexp.escape');
    module.exports = require('../../modules/_core').RegExp.escape;
  }, { "../../modules/_core": 23, "../../modules/core.regexp.escape": 119 }], 3: [function (require, module, exports) {
    module.exports = function (it) {
      if (typeof it != 'function') throw TypeError(it + ' is not a function!');
      return it;
    };
  }, {}], 4: [function (require, module, exports) {
    var cof = require('./_cof');
    module.exports = function (it, msg) {
      if (typeof it != 'number' && cof(it) != 'Number') throw TypeError(msg);
      return +it;
    };
  }, { "./_cof": 18 }], 5: [function (require, module, exports) {
    // 22.1.3.31 Array.prototype[@@unscopables]
    var UNSCOPABLES = require('./_wks')('unscopables'),
        ArrayProto = Array.prototype;
    if (ArrayProto[UNSCOPABLES] == undefined) require('./_hide')(ArrayProto, UNSCOPABLES, {});
    module.exports = function (key) {
      ArrayProto[UNSCOPABLES][key] = true;
    };
  }, { "./_hide": 40, "./_wks": 117 }], 6: [function (require, module, exports) {
    module.exports = function (it, Constructor, name, forbiddenField) {
      if (!(it instanceof Constructor) || forbiddenField !== undefined && forbiddenField in it) {
        throw TypeError(name + ': incorrect invocation!');
      }return it;
    };
  }, {}], 7: [function (require, module, exports) {
    var isObject = require('./_is-object');
    module.exports = function (it) {
      if (!isObject(it)) throw TypeError(it + ' is not an object!');
      return it;
    };
  }, { "./_is-object": 49 }], 8: [function (require, module, exports) {
    // 22.1.3.3 Array.prototype.copyWithin(target, start, end = this.length)
    'use strict';

    var toObject = require('./_to-object'),
        toIndex = require('./_to-index'),
        toLength = require('./_to-length');

    module.exports = [].copyWithin || function copyWithin(target /*= 0*/, start /*= 0, end = @length*/) {
      var O = toObject(this),
          len = toLength(O.length),
          to = toIndex(target, len),
          from = toIndex(start, len),
          end = arguments.length > 2 ? arguments[2] : undefined,
          count = Math.min((end === undefined ? len : toIndex(end, len)) - from, len - to),
          inc = 1;
      if (from < to && to < from + count) {
        inc = -1;
        from += count - 1;
        to += count - 1;
      }
      while (count-- > 0) {
        if (from in O) O[to] = O[from];else delete O[to];
        to += inc;
        from += inc;
      }return O;
    };
  }, { "./_to-index": 105, "./_to-length": 108, "./_to-object": 109 }], 9: [function (require, module, exports) {
    // 22.1.3.6 Array.prototype.fill(value, start = 0, end = this.length)
    'use strict';

    var toObject = require('./_to-object'),
        toIndex = require('./_to-index'),
        toLength = require('./_to-length');
    module.exports = function fill(value /*, start = 0, end = @length */) {
      var O = toObject(this),
          length = toLength(O.length),
          aLen = arguments.length,
          index = toIndex(aLen > 1 ? arguments[1] : undefined, length),
          end = aLen > 2 ? arguments[2] : undefined,
          endPos = end === undefined ? length : toIndex(end, length);
      while (endPos > index) {
        O[index++] = value;
      }return O;
    };
  }, { "./_to-index": 105, "./_to-length": 108, "./_to-object": 109 }], 10: [function (require, module, exports) {
    var forOf = require('./_for-of');

    module.exports = function (iter, ITERATOR) {
      var result = [];
      forOf(iter, false, result.push, result, ITERATOR);
      return result;
    };
  }, { "./_for-of": 37 }], 11: [function (require, module, exports) {
    // false -> Array#indexOf
    // true  -> Array#includes
    var toIObject = require('./_to-iobject'),
        toLength = require('./_to-length'),
        toIndex = require('./_to-index');
    module.exports = function (IS_INCLUDES) {
      return function ($this, el, fromIndex) {
        var O = toIObject($this),
            length = toLength(O.length),
            index = toIndex(fromIndex, length),
            value;
        // Array#includes uses SameValueZero equality algorithm
        if (IS_INCLUDES && el != el) while (length > index) {
          value = O[index++];
          if (value != value) return true;
          // Array#toIndex ignores holes, Array#includes - not
        } else for (; length > index; index++) {
          if (IS_INCLUDES || index in O) {
            if (O[index] === el) return IS_INCLUDES || index || 0;
          }
        }return !IS_INCLUDES && -1;
      };
    };
  }, { "./_to-index": 105, "./_to-iobject": 107, "./_to-length": 108 }], 12: [function (require, module, exports) {
    // 0 -> Array#forEach
    // 1 -> Array#map
    // 2 -> Array#filter
    // 3 -> Array#some
    // 4 -> Array#every
    // 5 -> Array#find
    // 6 -> Array#findIndex
    var ctx = require('./_ctx'),
        IObject = require('./_iobject'),
        toObject = require('./_to-object'),
        toLength = require('./_to-length'),
        asc = require('./_array-species-create');
    module.exports = function (TYPE, $create) {
      var IS_MAP = TYPE == 1,
          IS_FILTER = TYPE == 2,
          IS_SOME = TYPE == 3,
          IS_EVERY = TYPE == 4,
          IS_FIND_INDEX = TYPE == 6,
          NO_HOLES = TYPE == 5 || IS_FIND_INDEX,
          create = $create || asc;
      return function ($this, callbackfn, that) {
        var O = toObject($this),
            self = IObject(O),
            f = ctx(callbackfn, that, 3),
            length = toLength(self.length),
            index = 0,
            result = IS_MAP ? create($this, length) : IS_FILTER ? create($this, 0) : undefined,
            val,
            res;
        for (; length > index; index++) {
          if (NO_HOLES || index in self) {
            val = self[index];
            res = f(val, index, O);
            if (TYPE) {
              if (IS_MAP) result[index] = res; // map
              else if (res) switch (TYPE) {
                  case 3:
                    return true; // some
                  case 5:
                    return val; // find
                  case 6:
                    return index; // findIndex
                  case 2:
                    result.push(val); // filter
                } else if (IS_EVERY) return false; // every
            }
          }
        }return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : result;
      };
    };
  }, { "./_array-species-create": 15, "./_ctx": 25, "./_iobject": 45, "./_to-length": 108, "./_to-object": 109 }], 13: [function (require, module, exports) {
    var aFunction = require('./_a-function'),
        toObject = require('./_to-object'),
        IObject = require('./_iobject'),
        toLength = require('./_to-length');

    module.exports = function (that, callbackfn, aLen, memo, isRight) {
      aFunction(callbackfn);
      var O = toObject(that),
          self = IObject(O),
          length = toLength(O.length),
          index = isRight ? length - 1 : 0,
          i = isRight ? -1 : 1;
      if (aLen < 2) for (;;) {
        if (index in self) {
          memo = self[index];
          index += i;
          break;
        }
        index += i;
        if (isRight ? index < 0 : length <= index) {
          throw TypeError('Reduce of empty array with no initial value');
        }
      }
      for (; isRight ? index >= 0 : length > index; index += i) {
        if (index in self) {
          memo = callbackfn(memo, self[index], index, O);
        }
      }return memo;
    };
  }, { "./_a-function": 3, "./_iobject": 45, "./_to-length": 108, "./_to-object": 109 }], 14: [function (require, module, exports) {
    var isObject = require('./_is-object'),
        isArray = require('./_is-array'),
        SPECIES = require('./_wks')('species');

    module.exports = function (original) {
      var C;
      if (isArray(original)) {
        C = original.constructor;
        // cross-realm fallback
        if (typeof C == 'function' && (C === Array || isArray(C.prototype))) C = undefined;
        if (isObject(C)) {
          C = C[SPECIES];
          if (C === null) C = undefined;
        }
      }return C === undefined ? Array : C;
    };
  }, { "./_is-array": 47, "./_is-object": 49, "./_wks": 117 }], 15: [function (require, module, exports) {
    // 9.4.2.3 ArraySpeciesCreate(originalArray, length)
    var speciesConstructor = require('./_array-species-constructor');

    module.exports = function (original, length) {
      return new (speciesConstructor(original))(length);
    };
  }, { "./_array-species-constructor": 14 }], 16: [function (require, module, exports) {
    'use strict';

    var aFunction = require('./_a-function'),
        isObject = require('./_is-object'),
        invoke = require('./_invoke'),
        arraySlice = [].slice,
        factories = {};

    var construct = function construct(F, len, args) {
      if (!(len in factories)) {
        for (var n = [], i = 0; i < len; i++) {
          n[i] = 'a[' + i + ']';
        }factories[len] = Function('F,a', 'return new F(' + n.join(',') + ')');
      }return factories[len](F, args);
    };

    module.exports = Function.bind || function bind(that /*, args... */) {
      var fn = aFunction(this),
          partArgs = arraySlice.call(arguments, 1);
      var bound = function bound() /* args... */{
        var args = partArgs.concat(arraySlice.call(arguments));
        return this instanceof bound ? construct(fn, args.length, args) : invoke(fn, args, that);
      };
      if (isObject(fn.prototype)) bound.prototype = fn.prototype;
      return bound;
    };
  }, { "./_a-function": 3, "./_invoke": 44, "./_is-object": 49 }], 17: [function (require, module, exports) {
    // getting tag from 19.1.3.6 Object.prototype.toString()
    var cof = require('./_cof'),
        TAG = require('./_wks')('toStringTag')
    // ES3 wrong here
    ,
        ARG = cof(function () {
      return arguments;
    }()) == 'Arguments';

    // fallback for IE11 Script Access Denied error
    var tryGet = function tryGet(it, key) {
      try {
        return it[key];
      } catch (e) {/* empty */}
    };

    module.exports = function (it) {
      var O, T, B;
      return it === undefined ? 'Undefined' : it === null ? 'Null'
      // @@toStringTag case
      : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
      // builtinTag case
      : ARG ? cof(O)
      // ES3 arguments fallback
      : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
    };
  }, { "./_cof": 18, "./_wks": 117 }], 18: [function (require, module, exports) {
    var toString = {}.toString;

    module.exports = function (it) {
      return toString.call(it).slice(8, -1);
    };
  }, {}], 19: [function (require, module, exports) {
    'use strict';

    var dP = require('./_object-dp').f,
        create = require('./_object-create'),
        redefineAll = require('./_redefine-all'),
        ctx = require('./_ctx'),
        anInstance = require('./_an-instance'),
        defined = require('./_defined'),
        forOf = require('./_for-of'),
        $iterDefine = require('./_iter-define'),
        step = require('./_iter-step'),
        setSpecies = require('./_set-species'),
        DESCRIPTORS = require('./_descriptors'),
        fastKey = require('./_meta').fastKey,
        SIZE = DESCRIPTORS ? '_s' : 'size';

    var getEntry = function getEntry(that, key) {
      // fast case
      var index = fastKey(key),
          entry;
      if (index !== 'F') return that._i[index];
      // frozen object case
      for (entry = that._f; entry; entry = entry.n) {
        if (entry.k == key) return entry;
      }
    };

    module.exports = {
      getConstructor: function getConstructor(wrapper, NAME, IS_MAP, ADDER) {
        var C = wrapper(function (that, iterable) {
          anInstance(that, C, NAME, '_i');
          that._i = create(null); // index
          that._f = undefined; // first entry
          that._l = undefined; // last entry
          that[SIZE] = 0; // size
          if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
        });
        redefineAll(C.prototype, {
          // 23.1.3.1 Map.prototype.clear()
          // 23.2.3.2 Set.prototype.clear()
          clear: function clear() {
            for (var that = this, data = that._i, entry = that._f; entry; entry = entry.n) {
              entry.r = true;
              if (entry.p) entry.p = entry.p.n = undefined;
              delete data[entry.i];
            }
            that._f = that._l = undefined;
            that[SIZE] = 0;
          },
          // 23.1.3.3 Map.prototype.delete(key)
          // 23.2.3.4 Set.prototype.delete(value)
          'delete': function _delete(key) {
            var that = this,
                entry = getEntry(that, key);
            if (entry) {
              var next = entry.n,
                  prev = entry.p;
              delete that._i[entry.i];
              entry.r = true;
              if (prev) prev.n = next;
              if (next) next.p = prev;
              if (that._f == entry) that._f = next;
              if (that._l == entry) that._l = prev;
              that[SIZE]--;
            }return !!entry;
          },
          // 23.2.3.6 Set.prototype.forEach(callbackfn, thisArg = undefined)
          // 23.1.3.5 Map.prototype.forEach(callbackfn, thisArg = undefined)
          forEach: function forEach(callbackfn /*, that = undefined */) {
            anInstance(this, C, 'forEach');
            var f = ctx(callbackfn, arguments.length > 1 ? arguments[1] : undefined, 3),
                entry;
            while (entry = entry ? entry.n : this._f) {
              f(entry.v, entry.k, this);
              // revert to the last existing entry
              while (entry && entry.r) {
                entry = entry.p;
              }
            }
          },
          // 23.1.3.7 Map.prototype.has(key)
          // 23.2.3.7 Set.prototype.has(value)
          has: function has(key) {
            return !!getEntry(this, key);
          }
        });
        if (DESCRIPTORS) dP(C.prototype, 'size', {
          get: function get() {
            return defined(this[SIZE]);
          }
        });
        return C;
      },
      def: function def(that, key, value) {
        var entry = getEntry(that, key),
            prev,
            index;
        // change existing entry
        if (entry) {
          entry.v = value;
          // create new entry
        } else {
          that._l = entry = {
            i: index = fastKey(key, true), // <- index
            k: key, // <- key
            v: value, // <- value
            p: prev = that._l, // <- previous entry
            n: undefined, // <- next entry
            r: false // <- removed
          };
          if (!that._f) that._f = entry;
          if (prev) prev.n = entry;
          that[SIZE]++;
          // add to index
          if (index !== 'F') that._i[index] = entry;
        }return that;
      },
      getEntry: getEntry,
      setStrong: function setStrong(C, NAME, IS_MAP) {
        // add .keys, .values, .entries, [@@iterator]
        // 23.1.3.4, 23.1.3.8, 23.1.3.11, 23.1.3.12, 23.2.3.5, 23.2.3.8, 23.2.3.10, 23.2.3.11
        $iterDefine(C, NAME, function (iterated, kind) {
          this._t = iterated; // target
          this._k = kind; // kind
          this._l = undefined; // previous
        }, function () {
          var that = this,
              kind = that._k,
              entry = that._l;
          // revert to the last existing entry
          while (entry && entry.r) {
            entry = entry.p;
          } // get next entry
          if (!that._t || !(that._l = entry = entry ? entry.n : that._t._f)) {
            // or finish the iteration
            that._t = undefined;
            return step(1);
          }
          // return step by kind
          if (kind == 'keys') return step(0, entry.k);
          if (kind == 'values') return step(0, entry.v);
          return step(0, [entry.k, entry.v]);
        }, IS_MAP ? 'entries' : 'values', !IS_MAP, true);

        // add [@@species], 23.1.2.2, 23.2.2.2
        setSpecies(NAME);
      }
    };
  }, { "./_an-instance": 6, "./_ctx": 25, "./_defined": 27, "./_descriptors": 28, "./_for-of": 37, "./_iter-define": 53, "./_iter-step": 55, "./_meta": 62, "./_object-create": 66, "./_object-dp": 67, "./_redefine-all": 86, "./_set-species": 91 }], 20: [function (require, module, exports) {
    // https://github.com/DavidBruant/Map-Set.prototype.toJSON
    var classof = require('./_classof'),
        from = require('./_array-from-iterable');
    module.exports = function (NAME) {
      return function toJSON() {
        if (classof(this) != NAME) throw TypeError(NAME + "#toJSON isn't generic");
        return from(this);
      };
    };
  }, { "./_array-from-iterable": 10, "./_classof": 17 }], 21: [function (require, module, exports) {
    'use strict';

    var redefineAll = require('./_redefine-all'),
        getWeak = require('./_meta').getWeak,
        anObject = require('./_an-object'),
        isObject = require('./_is-object'),
        anInstance = require('./_an-instance'),
        forOf = require('./_for-of'),
        createArrayMethod = require('./_array-methods'),
        $has = require('./_has'),
        arrayFind = createArrayMethod(5),
        arrayFindIndex = createArrayMethod(6),
        id = 0;

    // fallback for uncaught frozen keys
    var uncaughtFrozenStore = function uncaughtFrozenStore(that) {
      return that._l || (that._l = new UncaughtFrozenStore());
    };
    var UncaughtFrozenStore = function UncaughtFrozenStore() {
      this.a = [];
    };
    var findUncaughtFrozen = function findUncaughtFrozen(store, key) {
      return arrayFind(store.a, function (it) {
        return it[0] === key;
      });
    };
    UncaughtFrozenStore.prototype = {
      get: function get(key) {
        var entry = findUncaughtFrozen(this, key);
        if (entry) return entry[1];
      },
      has: function has(key) {
        return !!findUncaughtFrozen(this, key);
      },
      set: function set(key, value) {
        var entry = findUncaughtFrozen(this, key);
        if (entry) entry[1] = value;else this.a.push([key, value]);
      },
      'delete': function _delete(key) {
        var index = arrayFindIndex(this.a, function (it) {
          return it[0] === key;
        });
        if (~index) this.a.splice(index, 1);
        return !!~index;
      }
    };

    module.exports = {
      getConstructor: function getConstructor(wrapper, NAME, IS_MAP, ADDER) {
        var C = wrapper(function (that, iterable) {
          anInstance(that, C, NAME, '_i');
          that._i = id++; // collection id
          that._l = undefined; // leak store for uncaught frozen objects
          if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
        });
        redefineAll(C.prototype, {
          // 23.3.3.2 WeakMap.prototype.delete(key)
          // 23.4.3.3 WeakSet.prototype.delete(value)
          'delete': function _delete(key) {
            if (!isObject(key)) return false;
            var data = getWeak(key);
            if (data === true) return uncaughtFrozenStore(this)['delete'](key);
            return data && $has(data, this._i) && delete data[this._i];
          },
          // 23.3.3.4 WeakMap.prototype.has(key)
          // 23.4.3.4 WeakSet.prototype.has(value)
          has: function has(key) {
            if (!isObject(key)) return false;
            var data = getWeak(key);
            if (data === true) return uncaughtFrozenStore(this).has(key);
            return data && $has(data, this._i);
          }
        });
        return C;
      },
      def: function def(that, key, value) {
        var data = getWeak(anObject(key), true);
        if (data === true) uncaughtFrozenStore(that).set(key, value);else data[that._i] = value;
        return that;
      },
      ufstore: uncaughtFrozenStore
    };
  }, { "./_an-instance": 6, "./_an-object": 7, "./_array-methods": 12, "./_for-of": 37, "./_has": 39, "./_is-object": 49, "./_meta": 62, "./_redefine-all": 86 }], 22: [function (require, module, exports) {
    'use strict';

    var global = require('./_global'),
        $export = require('./_export'),
        redefine = require('./_redefine'),
        redefineAll = require('./_redefine-all'),
        meta = require('./_meta'),
        forOf = require('./_for-of'),
        anInstance = require('./_an-instance'),
        isObject = require('./_is-object'),
        fails = require('./_fails'),
        $iterDetect = require('./_iter-detect'),
        setToStringTag = require('./_set-to-string-tag'),
        inheritIfRequired = require('./_inherit-if-required');

    module.exports = function (NAME, wrapper, methods, common, IS_MAP, IS_WEAK) {
      var Base = global[NAME],
          C = Base,
          ADDER = IS_MAP ? 'set' : 'add',
          proto = C && C.prototype,
          O = {};
      var fixMethod = function fixMethod(KEY) {
        var fn = proto[KEY];
        redefine(proto, KEY, KEY == 'delete' ? function (a) {
          return IS_WEAK && !isObject(a) ? false : fn.call(this, a === 0 ? 0 : a);
        } : KEY == 'has' ? function has(a) {
          return IS_WEAK && !isObject(a) ? false : fn.call(this, a === 0 ? 0 : a);
        } : KEY == 'get' ? function get(a) {
          return IS_WEAK && !isObject(a) ? undefined : fn.call(this, a === 0 ? 0 : a);
        } : KEY == 'add' ? function add(a) {
          fn.call(this, a === 0 ? 0 : a);return this;
        } : function set(a, b) {
          fn.call(this, a === 0 ? 0 : a, b);return this;
        });
      };
      if (typeof C != 'function' || !(IS_WEAK || proto.forEach && !fails(function () {
        new C().entries().next();
      }))) {
        // create collection constructor
        C = common.getConstructor(wrapper, NAME, IS_MAP, ADDER);
        redefineAll(C.prototype, methods);
        meta.NEED = true;
      } else {
        var instance = new C()
        // early implementations not supports chaining
        ,
            HASNT_CHAINING = instance[ADDER](IS_WEAK ? {} : -0, 1) != instance
        // V8 ~  Chromium 40- weak-collections throws on primitives, but should return false
        ,
            THROWS_ON_PRIMITIVES = fails(function () {
          instance.has(1);
        })
        // most early implementations doesn't supports iterables, most modern - not close it correctly
        ,
            ACCEPT_ITERABLES = $iterDetect(function (iter) {
          new C(iter);
        }) // eslint-disable-line no-new
        // for early implementations -0 and +0 not the same
        ,
            BUGGY_ZERO = !IS_WEAK && fails(function () {
          // V8 ~ Chromium 42- fails only with 5+ elements
          var $instance = new C(),
              index = 5;
          while (index--) {
            $instance[ADDER](index, index);
          }return !$instance.has(-0);
        });
        if (!ACCEPT_ITERABLES) {
          C = wrapper(function (target, iterable) {
            anInstance(target, C, NAME);
            var that = inheritIfRequired(new Base(), target, C);
            if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
            return that;
          });
          C.prototype = proto;
          proto.constructor = C;
        }
        if (THROWS_ON_PRIMITIVES || BUGGY_ZERO) {
          fixMethod('delete');
          fixMethod('has');
          IS_MAP && fixMethod('get');
        }
        if (BUGGY_ZERO || HASNT_CHAINING) fixMethod(ADDER);
        // weak collections should not contains .clear method
        if (IS_WEAK && proto.clear) delete proto.clear;
      }

      setToStringTag(C, NAME);

      O[NAME] = C;
      $export($export.G + $export.W + $export.F * (C != Base), O);

      if (!IS_WEAK) common.setStrong(C, NAME, IS_MAP);

      return C;
    };
  }, { "./_an-instance": 6, "./_export": 32, "./_fails": 34, "./_for-of": 37, "./_global": 38, "./_inherit-if-required": 43, "./_is-object": 49, "./_iter-detect": 54, "./_meta": 62, "./_redefine": 87, "./_redefine-all": 86, "./_set-to-string-tag": 92 }], 23: [function (require, module, exports) {
    var core = module.exports = { version: '2.4.0' };
    if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef
  }, {}], 24: [function (require, module, exports) {
    'use strict';

    var $defineProperty = require('./_object-dp'),
        createDesc = require('./_property-desc');

    module.exports = function (object, index, value) {
      if (index in object) $defineProperty.f(object, index, createDesc(0, value));else object[index] = value;
    };
  }, { "./_object-dp": 67, "./_property-desc": 85 }], 25: [function (require, module, exports) {
    // optional / simple context binding
    var aFunction = require('./_a-function');
    module.exports = function (fn, that, length) {
      aFunction(fn);
      if (that === undefined) return fn;
      switch (length) {
        case 1:
          return function (a) {
            return fn.call(that, a);
          };
        case 2:
          return function (a, b) {
            return fn.call(that, a, b);
          };
        case 3:
          return function (a, b, c) {
            return fn.call(that, a, b, c);
          };
      }
      return function () /* ...args */{
        return fn.apply(that, arguments);
      };
    };
  }, { "./_a-function": 3 }], 26: [function (require, module, exports) {
    'use strict';

    var anObject = require('./_an-object'),
        toPrimitive = require('./_to-primitive'),
        NUMBER = 'number';

    module.exports = function (hint) {
      if (hint !== 'string' && hint !== NUMBER && hint !== 'default') throw TypeError('Incorrect hint');
      return toPrimitive(anObject(this), hint != NUMBER);
    };
  }, { "./_an-object": 7, "./_to-primitive": 110 }], 27: [function (require, module, exports) {
    // 7.2.1 RequireObjectCoercible(argument)
    module.exports = function (it) {
      if (it == undefined) throw TypeError("Can't call method on  " + it);
      return it;
    };
  }, {}], 28: [function (require, module, exports) {
    // Thank's IE8 for his funny defineProperty
    module.exports = !require('./_fails')(function () {
      return Object.defineProperty({}, 'a', { get: function get() {
          return 7;
        } }).a != 7;
    });
  }, { "./_fails": 34 }], 29: [function (require, module, exports) {
    var isObject = require('./_is-object'),
        document = require('./_global').document
    // in old IE typeof document.createElement is 'object'
    ,
        is = isObject(document) && isObject(document.createElement);
    module.exports = function (it) {
      return is ? document.createElement(it) : {};
    };
  }, { "./_global": 38, "./_is-object": 49 }], 30: [function (require, module, exports) {
    // IE 8- don't enum bug keys
    module.exports = 'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'.split(',');
  }, {}], 31: [function (require, module, exports) {
    // all enumerable object keys, includes symbols
    var getKeys = require('./_object-keys'),
        gOPS = require('./_object-gops'),
        pIE = require('./_object-pie');
    module.exports = function (it) {
      var result = getKeys(it),
          getSymbols = gOPS.f;
      if (getSymbols) {
        var symbols = getSymbols(it),
            isEnum = pIE.f,
            i = 0,
            key;
        while (symbols.length > i) {
          if (isEnum.call(it, key = symbols[i++])) result.push(key);
        }
      }return result;
    };
  }, { "./_object-gops": 73, "./_object-keys": 76, "./_object-pie": 77 }], 32: [function (require, module, exports) {
    var global = require('./_global'),
        core = require('./_core'),
        hide = require('./_hide'),
        redefine = require('./_redefine'),
        ctx = require('./_ctx'),
        PROTOTYPE = 'prototype';

    var $export = function $export(type, name, source) {
      var IS_FORCED = type & $export.F,
          IS_GLOBAL = type & $export.G,
          IS_STATIC = type & $export.S,
          IS_PROTO = type & $export.P,
          IS_BIND = type & $export.B,
          target = IS_GLOBAL ? global : IS_STATIC ? global[name] || (global[name] = {}) : (global[name] || {})[PROTOTYPE],
          exports = IS_GLOBAL ? core : core[name] || (core[name] = {}),
          expProto = exports[PROTOTYPE] || (exports[PROTOTYPE] = {}),
          key,
          own,
          out,
          exp;
      if (IS_GLOBAL) source = name;
      for (key in source) {
        // contains in native
        own = !IS_FORCED && target && target[key] !== undefined;
        // export native or passed
        out = (own ? target : source)[key];
        // bind timers to global for call from export context
        exp = IS_BIND && own ? ctx(out, global) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
        // extend global
        if (target) redefine(target, key, out, type & $export.U);
        // export
        if (exports[key] != out) hide(exports, key, exp);
        if (IS_PROTO && expProto[key] != out) expProto[key] = out;
      }
    };
    global.core = core;
    // type bitmap
    $export.F = 1; // forced
    $export.G = 2; // global
    $export.S = 4; // static
    $export.P = 8; // proto
    $export.B = 16; // bind
    $export.W = 32; // wrap
    $export.U = 64; // safe
    $export.R = 128; // real proto method for `library` 
    module.exports = $export;
  }, { "./_core": 23, "./_ctx": 25, "./_global": 38, "./_hide": 40, "./_redefine": 87 }], 33: [function (require, module, exports) {
    var MATCH = require('./_wks')('match');
    module.exports = function (KEY) {
      var re = /./;
      try {
        '/./'[KEY](re);
      } catch (e) {
        try {
          re[MATCH] = false;
          return !'/./'[KEY](re);
        } catch (f) {/* empty */}
      }return true;
    };
  }, { "./_wks": 117 }], 34: [function (require, module, exports) {
    module.exports = function (exec) {
      try {
        return !!exec();
      } catch (e) {
        return true;
      }
    };
  }, {}], 35: [function (require, module, exports) {
    'use strict';

    var hide = require('./_hide'),
        redefine = require('./_redefine'),
        fails = require('./_fails'),
        defined = require('./_defined'),
        wks = require('./_wks');

    module.exports = function (KEY, length, exec) {
      var SYMBOL = wks(KEY),
          fns = exec(defined, SYMBOL, ''[KEY]),
          strfn = fns[0],
          rxfn = fns[1];
      if (fails(function () {
        var O = {};
        O[SYMBOL] = function () {
          return 7;
        };
        return ''[KEY](O) != 7;
      })) {
        redefine(String.prototype, KEY, strfn);
        hide(RegExp.prototype, SYMBOL, length == 2
        // 21.2.5.8 RegExp.prototype[@@replace](string, replaceValue)
        // 21.2.5.11 RegExp.prototype[@@split](string, limit)
        ? function (string, arg) {
          return rxfn.call(string, this, arg);
        }
        // 21.2.5.6 RegExp.prototype[@@match](string)
        // 21.2.5.9 RegExp.prototype[@@search](string)
        : function (string) {
          return rxfn.call(string, this);
        });
      }
    };
  }, { "./_defined": 27, "./_fails": 34, "./_hide": 40, "./_redefine": 87, "./_wks": 117 }], 36: [function (require, module, exports) {
    'use strict';
    // 21.2.5.3 get RegExp.prototype.flags

    var anObject = require('./_an-object');
    module.exports = function () {
      var that = anObject(this),
          result = '';
      if (that.global) result += 'g';
      if (that.ignoreCase) result += 'i';
      if (that.multiline) result += 'm';
      if (that.unicode) result += 'u';
      if (that.sticky) result += 'y';
      return result;
    };
  }, { "./_an-object": 7 }], 37: [function (require, module, exports) {
    var ctx = require('./_ctx'),
        call = require('./_iter-call'),
        isArrayIter = require('./_is-array-iter'),
        anObject = require('./_an-object'),
        toLength = require('./_to-length'),
        getIterFn = require('./core.get-iterator-method'),
        BREAK = {},
        RETURN = {};
    var exports = module.exports = function (iterable, entries, fn, that, ITERATOR) {
      var iterFn = ITERATOR ? function () {
        return iterable;
      } : getIterFn(iterable),
          f = ctx(fn, that, entries ? 2 : 1),
          index = 0,
          length,
          step,
          iterator,
          result;
      if (typeof iterFn != 'function') throw TypeError(iterable + ' is not iterable!');
      // fast case for arrays with default iterator
      if (isArrayIter(iterFn)) for (length = toLength(iterable.length); length > index; index++) {
        result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
        if (result === BREAK || result === RETURN) return result;
      } else for (iterator = iterFn.call(iterable); !(step = iterator.next()).done;) {
        result = call(iterator, f, step.value, entries);
        if (result === BREAK || result === RETURN) return result;
      }
    };
    exports.BREAK = BREAK;
    exports.RETURN = RETURN;
  }, { "./_an-object": 7, "./_ctx": 25, "./_is-array-iter": 46, "./_iter-call": 51, "./_to-length": 108, "./core.get-iterator-method": 118 }], 38: [function (require, module, exports) {
    // https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
    var global = module.exports = typeof window != 'undefined' && window.Math == Math ? window : typeof self != 'undefined' && self.Math == Math ? self : Function('return this')();
    if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef
  }, {}], 39: [function (require, module, exports) {
    var hasOwnProperty = {}.hasOwnProperty;
    module.exports = function (it, key) {
      return hasOwnProperty.call(it, key);
    };
  }, {}], 40: [function (require, module, exports) {
    var dP = require('./_object-dp'),
        createDesc = require('./_property-desc');
    module.exports = require('./_descriptors') ? function (object, key, value) {
      return dP.f(object, key, createDesc(1, value));
    } : function (object, key, value) {
      object[key] = value;
      return object;
    };
  }, { "./_descriptors": 28, "./_object-dp": 67, "./_property-desc": 85 }], 41: [function (require, module, exports) {
    module.exports = require('./_global').document && document.documentElement;
  }, { "./_global": 38 }], 42: [function (require, module, exports) {
    module.exports = !require('./_descriptors') && !require('./_fails')(function () {
      return Object.defineProperty(require('./_dom-create')('div'), 'a', { get: function get() {
          return 7;
        } }).a != 7;
    });
  }, { "./_descriptors": 28, "./_dom-create": 29, "./_fails": 34 }], 43: [function (require, module, exports) {
    var isObject = require('./_is-object'),
        setPrototypeOf = require('./_set-proto').set;
    module.exports = function (that, target, C) {
      var P,
          S = target.constructor;
      if (S !== C && typeof S == 'function' && (P = S.prototype) !== C.prototype && isObject(P) && setPrototypeOf) {
        setPrototypeOf(that, P);
      }return that;
    };
  }, { "./_is-object": 49, "./_set-proto": 90 }], 44: [function (require, module, exports) {
    // fast apply, http://jsperf.lnkit.com/fast-apply/5
    module.exports = function (fn, args, that) {
      var un = that === undefined;
      switch (args.length) {
        case 0:
          return un ? fn() : fn.call(that);
        case 1:
          return un ? fn(args[0]) : fn.call(that, args[0]);
        case 2:
          return un ? fn(args[0], args[1]) : fn.call(that, args[0], args[1]);
        case 3:
          return un ? fn(args[0], args[1], args[2]) : fn.call(that, args[0], args[1], args[2]);
        case 4:
          return un ? fn(args[0], args[1], args[2], args[3]) : fn.call(that, args[0], args[1], args[2], args[3]);
      }return fn.apply(that, args);
    };
  }, {}], 45: [function (require, module, exports) {
    // fallback for non-array-like ES3 and non-enumerable old V8 strings
    var cof = require('./_cof');
    module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
      return cof(it) == 'String' ? it.split('') : Object(it);
    };
  }, { "./_cof": 18 }], 46: [function (require, module, exports) {
    // check on default Array iterator
    var Iterators = require('./_iterators'),
        ITERATOR = require('./_wks')('iterator'),
        ArrayProto = Array.prototype;

    module.exports = function (it) {
      return it !== undefined && (Iterators.Array === it || ArrayProto[ITERATOR] === it);
    };
  }, { "./_iterators": 56, "./_wks": 117 }], 47: [function (require, module, exports) {
    // 7.2.2 IsArray(argument)
    var cof = require('./_cof');
    module.exports = Array.isArray || function isArray(arg) {
      return cof(arg) == 'Array';
    };
  }, { "./_cof": 18 }], 48: [function (require, module, exports) {
    // 20.1.2.3 Number.isInteger(number)
    var isObject = require('./_is-object'),
        floor = Math.floor;
    module.exports = function isInteger(it) {
      return !isObject(it) && isFinite(it) && floor(it) === it;
    };
  }, { "./_is-object": 49 }], 49: [function (require, module, exports) {
    module.exports = function (it) {
      return (typeof it === "undefined" ? "undefined" : _typeof(it)) === 'object' ? it !== null : typeof it === 'function';
    };
  }, {}], 50: [function (require, module, exports) {
    // 7.2.8 IsRegExp(argument)
    var isObject = require('./_is-object'),
        cof = require('./_cof'),
        MATCH = require('./_wks')('match');
    module.exports = function (it) {
      var isRegExp;
      return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : cof(it) == 'RegExp');
    };
  }, { "./_cof": 18, "./_is-object": 49, "./_wks": 117 }], 51: [function (require, module, exports) {
    // call something on iterator step with safe closing on error
    var anObject = require('./_an-object');
    module.exports = function (iterator, fn, value, entries) {
      try {
        return entries ? fn(anObject(value)[0], value[1]) : fn(value);
        // 7.4.6 IteratorClose(iterator, completion)
      } catch (e) {
        var ret = iterator['return'];
        if (ret !== undefined) anObject(ret.call(iterator));
        throw e;
      }
    };
  }, { "./_an-object": 7 }], 52: [function (require, module, exports) {
    'use strict';

    var create = require('./_object-create'),
        descriptor = require('./_property-desc'),
        setToStringTag = require('./_set-to-string-tag'),
        IteratorPrototype = {};

    // 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
    require('./_hide')(IteratorPrototype, require('./_wks')('iterator'), function () {
      return this;
    });

    module.exports = function (Constructor, NAME, next) {
      Constructor.prototype = create(IteratorPrototype, { next: descriptor(1, next) });
      setToStringTag(Constructor, NAME + ' Iterator');
    };
  }, { "./_hide": 40, "./_object-create": 66, "./_property-desc": 85, "./_set-to-string-tag": 92, "./_wks": 117 }], 53: [function (require, module, exports) {
    'use strict';

    var LIBRARY = require('./_library'),
        $export = require('./_export'),
        redefine = require('./_redefine'),
        hide = require('./_hide'),
        has = require('./_has'),
        Iterators = require('./_iterators'),
        $iterCreate = require('./_iter-create'),
        setToStringTag = require('./_set-to-string-tag'),
        getPrototypeOf = require('./_object-gpo'),
        ITERATOR = require('./_wks')('iterator'),
        BUGGY = !([].keys && 'next' in [].keys()) // Safari has buggy iterators w/o `next`
    ,
        FF_ITERATOR = '@@iterator',
        KEYS = 'keys',
        VALUES = 'values';

    var returnThis = function returnThis() {
      return this;
    };

    module.exports = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
      $iterCreate(Constructor, NAME, next);
      var getMethod = function getMethod(kind) {
        if (!BUGGY && kind in proto) return proto[kind];
        switch (kind) {
          case KEYS:
            return function keys() {
              return new Constructor(this, kind);
            };
          case VALUES:
            return function values() {
              return new Constructor(this, kind);
            };
        }return function entries() {
          return new Constructor(this, kind);
        };
      };
      var TAG = NAME + ' Iterator',
          DEF_VALUES = DEFAULT == VALUES,
          VALUES_BUG = false,
          proto = Base.prototype,
          $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT],
          $default = $native || getMethod(DEFAULT),
          $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined,
          $anyNative = NAME == 'Array' ? proto.entries || $native : $native,
          methods,
          key,
          IteratorPrototype;
      // Fix native
      if ($anyNative) {
        IteratorPrototype = getPrototypeOf($anyNative.call(new Base()));
        if (IteratorPrototype !== Object.prototype) {
          // Set @@toStringTag to native iterators
          setToStringTag(IteratorPrototype, TAG, true);
          // fix for some old engines
          if (!LIBRARY && !has(IteratorPrototype, ITERATOR)) hide(IteratorPrototype, ITERATOR, returnThis);
        }
      }
      // fix Array#{values, @@iterator}.name in V8 / FF
      if (DEF_VALUES && $native && $native.name !== VALUES) {
        VALUES_BUG = true;
        $default = function values() {
          return $native.call(this);
        };
      }
      // Define iterator
      if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
        hide(proto, ITERATOR, $default);
      }
      // Plug for library
      Iterators[NAME] = $default;
      Iterators[TAG] = returnThis;
      if (DEFAULT) {
        methods = {
          values: DEF_VALUES ? $default : getMethod(VALUES),
          keys: IS_SET ? $default : getMethod(KEYS),
          entries: $entries
        };
        if (FORCED) for (key in methods) {
          if (!(key in proto)) redefine(proto, key, methods[key]);
        } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
      }
      return methods;
    };
  }, { "./_export": 32, "./_has": 39, "./_hide": 40, "./_iter-create": 52, "./_iterators": 56, "./_library": 58, "./_object-gpo": 74, "./_redefine": 87, "./_set-to-string-tag": 92, "./_wks": 117 }], 54: [function (require, module, exports) {
    var ITERATOR = require('./_wks')('iterator'),
        SAFE_CLOSING = false;

    try {
      var riter = [7][ITERATOR]();
      riter['return'] = function () {
        SAFE_CLOSING = true;
      };
      Array.from(riter, function () {
        throw 2;
      });
    } catch (e) {/* empty */}

    module.exports = function (exec, skipClosing) {
      if (!skipClosing && !SAFE_CLOSING) return false;
      var safe = false;
      try {
        var arr = [7],
            iter = arr[ITERATOR]();
        iter.next = function () {
          return { done: safe = true };
        };
        arr[ITERATOR] = function () {
          return iter;
        };
        exec(arr);
      } catch (e) {/* empty */}
      return safe;
    };
  }, { "./_wks": 117 }], 55: [function (require, module, exports) {
    module.exports = function (done, value) {
      return { value: value, done: !!done };
    };
  }, {}], 56: [function (require, module, exports) {
    module.exports = {};
  }, {}], 57: [function (require, module, exports) {
    var getKeys = require('./_object-keys'),
        toIObject = require('./_to-iobject');
    module.exports = function (object, el) {
      var O = toIObject(object),
          keys = getKeys(O),
          length = keys.length,
          index = 0,
          key;
      while (length > index) {
        if (O[key = keys[index++]] === el) return key;
      }
    };
  }, { "./_object-keys": 76, "./_to-iobject": 107 }], 58: [function (require, module, exports) {
    module.exports = false;
  }, {}], 59: [function (require, module, exports) {
    // 20.2.2.14 Math.expm1(x)
    var $expm1 = Math.expm1;
    module.exports = !$expm1
    // Old FF bug
    || $expm1(10) > 22025.465794806719 || $expm1(10) < 22025.4657948067165168
    // Tor Browser bug
    || $expm1(-2e-17) != -2e-17 ? function expm1(x) {
      return (x = +x) == 0 ? x : x > -1e-6 && x < 1e-6 ? x + x * x / 2 : Math.exp(x) - 1;
    } : $expm1;
  }, {}], 60: [function (require, module, exports) {
    // 20.2.2.20 Math.log1p(x)
    module.exports = Math.log1p || function log1p(x) {
      return (x = +x) > -1e-8 && x < 1e-8 ? x - x * x / 2 : Math.log(1 + x);
    };
  }, {}], 61: [function (require, module, exports) {
    // 20.2.2.28 Math.sign(x)
    module.exports = Math.sign || function sign(x) {
      return (x = +x) == 0 || x != x ? x : x < 0 ? -1 : 1;
    };
  }, {}], 62: [function (require, module, exports) {
    var META = require('./_uid')('meta'),
        isObject = require('./_is-object'),
        has = require('./_has'),
        setDesc = require('./_object-dp').f,
        id = 0;
    var isExtensible = Object.isExtensible || function () {
      return true;
    };
    var FREEZE = !require('./_fails')(function () {
      return isExtensible(Object.preventExtensions({}));
    });
    var setMeta = function setMeta(it) {
      setDesc(it, META, { value: {
          i: 'O' + ++id, // object ID
          w: {} // weak collections IDs
        } });
    };
    var fastKey = function fastKey(it, create) {
      // return primitive with prefix
      if (!isObject(it)) return (typeof it === "undefined" ? "undefined" : _typeof(it)) == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
      if (!has(it, META)) {
        // can't set metadata to uncaught frozen object
        if (!isExtensible(it)) return 'F';
        // not necessary to add metadata
        if (!create) return 'E';
        // add missing metadata
        setMeta(it);
        // return object ID
      }return it[META].i;
    };
    var getWeak = function getWeak(it, create) {
      if (!has(it, META)) {
        // can't set metadata to uncaught frozen object
        if (!isExtensible(it)) return true;
        // not necessary to add metadata
        if (!create) return false;
        // add missing metadata
        setMeta(it);
        // return hash weak collections IDs
      }return it[META].w;
    };
    // add metadata on freeze-family methods calling
    var onFreeze = function onFreeze(it) {
      if (FREEZE && meta.NEED && isExtensible(it) && !has(it, META)) setMeta(it);
      return it;
    };
    var meta = module.exports = {
      KEY: META,
      NEED: false,
      fastKey: fastKey,
      getWeak: getWeak,
      onFreeze: onFreeze
    };
  }, { "./_fails": 34, "./_has": 39, "./_is-object": 49, "./_object-dp": 67, "./_uid": 114 }], 63: [function (require, module, exports) {
    var Map = require('./es6.map'),
        $export = require('./_export'),
        shared = require('./_shared')('metadata'),
        store = shared.store || (shared.store = new (require('./es6.weak-map'))());

    var getOrCreateMetadataMap = function getOrCreateMetadataMap(target, targetKey, create) {
      var targetMetadata = store.get(target);
      if (!targetMetadata) {
        if (!create) return undefined;
        store.set(target, targetMetadata = new Map());
      }
      var keyMetadata = targetMetadata.get(targetKey);
      if (!keyMetadata) {
        if (!create) return undefined;
        targetMetadata.set(targetKey, keyMetadata = new Map());
      }return keyMetadata;
    };
    var ordinaryHasOwnMetadata = function ordinaryHasOwnMetadata(MetadataKey, O, P) {
      var metadataMap = getOrCreateMetadataMap(O, P, false);
      return metadataMap === undefined ? false : metadataMap.has(MetadataKey);
    };
    var ordinaryGetOwnMetadata = function ordinaryGetOwnMetadata(MetadataKey, O, P) {
      var metadataMap = getOrCreateMetadataMap(O, P, false);
      return metadataMap === undefined ? undefined : metadataMap.get(MetadataKey);
    };
    var ordinaryDefineOwnMetadata = function ordinaryDefineOwnMetadata(MetadataKey, MetadataValue, O, P) {
      getOrCreateMetadataMap(O, P, true).set(MetadataKey, MetadataValue);
    };
    var ordinaryOwnMetadataKeys = function ordinaryOwnMetadataKeys(target, targetKey) {
      var metadataMap = getOrCreateMetadataMap(target, targetKey, false),
          keys = [];
      if (metadataMap) metadataMap.forEach(function (_, key) {
        keys.push(key);
      });
      return keys;
    };
    var toMetaKey = function toMetaKey(it) {
      return it === undefined || (typeof it === "undefined" ? "undefined" : _typeof(it)) == 'symbol' ? it : String(it);
    };
    var exp = function exp(O) {
      $export($export.S, 'Reflect', O);
    };

    module.exports = {
      store: store,
      map: getOrCreateMetadataMap,
      has: ordinaryHasOwnMetadata,
      get: ordinaryGetOwnMetadata,
      set: ordinaryDefineOwnMetadata,
      keys: ordinaryOwnMetadataKeys,
      key: toMetaKey,
      exp: exp
    };
  }, { "./_export": 32, "./_shared": 94, "./es6.map": 149, "./es6.weak-map": 255 }], 64: [function (require, module, exports) {
    var global = require('./_global'),
        macrotask = require('./_task').set,
        Observer = global.MutationObserver || global.WebKitMutationObserver,
        process = global.process,
        Promise = global.Promise,
        isNode = require('./_cof')(process) == 'process';

    module.exports = function () {
      var head, last, notify;

      var flush = function flush() {
        var parent, fn;
        if (isNode && (parent = process.domain)) parent.exit();
        while (head) {
          fn = head.fn;
          head = head.next;
          try {
            fn();
          } catch (e) {
            if (head) notify();else last = undefined;
            throw e;
          }
        }last = undefined;
        if (parent) parent.enter();
      };

      // Node.js
      if (isNode) {
        notify = function notify() {
          process.nextTick(flush);
        };
        // browsers with MutationObserver
      } else if (Observer) {
        var toggle = true,
            node = document.createTextNode('');
        new Observer(flush).observe(node, { characterData: true }); // eslint-disable-line no-new
        notify = function notify() {
          node.data = toggle = !toggle;
        };
        // environments with maybe non-completely correct, but existent Promise
      } else if (Promise && Promise.resolve) {
        var promise = Promise.resolve();
        notify = function notify() {
          promise.then(flush);
        };
        // for other environments - macrotask based on:
        // - setImmediate
        // - MessageChannel
        // - window.postMessag
        // - onreadystatechange
        // - setTimeout
      } else {
        notify = function notify() {
          // strange IE + webpack dev server bug - use .call(global)
          macrotask.call(global, flush);
        };
      }

      return function (fn) {
        var task = { fn: fn, next: undefined };
        if (last) last.next = task;
        if (!head) {
          head = task;
          notify();
        }last = task;
      };
    };
  }, { "./_cof": 18, "./_global": 38, "./_task": 104 }], 65: [function (require, module, exports) {
    'use strict';
    // 19.1.2.1 Object.assign(target, source, ...)

    var getKeys = require('./_object-keys'),
        gOPS = require('./_object-gops'),
        pIE = require('./_object-pie'),
        toObject = require('./_to-object'),
        IObject = require('./_iobject'),
        $assign = Object.assign;

    // should work with symbols and should have deterministic property order (V8 bug)
    module.exports = !$assign || require('./_fails')(function () {
      var A = {},
          B = {},
          S = Symbol(),
          K = 'abcdefghijklmnopqrst';
      A[S] = 7;
      K.split('').forEach(function (k) {
        B[k] = k;
      });
      return $assign({}, A)[S] != 7 || Object.keys($assign({}, B)).join('') != K;
    }) ? function assign(target, source) {
      // eslint-disable-line no-unused-vars
      var T = toObject(target),
          aLen = arguments.length,
          index = 1,
          getSymbols = gOPS.f,
          isEnum = pIE.f;
      while (aLen > index) {
        var S = IObject(arguments[index++]),
            keys = getSymbols ? getKeys(S).concat(getSymbols(S)) : getKeys(S),
            length = keys.length,
            j = 0,
            key;
        while (length > j) {
          if (isEnum.call(S, key = keys[j++])) T[key] = S[key];
        }
      }return T;
    } : $assign;
  }, { "./_fails": 34, "./_iobject": 45, "./_object-gops": 73, "./_object-keys": 76, "./_object-pie": 77, "./_to-object": 109 }], 66: [function (require, module, exports) {
    // 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
    var anObject = require('./_an-object'),
        dPs = require('./_object-dps'),
        enumBugKeys = require('./_enum-bug-keys'),
        IE_PROTO = require('./_shared-key')('IE_PROTO'),
        Empty = function Empty() {/* empty */},
        PROTOTYPE = 'prototype';

    // Create object with fake `null` prototype: use iframe Object with cleared prototype
    var _createDict = function createDict() {
      // Thrash, waste and sodomy: IE GC bug
      var iframe = require('./_dom-create')('iframe'),
          i = enumBugKeys.length,
          lt = '<',
          gt = '>',
          iframeDocument;
      iframe.style.display = 'none';
      require('./_html').appendChild(iframe);
      iframe.src = 'javascript:'; // eslint-disable-line no-script-url
      // createDict = iframe.contentWindow.Object;
      // html.removeChild(iframe);
      iframeDocument = iframe.contentWindow.document;
      iframeDocument.open();
      iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
      iframeDocument.close();
      _createDict = iframeDocument.F;
      while (i--) {
        delete _createDict[PROTOTYPE][enumBugKeys[i]];
      }return _createDict();
    };

    module.exports = Object.create || function create(O, Properties) {
      var result;
      if (O !== null) {
        Empty[PROTOTYPE] = anObject(O);
        result = new Empty();
        Empty[PROTOTYPE] = null;
        // add "__proto__" for Object.getPrototypeOf polyfill
        result[IE_PROTO] = O;
      } else result = _createDict();
      return Properties === undefined ? result : dPs(result, Properties);
    };
  }, { "./_an-object": 7, "./_dom-create": 29, "./_enum-bug-keys": 30, "./_html": 41, "./_object-dps": 68, "./_shared-key": 93 }], 67: [function (require, module, exports) {
    var anObject = require('./_an-object'),
        IE8_DOM_DEFINE = require('./_ie8-dom-define'),
        toPrimitive = require('./_to-primitive'),
        dP = Object.defineProperty;

    exports.f = require('./_descriptors') ? Object.defineProperty : function defineProperty(O, P, Attributes) {
      anObject(O);
      P = toPrimitive(P, true);
      anObject(Attributes);
      if (IE8_DOM_DEFINE) try {
        return dP(O, P, Attributes);
      } catch (e) {/* empty */}
      if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
      if ('value' in Attributes) O[P] = Attributes.value;
      return O;
    };
  }, { "./_an-object": 7, "./_descriptors": 28, "./_ie8-dom-define": 42, "./_to-primitive": 110 }], 68: [function (require, module, exports) {
    var dP = require('./_object-dp'),
        anObject = require('./_an-object'),
        getKeys = require('./_object-keys');

    module.exports = require('./_descriptors') ? Object.defineProperties : function defineProperties(O, Properties) {
      anObject(O);
      var keys = getKeys(Properties),
          length = keys.length,
          i = 0,
          P;
      while (length > i) {
        dP.f(O, P = keys[i++], Properties[P]);
      }return O;
    };
  }, { "./_an-object": 7, "./_descriptors": 28, "./_object-dp": 67, "./_object-keys": 76 }], 69: [function (require, module, exports) {
    // Forced replacement prototype accessors methods
    module.exports = require('./_library') || !require('./_fails')(function () {
      var K = Math.random();
      // In FF throws only define methods
      __defineSetter__.call(null, K, function () {/* empty */});
      delete require('./_global')[K];
    });
  }, { "./_fails": 34, "./_global": 38, "./_library": 58 }], 70: [function (require, module, exports) {
    var pIE = require('./_object-pie'),
        createDesc = require('./_property-desc'),
        toIObject = require('./_to-iobject'),
        toPrimitive = require('./_to-primitive'),
        has = require('./_has'),
        IE8_DOM_DEFINE = require('./_ie8-dom-define'),
        gOPD = Object.getOwnPropertyDescriptor;

    exports.f = require('./_descriptors') ? gOPD : function getOwnPropertyDescriptor(O, P) {
      O = toIObject(O);
      P = toPrimitive(P, true);
      if (IE8_DOM_DEFINE) try {
        return gOPD(O, P);
      } catch (e) {/* empty */}
      if (has(O, P)) return createDesc(!pIE.f.call(O, P), O[P]);
    };
  }, { "./_descriptors": 28, "./_has": 39, "./_ie8-dom-define": 42, "./_object-pie": 77, "./_property-desc": 85, "./_to-iobject": 107, "./_to-primitive": 110 }], 71: [function (require, module, exports) {
    // fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
    var toIObject = require('./_to-iobject'),
        gOPN = require('./_object-gopn').f,
        toString = {}.toString;

    var windowNames = (typeof window === "undefined" ? "undefined" : _typeof(window)) == 'object' && window && Object.getOwnPropertyNames ? Object.getOwnPropertyNames(window) : [];

    var getWindowNames = function getWindowNames(it) {
      try {
        return gOPN(it);
      } catch (e) {
        return windowNames.slice();
      }
    };

    module.exports.f = function getOwnPropertyNames(it) {
      return windowNames && toString.call(it) == '[object Window]' ? getWindowNames(it) : gOPN(toIObject(it));
    };
  }, { "./_object-gopn": 72, "./_to-iobject": 107 }], 72: [function (require, module, exports) {
    // 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)
    var $keys = require('./_object-keys-internal'),
        hiddenKeys = require('./_enum-bug-keys').concat('length', 'prototype');

    exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
      return $keys(O, hiddenKeys);
    };
  }, { "./_enum-bug-keys": 30, "./_object-keys-internal": 75 }], 73: [function (require, module, exports) {
    exports.f = Object.getOwnPropertySymbols;
  }, {}], 74: [function (require, module, exports) {
    // 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
    var has = require('./_has'),
        toObject = require('./_to-object'),
        IE_PROTO = require('./_shared-key')('IE_PROTO'),
        ObjectProto = Object.prototype;

    module.exports = Object.getPrototypeOf || function (O) {
      O = toObject(O);
      if (has(O, IE_PROTO)) return O[IE_PROTO];
      if (typeof O.constructor == 'function' && O instanceof O.constructor) {
        return O.constructor.prototype;
      }return O instanceof Object ? ObjectProto : null;
    };
  }, { "./_has": 39, "./_shared-key": 93, "./_to-object": 109 }], 75: [function (require, module, exports) {
    var has = require('./_has'),
        toIObject = require('./_to-iobject'),
        arrayIndexOf = require('./_array-includes')(false),
        IE_PROTO = require('./_shared-key')('IE_PROTO');

    module.exports = function (object, names) {
      var O = toIObject(object),
          i = 0,
          result = [],
          key;
      for (key in O) {
        if (key != IE_PROTO) has(O, key) && result.push(key);
      } // Don't enum bug & hidden keys
      while (names.length > i) {
        if (has(O, key = names[i++])) {
          ~arrayIndexOf(result, key) || result.push(key);
        }
      }return result;
    };
  }, { "./_array-includes": 11, "./_has": 39, "./_shared-key": 93, "./_to-iobject": 107 }], 76: [function (require, module, exports) {
    // 19.1.2.14 / 15.2.3.14 Object.keys(O)
    var $keys = require('./_object-keys-internal'),
        enumBugKeys = require('./_enum-bug-keys');

    module.exports = Object.keys || function keys(O) {
      return $keys(O, enumBugKeys);
    };
  }, { "./_enum-bug-keys": 30, "./_object-keys-internal": 75 }], 77: [function (require, module, exports) {
    exports.f = {}.propertyIsEnumerable;
  }, {}], 78: [function (require, module, exports) {
    // most Object methods by ES6 should accept primitives
    var $export = require('./_export'),
        core = require('./_core'),
        fails = require('./_fails');
    module.exports = function (KEY, exec) {
      var fn = (core.Object || {})[KEY] || Object[KEY],
          exp = {};
      exp[KEY] = exec(fn);
      $export($export.S + $export.F * fails(function () {
        fn(1);
      }), 'Object', exp);
    };
  }, { "./_core": 23, "./_export": 32, "./_fails": 34 }], 79: [function (require, module, exports) {
    var getKeys = require('./_object-keys'),
        toIObject = require('./_to-iobject'),
        isEnum = require('./_object-pie').f;
    module.exports = function (isEntries) {
      return function (it) {
        var O = toIObject(it),
            keys = getKeys(O),
            length = keys.length,
            i = 0,
            result = [],
            key;
        while (length > i) {
          if (isEnum.call(O, key = keys[i++])) {
            result.push(isEntries ? [key, O[key]] : O[key]);
          }
        }return result;
      };
    };
  }, { "./_object-keys": 76, "./_object-pie": 77, "./_to-iobject": 107 }], 80: [function (require, module, exports) {
    // all object keys, includes non-enumerable and symbols
    var gOPN = require('./_object-gopn'),
        gOPS = require('./_object-gops'),
        anObject = require('./_an-object'),
        Reflect = require('./_global').Reflect;
    module.exports = Reflect && Reflect.ownKeys || function ownKeys(it) {
      var keys = gOPN.f(anObject(it)),
          getSymbols = gOPS.f;
      return getSymbols ? keys.concat(getSymbols(it)) : keys;
    };
  }, { "./_an-object": 7, "./_global": 38, "./_object-gopn": 72, "./_object-gops": 73 }], 81: [function (require, module, exports) {
    var $parseFloat = require('./_global').parseFloat,
        $trim = require('./_string-trim').trim;

    module.exports = 1 / $parseFloat(require('./_string-ws') + '-0') !== -Infinity ? function parseFloat(str) {
      var string = $trim(String(str), 3),
          result = $parseFloat(string);
      return result === 0 && string.charAt(0) == '-' ? -0 : result;
    } : $parseFloat;
  }, { "./_global": 38, "./_string-trim": 102, "./_string-ws": 103 }], 82: [function (require, module, exports) {
    var $parseInt = require('./_global').parseInt,
        $trim = require('./_string-trim').trim,
        ws = require('./_string-ws'),
        hex = /^[\-+]?0[xX]/;

    module.exports = $parseInt(ws + '08') !== 8 || $parseInt(ws + '0x16') !== 22 ? function parseInt(str, radix) {
      var string = $trim(String(str), 3);
      return $parseInt(string, radix >>> 0 || (hex.test(string) ? 16 : 10));
    } : $parseInt;
  }, { "./_global": 38, "./_string-trim": 102, "./_string-ws": 103 }], 83: [function (require, module, exports) {
    'use strict';

    var path = require('./_path'),
        invoke = require('./_invoke'),
        aFunction = require('./_a-function');
    module.exports = function () /* ...pargs */{
      var fn = aFunction(this),
          length = arguments.length,
          pargs = Array(length),
          i = 0,
          _ = path._,
          holder = false;
      while (length > i) {
        if ((pargs[i] = arguments[i++]) === _) holder = true;
      }return function () /* ...args */{
        var that = this,
            aLen = arguments.length,
            j = 0,
            k = 0,
            args;
        if (!holder && !aLen) return invoke(fn, pargs, that);
        args = pargs.slice();
        if (holder) for (; length > j; j++) {
          if (args[j] === _) args[j] = arguments[k++];
        }while (aLen > k) {
          args.push(arguments[k++]);
        }return invoke(fn, args, that);
      };
    };
  }, { "./_a-function": 3, "./_invoke": 44, "./_path": 84 }], 84: [function (require, module, exports) {
    module.exports = require('./_global');
  }, { "./_global": 38 }], 85: [function (require, module, exports) {
    module.exports = function (bitmap, value) {
      return {
        enumerable: !(bitmap & 1),
        configurable: !(bitmap & 2),
        writable: !(bitmap & 4),
        value: value
      };
    };
  }, {}], 86: [function (require, module, exports) {
    var redefine = require('./_redefine');
    module.exports = function (target, src, safe) {
      for (var key in src) {
        redefine(target, key, src[key], safe);
      }return target;
    };
  }, { "./_redefine": 87 }], 87: [function (require, module, exports) {
    var global = require('./_global'),
        hide = require('./_hide'),
        has = require('./_has'),
        SRC = require('./_uid')('src'),
        TO_STRING = 'toString',
        $toString = Function[TO_STRING],
        TPL = ('' + $toString).split(TO_STRING);

    require('./_core').inspectSource = function (it) {
      return $toString.call(it);
    };

    (module.exports = function (O, key, val, safe) {
      var isFunction = typeof val == 'function';
      if (isFunction) has(val, 'name') || hide(val, 'name', key);
      if (O[key] === val) return;
      if (isFunction) has(val, SRC) || hide(val, SRC, O[key] ? '' + O[key] : TPL.join(String(key)));
      if (O === global) {
        O[key] = val;
      } else {
        if (!safe) {
          delete O[key];
          hide(O, key, val);
        } else {
          if (O[key]) O[key] = val;else hide(O, key, val);
        }
      }
      // add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
    })(Function.prototype, TO_STRING, function toString() {
      return typeof this == 'function' && this[SRC] || $toString.call(this);
    });
  }, { "./_core": 23, "./_global": 38, "./_has": 39, "./_hide": 40, "./_uid": 114 }], 88: [function (require, module, exports) {
    module.exports = function (regExp, replace) {
      var replacer = replace === Object(replace) ? function (part) {
        return replace[part];
      } : replace;
      return function (it) {
        return String(it).replace(regExp, replacer);
      };
    };
  }, {}], 89: [function (require, module, exports) {
    // 7.2.9 SameValue(x, y)
    module.exports = Object.is || function is(x, y) {
      return x === y ? x !== 0 || 1 / x === 1 / y : x != x && y != y;
    };
  }, {}], 90: [function (require, module, exports) {
    // Works with __proto__ only. Old v8 can't work with null proto objects.
    /* eslint-disable no-proto */
    var isObject = require('./_is-object'),
        anObject = require('./_an-object');
    var check = function check(O, proto) {
      anObject(O);
      if (!isObject(proto) && proto !== null) throw TypeError(proto + ": can't set as prototype!");
    };
    module.exports = {
      set: Object.setPrototypeOf || ('__proto__' in {} ? // eslint-disable-line
      function (test, buggy, set) {
        try {
          set = require('./_ctx')(Function.call, require('./_object-gopd').f(Object.prototype, '__proto__').set, 2);
          set(test, []);
          buggy = !(test instanceof Array);
        } catch (e) {
          buggy = true;
        }
        return function setPrototypeOf(O, proto) {
          check(O, proto);
          if (buggy) O.__proto__ = proto;else set(O, proto);
          return O;
        };
      }({}, false) : undefined),
      check: check
    };
  }, { "./_an-object": 7, "./_ctx": 25, "./_is-object": 49, "./_object-gopd": 70 }], 91: [function (require, module, exports) {
    'use strict';

    var global = require('./_global'),
        dP = require('./_object-dp'),
        DESCRIPTORS = require('./_descriptors'),
        SPECIES = require('./_wks')('species');

    module.exports = function (KEY) {
      var C = global[KEY];
      if (DESCRIPTORS && C && !C[SPECIES]) dP.f(C, SPECIES, {
        configurable: true,
        get: function get() {
          return this;
        }
      });
    };
  }, { "./_descriptors": 28, "./_global": 38, "./_object-dp": 67, "./_wks": 117 }], 92: [function (require, module, exports) {
    var def = require('./_object-dp').f,
        has = require('./_has'),
        TAG = require('./_wks')('toStringTag');

    module.exports = function (it, tag, stat) {
      if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, { configurable: true, value: tag });
    };
  }, { "./_has": 39, "./_object-dp": 67, "./_wks": 117 }], 93: [function (require, module, exports) {
    var shared = require('./_shared')('keys'),
        uid = require('./_uid');
    module.exports = function (key) {
      return shared[key] || (shared[key] = uid(key));
    };
  }, { "./_shared": 94, "./_uid": 114 }], 94: [function (require, module, exports) {
    var global = require('./_global'),
        SHARED = '__core-js_shared__',
        store = global[SHARED] || (global[SHARED] = {});
    module.exports = function (key) {
      return store[key] || (store[key] = {});
    };
  }, { "./_global": 38 }], 95: [function (require, module, exports) {
    // 7.3.20 SpeciesConstructor(O, defaultConstructor)
    var anObject = require('./_an-object'),
        aFunction = require('./_a-function'),
        SPECIES = require('./_wks')('species');
    module.exports = function (O, D) {
      var C = anObject(O).constructor,
          S;
      return C === undefined || (S = anObject(C)[SPECIES]) == undefined ? D : aFunction(S);
    };
  }, { "./_a-function": 3, "./_an-object": 7, "./_wks": 117 }], 96: [function (require, module, exports) {
    var fails = require('./_fails');

    module.exports = function (method, arg) {
      return !!method && fails(function () {
        arg ? method.call(null, function () {}, 1) : method.call(null);
      });
    };
  }, { "./_fails": 34 }], 97: [function (require, module, exports) {
    var toInteger = require('./_to-integer'),
        defined = require('./_defined');
    // true  -> String#at
    // false -> String#codePointAt
    module.exports = function (TO_STRING) {
      return function (that, pos) {
        var s = String(defined(that)),
            i = toInteger(pos),
            l = s.length,
            a,
            b;
        if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
        a = s.charCodeAt(i);
        return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff ? TO_STRING ? s.charAt(i) : a : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
      };
    };
  }, { "./_defined": 27, "./_to-integer": 106 }], 98: [function (require, module, exports) {
    // helper for String#{startsWith, endsWith, includes}
    var isRegExp = require('./_is-regexp'),
        defined = require('./_defined');

    module.exports = function (that, searchString, NAME) {
      if (isRegExp(searchString)) throw TypeError('String#' + NAME + " doesn't accept regex!");
      return String(defined(that));
    };
  }, { "./_defined": 27, "./_is-regexp": 50 }], 99: [function (require, module, exports) {
    var $export = require('./_export'),
        fails = require('./_fails'),
        defined = require('./_defined'),
        quot = /"/g;
    // B.2.3.2.1 CreateHTML(string, tag, attribute, value)
    var createHTML = function createHTML(string, tag, attribute, value) {
      var S = String(defined(string)),
          p1 = '<' + tag;
      if (attribute !== '') p1 += ' ' + attribute + '="' + String(value).replace(quot, '&quot;') + '"';
      return p1 + '>' + S + '</' + tag + '>';
    };
    module.exports = function (NAME, exec) {
      var O = {};
      O[NAME] = exec(createHTML);
      $export($export.P + $export.F * fails(function () {
        var test = ''[NAME]('"');
        return test !== test.toLowerCase() || test.split('"').length > 3;
      }), 'String', O);
    };
  }, { "./_defined": 27, "./_export": 32, "./_fails": 34 }], 100: [function (require, module, exports) {
    // https://github.com/tc39/proposal-string-pad-start-end
    var toLength = require('./_to-length'),
        repeat = require('./_string-repeat'),
        defined = require('./_defined');

    module.exports = function (that, maxLength, fillString, left) {
      var S = String(defined(that)),
          stringLength = S.length,
          fillStr = fillString === undefined ? ' ' : String(fillString),
          intMaxLength = toLength(maxLength);
      if (intMaxLength <= stringLength || fillStr == '') return S;
      var fillLen = intMaxLength - stringLength,
          stringFiller = repeat.call(fillStr, Math.ceil(fillLen / fillStr.length));
      if (stringFiller.length > fillLen) stringFiller = stringFiller.slice(0, fillLen);
      return left ? stringFiller + S : S + stringFiller;
    };
  }, { "./_defined": 27, "./_string-repeat": 101, "./_to-length": 108 }], 101: [function (require, module, exports) {
    'use strict';

    var toInteger = require('./_to-integer'),
        defined = require('./_defined');

    module.exports = function repeat(count) {
      var str = String(defined(this)),
          res = '',
          n = toInteger(count);
      if (n < 0 || n == Infinity) throw RangeError("Count can't be negative");
      for (; n > 0; (n >>>= 1) && (str += str)) {
        if (n & 1) res += str;
      }return res;
    };
  }, { "./_defined": 27, "./_to-integer": 106 }], 102: [function (require, module, exports) {
    var $export = require('./_export'),
        defined = require('./_defined'),
        fails = require('./_fails'),
        spaces = require('./_string-ws'),
        space = '[' + spaces + ']',
        non = "\u200B\x85",
        ltrim = RegExp('^' + space + space + '*'),
        rtrim = RegExp(space + space + '*$');

    var exporter = function exporter(KEY, exec, ALIAS) {
      var exp = {};
      var FORCE = fails(function () {
        return !!spaces[KEY]() || non[KEY]() != non;
      });
      var fn = exp[KEY] = FORCE ? exec(trim) : spaces[KEY];
      if (ALIAS) exp[ALIAS] = fn;
      $export($export.P + $export.F * FORCE, 'String', exp);
    };

    // 1 -> String#trimLeft
    // 2 -> String#trimRight
    // 3 -> String#trim
    var trim = exporter.trim = function (string, TYPE) {
      string = String(defined(string));
      if (TYPE & 1) string = string.replace(ltrim, '');
      if (TYPE & 2) string = string.replace(rtrim, '');
      return string;
    };

    module.exports = exporter;
  }, { "./_defined": 27, "./_export": 32, "./_fails": 34, "./_string-ws": 103 }], 103: [function (require, module, exports) {
    module.exports = "\t\n\x0B\f\r \xA0\u1680\u180E\u2000\u2001\u2002\u2003" + "\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF";
  }, {}], 104: [function (require, module, exports) {
    var ctx = require('./_ctx'),
        invoke = require('./_invoke'),
        html = require('./_html'),
        cel = require('./_dom-create'),
        global = require('./_global'),
        process = global.process,
        setTask = global.setImmediate,
        clearTask = global.clearImmediate,
        MessageChannel = global.MessageChannel,
        counter = 0,
        queue = {},
        ONREADYSTATECHANGE = 'onreadystatechange',
        defer,
        channel,
        port;
    var run = function run() {
      var id = +this;
      if (queue.hasOwnProperty(id)) {
        var fn = queue[id];
        delete queue[id];
        fn();
      }
    };
    var listener = function listener(event) {
      run.call(event.data);
    };
    // Node.js 0.9+ & IE10+ has setImmediate, otherwise:
    if (!setTask || !clearTask) {
      setTask = function setImmediate(fn) {
        var args = [],
            i = 1;
        while (arguments.length > i) {
          args.push(arguments[i++]);
        }queue[++counter] = function () {
          invoke(typeof fn == 'function' ? fn : Function(fn), args);
        };
        defer(counter);
        return counter;
      };
      clearTask = function clearImmediate(id) {
        delete queue[id];
      };
      // Node.js 0.8-
      if (require('./_cof')(process) == 'process') {
        defer = function defer(id) {
          process.nextTick(ctx(run, id, 1));
        };
        // Browsers with MessageChannel, includes WebWorkers
      } else if (MessageChannel) {
        channel = new MessageChannel();
        port = channel.port2;
        channel.port1.onmessage = listener;
        defer = ctx(port.postMessage, port, 1);
        // Browsers with postMessage, skip WebWorkers
        // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
      } else if (global.addEventListener && typeof postMessage == 'function' && !global.importScripts) {
        defer = function defer(id) {
          global.postMessage(id + '', '*');
        };
        global.addEventListener('message', listener, false);
        // IE8-
      } else if (ONREADYSTATECHANGE in cel('script')) {
        defer = function defer(id) {
          html.appendChild(cel('script'))[ONREADYSTATECHANGE] = function () {
            html.removeChild(this);
            run.call(id);
          };
        };
        // Rest old browsers
      } else {
        defer = function defer(id) {
          setTimeout(ctx(run, id, 1), 0);
        };
      }
    }
    module.exports = {
      set: setTask,
      clear: clearTask
    };
  }, { "./_cof": 18, "./_ctx": 25, "./_dom-create": 29, "./_global": 38, "./_html": 41, "./_invoke": 44 }], 105: [function (require, module, exports) {
    var toInteger = require('./_to-integer'),
        max = Math.max,
        min = Math.min;
    module.exports = function (index, length) {
      index = toInteger(index);
      return index < 0 ? max(index + length, 0) : min(index, length);
    };
  }, { "./_to-integer": 106 }], 106: [function (require, module, exports) {
    // 7.1.4 ToInteger
    var ceil = Math.ceil,
        floor = Math.floor;
    module.exports = function (it) {
      return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
    };
  }, {}], 107: [function (require, module, exports) {
    // to indexed object, toObject with fallback for non-array-like ES3 strings
    var IObject = require('./_iobject'),
        defined = require('./_defined');
    module.exports = function (it) {
      return IObject(defined(it));
    };
  }, { "./_defined": 27, "./_iobject": 45 }], 108: [function (require, module, exports) {
    // 7.1.15 ToLength
    var toInteger = require('./_to-integer'),
        min = Math.min;
    module.exports = function (it) {
      return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
    };
  }, { "./_to-integer": 106 }], 109: [function (require, module, exports) {
    // 7.1.13 ToObject(argument)
    var defined = require('./_defined');
    module.exports = function (it) {
      return Object(defined(it));
    };
  }, { "./_defined": 27 }], 110: [function (require, module, exports) {
    // 7.1.1 ToPrimitive(input [, PreferredType])
    var isObject = require('./_is-object');
    // instead of the ES6 spec version, we didn't implement @@toPrimitive case
    // and the second argument - flag - preferred type is a string
    module.exports = function (it, S) {
      if (!isObject(it)) return it;
      var fn, val;
      if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
      if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
      if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
      throw TypeError("Can't convert object to primitive value");
    };
  }, { "./_is-object": 49 }], 111: [function (require, module, exports) {
    'use strict';

    if (require('./_descriptors')) {
      var LIBRARY = require('./_library'),
          global = require('./_global'),
          fails = require('./_fails'),
          $export = require('./_export'),
          $typed = require('./_typed'),
          $buffer = require('./_typed-buffer'),
          ctx = require('./_ctx'),
          anInstance = require('./_an-instance'),
          propertyDesc = require('./_property-desc'),
          hide = require('./_hide'),
          redefineAll = require('./_redefine-all'),
          toInteger = require('./_to-integer'),
          toLength = require('./_to-length'),
          toIndex = require('./_to-index'),
          toPrimitive = require('./_to-primitive'),
          has = require('./_has'),
          same = require('./_same-value'),
          classof = require('./_classof'),
          isObject = require('./_is-object'),
          toObject = require('./_to-object'),
          isArrayIter = require('./_is-array-iter'),
          create = require('./_object-create'),
          getPrototypeOf = require('./_object-gpo'),
          gOPN = require('./_object-gopn').f,
          getIterFn = require('./core.get-iterator-method'),
          uid = require('./_uid'),
          wks = require('./_wks'),
          createArrayMethod = require('./_array-methods'),
          createArrayIncludes = require('./_array-includes'),
          speciesConstructor = require('./_species-constructor'),
          ArrayIterators = require('./es6.array.iterator'),
          Iterators = require('./_iterators'),
          $iterDetect = require('./_iter-detect'),
          setSpecies = require('./_set-species'),
          arrayFill = require('./_array-fill'),
          arrayCopyWithin = require('./_array-copy-within'),
          $DP = require('./_object-dp'),
          $GOPD = require('./_object-gopd'),
          dP = $DP.f,
          gOPD = $GOPD.f,
          RangeError = global.RangeError,
          TypeError = global.TypeError,
          Uint8Array = global.Uint8Array,
          ARRAY_BUFFER = 'ArrayBuffer',
          SHARED_BUFFER = 'Shared' + ARRAY_BUFFER,
          BYTES_PER_ELEMENT = 'BYTES_PER_ELEMENT',
          PROTOTYPE = 'prototype',
          ArrayProto = Array[PROTOTYPE],
          $ArrayBuffer = $buffer.ArrayBuffer,
          $DataView = $buffer.DataView,
          arrayForEach = createArrayMethod(0),
          arrayFilter = createArrayMethod(2),
          arraySome = createArrayMethod(3),
          arrayEvery = createArrayMethod(4),
          arrayFind = createArrayMethod(5),
          arrayFindIndex = createArrayMethod(6),
          arrayIncludes = createArrayIncludes(true),
          arrayIndexOf = createArrayIncludes(false),
          arrayValues = ArrayIterators.values,
          arrayKeys = ArrayIterators.keys,
          arrayEntries = ArrayIterators.entries,
          arrayLastIndexOf = ArrayProto.lastIndexOf,
          arrayReduce = ArrayProto.reduce,
          arrayReduceRight = ArrayProto.reduceRight,
          arrayJoin = ArrayProto.join,
          arraySort = ArrayProto.sort,
          arraySlice = ArrayProto.slice,
          arrayToString = ArrayProto.toString,
          arrayToLocaleString = ArrayProto.toLocaleString,
          ITERATOR = wks('iterator'),
          TAG = wks('toStringTag'),
          TYPED_CONSTRUCTOR = uid('typed_constructor'),
          DEF_CONSTRUCTOR = uid('def_constructor'),
          ALL_CONSTRUCTORS = $typed.CONSTR,
          TYPED_ARRAY = $typed.TYPED,
          VIEW = $typed.VIEW,
          WRONG_LENGTH = 'Wrong length!';

      var $map = createArrayMethod(1, function (O, length) {
        return allocate(speciesConstructor(O, O[DEF_CONSTRUCTOR]), length);
      });

      var LITTLE_ENDIAN = fails(function () {
        return new Uint8Array(new Uint16Array([1]).buffer)[0] === 1;
      });

      var FORCED_SET = !!Uint8Array && !!Uint8Array[PROTOTYPE].set && fails(function () {
        new Uint8Array(1).set({});
      });

      var strictToLength = function strictToLength(it, SAME) {
        if (it === undefined) throw TypeError(WRONG_LENGTH);
        var number = +it,
            length = toLength(it);
        if (SAME && !same(number, length)) throw RangeError(WRONG_LENGTH);
        return length;
      };

      var toOffset = function toOffset(it, BYTES) {
        var offset = toInteger(it);
        if (offset < 0 || offset % BYTES) throw RangeError('Wrong offset!');
        return offset;
      };

      var validate = function validate(it) {
        if (isObject(it) && TYPED_ARRAY in it) return it;
        throw TypeError(it + ' is not a typed array!');
      };

      var allocate = function allocate(C, length) {
        if (!(isObject(C) && TYPED_CONSTRUCTOR in C)) {
          throw TypeError('It is not a typed array constructor!');
        }return new C(length);
      };

      var speciesFromList = function speciesFromList(O, list) {
        return fromList(speciesConstructor(O, O[DEF_CONSTRUCTOR]), list);
      };

      var fromList = function fromList(C, list) {
        var index = 0,
            length = list.length,
            result = allocate(C, length);
        while (length > index) {
          result[index] = list[index++];
        }return result;
      };

      var addGetter = function addGetter(it, key, internal) {
        dP(it, key, { get: function get() {
            return this._d[internal];
          } });
      };

      var $from = function from(source /*, mapfn, thisArg */) {
        var O = toObject(source),
            aLen = arguments.length,
            mapfn = aLen > 1 ? arguments[1] : undefined,
            mapping = mapfn !== undefined,
            iterFn = getIterFn(O),
            i,
            length,
            values,
            result,
            step,
            iterator;
        if (iterFn != undefined && !isArrayIter(iterFn)) {
          for (iterator = iterFn.call(O), values = [], i = 0; !(step = iterator.next()).done; i++) {
            values.push(step.value);
          }O = values;
        }
        if (mapping && aLen > 2) mapfn = ctx(mapfn, arguments[2], 2);
        for (i = 0, length = toLength(O.length), result = allocate(this, length); length > i; i++) {
          result[i] = mapping ? mapfn(O[i], i) : O[i];
        }
        return result;
      };

      var $of = function of() /*...items*/{
        var index = 0,
            length = arguments.length,
            result = allocate(this, length);
        while (length > index) {
          result[index] = arguments[index++];
        }return result;
      };

      // iOS Safari 6.x fails here
      var TO_LOCALE_BUG = !!Uint8Array && fails(function () {
        arrayToLocaleString.call(new Uint8Array(1));
      });

      var $toLocaleString = function toLocaleString() {
        return arrayToLocaleString.apply(TO_LOCALE_BUG ? arraySlice.call(validate(this)) : validate(this), arguments);
      };

      var proto = {
        copyWithin: function copyWithin(target, start /*, end */) {
          return arrayCopyWithin.call(validate(this), target, start, arguments.length > 2 ? arguments[2] : undefined);
        },
        every: function every(callbackfn /*, thisArg */) {
          return arrayEvery(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
        },
        fill: function fill(value /*, start, end */) {
          // eslint-disable-line no-unused-vars
          return arrayFill.apply(validate(this), arguments);
        },
        filter: function filter(callbackfn /*, thisArg */) {
          return speciesFromList(this, arrayFilter(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined));
        },
        find: function find(predicate /*, thisArg */) {
          return arrayFind(validate(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
        },
        findIndex: function findIndex(predicate /*, thisArg */) {
          return arrayFindIndex(validate(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
        },
        forEach: function forEach(callbackfn /*, thisArg */) {
          arrayForEach(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
        },
        indexOf: function indexOf(searchElement /*, fromIndex */) {
          return arrayIndexOf(validate(this), searchElement, arguments.length > 1 ? arguments[1] : undefined);
        },
        includes: function includes(searchElement /*, fromIndex */) {
          return arrayIncludes(validate(this), searchElement, arguments.length > 1 ? arguments[1] : undefined);
        },
        join: function join(separator) {
          // eslint-disable-line no-unused-vars
          return arrayJoin.apply(validate(this), arguments);
        },
        lastIndexOf: function lastIndexOf(searchElement /*, fromIndex */) {
          // eslint-disable-line no-unused-vars
          return arrayLastIndexOf.apply(validate(this), arguments);
        },
        map: function map(mapfn /*, thisArg */) {
          return $map(validate(this), mapfn, arguments.length > 1 ? arguments[1] : undefined);
        },
        reduce: function reduce(callbackfn /*, initialValue */) {
          // eslint-disable-line no-unused-vars
          return arrayReduce.apply(validate(this), arguments);
        },
        reduceRight: function reduceRight(callbackfn /*, initialValue */) {
          // eslint-disable-line no-unused-vars
          return arrayReduceRight.apply(validate(this), arguments);
        },
        reverse: function reverse() {
          var that = this,
              length = validate(that).length,
              middle = Math.floor(length / 2),
              index = 0,
              value;
          while (index < middle) {
            value = that[index];
            that[index++] = that[--length];
            that[length] = value;
          }return that;
        },
        some: function some(callbackfn /*, thisArg */) {
          return arraySome(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
        },
        sort: function sort(comparefn) {
          return arraySort.call(validate(this), comparefn);
        },
        subarray: function subarray(begin, end) {
          var O = validate(this),
              length = O.length,
              $begin = toIndex(begin, length);
          return new (speciesConstructor(O, O[DEF_CONSTRUCTOR]))(O.buffer, O.byteOffset + $begin * O.BYTES_PER_ELEMENT, toLength((end === undefined ? length : toIndex(end, length)) - $begin));
        }
      };

      var $slice = function slice(start, end) {
        return speciesFromList(this, arraySlice.call(validate(this), start, end));
      };

      var $set = function set(arrayLike /*, offset */) {
        validate(this);
        var offset = toOffset(arguments[1], 1),
            length = this.length,
            src = toObject(arrayLike),
            len = toLength(src.length),
            index = 0;
        if (len + offset > length) throw RangeError(WRONG_LENGTH);
        while (index < len) {
          this[offset + index] = src[index++];
        }
      };

      var $iterators = {
        entries: function entries() {
          return arrayEntries.call(validate(this));
        },
        keys: function keys() {
          return arrayKeys.call(validate(this));
        },
        values: function values() {
          return arrayValues.call(validate(this));
        }
      };

      var isTAIndex = function isTAIndex(target, key) {
        return isObject(target) && target[TYPED_ARRAY] && (typeof key === "undefined" ? "undefined" : _typeof(key)) != 'symbol' && key in target && String(+key) == String(key);
      };
      var $getDesc = function getOwnPropertyDescriptor(target, key) {
        return isTAIndex(target, key = toPrimitive(key, true)) ? propertyDesc(2, target[key]) : gOPD(target, key);
      };
      var $setDesc = function defineProperty(target, key, desc) {
        if (isTAIndex(target, key = toPrimitive(key, true)) && isObject(desc) && has(desc, 'value') && !has(desc, 'get') && !has(desc, 'set')
        // TODO: add validation descriptor w/o calling accessors
        && !desc.configurable && (!has(desc, 'writable') || desc.writable) && (!has(desc, 'enumerable') || desc.enumerable)) {
          target[key] = desc.value;
          return target;
        } else return dP(target, key, desc);
      };

      if (!ALL_CONSTRUCTORS) {
        $GOPD.f = $getDesc;
        $DP.f = $setDesc;
      }

      $export($export.S + $export.F * !ALL_CONSTRUCTORS, 'Object', {
        getOwnPropertyDescriptor: $getDesc,
        defineProperty: $setDesc
      });

      if (fails(function () {
        arrayToString.call({});
      })) {
        arrayToString = arrayToLocaleString = function toString() {
          return arrayJoin.call(this);
        };
      }

      var $TypedArrayPrototype$ = redefineAll({}, proto);
      redefineAll($TypedArrayPrototype$, $iterators);
      hide($TypedArrayPrototype$, ITERATOR, $iterators.values);
      redefineAll($TypedArrayPrototype$, {
        slice: $slice,
        set: $set,
        constructor: function constructor() {/* noop */},
        toString: arrayToString,
        toLocaleString: $toLocaleString
      });
      addGetter($TypedArrayPrototype$, 'buffer', 'b');
      addGetter($TypedArrayPrototype$, 'byteOffset', 'o');
      addGetter($TypedArrayPrototype$, 'byteLength', 'l');
      addGetter($TypedArrayPrototype$, 'length', 'e');
      dP($TypedArrayPrototype$, TAG, {
        get: function get() {
          return this[TYPED_ARRAY];
        }
      });

      module.exports = function (KEY, BYTES, wrapper, CLAMPED) {
        CLAMPED = !!CLAMPED;
        var NAME = KEY + (CLAMPED ? 'Clamped' : '') + 'Array',
            ISNT_UINT8 = NAME != 'Uint8Array',
            GETTER = 'get' + KEY,
            SETTER = 'set' + KEY,
            TypedArray = global[NAME],
            Base = TypedArray || {},
            TAC = TypedArray && getPrototypeOf(TypedArray),
            FORCED = !TypedArray || !$typed.ABV,
            O = {},
            TypedArrayPrototype = TypedArray && TypedArray[PROTOTYPE];
        var getter = function getter(that, index) {
          var data = that._d;
          return data.v[GETTER](index * BYTES + data.o, LITTLE_ENDIAN);
        };
        var setter = function setter(that, index, value) {
          var data = that._d;
          if (CLAMPED) value = (value = Math.round(value)) < 0 ? 0 : value > 0xff ? 0xff : value & 0xff;
          data.v[SETTER](index * BYTES + data.o, value, LITTLE_ENDIAN);
        };
        var addElement = function addElement(that, index) {
          dP(that, index, {
            get: function get() {
              return getter(this, index);
            },
            set: function set(value) {
              return setter(this, index, value);
            },
            enumerable: true
          });
        };
        if (FORCED) {
          TypedArray = wrapper(function (that, data, $offset, $length) {
            anInstance(that, TypedArray, NAME, '_d');
            var index = 0,
                offset = 0,
                buffer,
                byteLength,
                length,
                klass;
            if (!isObject(data)) {
              length = strictToLength(data, true);
              byteLength = length * BYTES;
              buffer = new $ArrayBuffer(byteLength);
            } else if (data instanceof $ArrayBuffer || (klass = classof(data)) == ARRAY_BUFFER || klass == SHARED_BUFFER) {
              buffer = data;
              offset = toOffset($offset, BYTES);
              var $len = data.byteLength;
              if ($length === undefined) {
                if ($len % BYTES) throw RangeError(WRONG_LENGTH);
                byteLength = $len - offset;
                if (byteLength < 0) throw RangeError(WRONG_LENGTH);
              } else {
                byteLength = toLength($length) * BYTES;
                if (byteLength + offset > $len) throw RangeError(WRONG_LENGTH);
              }
              length = byteLength / BYTES;
            } else if (TYPED_ARRAY in data) {
              return fromList(TypedArray, data);
            } else {
              return $from.call(TypedArray, data);
            }
            hide(that, '_d', {
              b: buffer,
              o: offset,
              l: byteLength,
              e: length,
              v: new $DataView(buffer)
            });
            while (index < length) {
              addElement(that, index++);
            }
          });
          TypedArrayPrototype = TypedArray[PROTOTYPE] = create($TypedArrayPrototype$);
          hide(TypedArrayPrototype, 'constructor', TypedArray);
        } else if (!$iterDetect(function (iter) {
          // V8 works with iterators, but fails in many other cases
          // https://code.google.com/p/v8/issues/detail?id=4552
          new TypedArray(null); // eslint-disable-line no-new
          new TypedArray(iter); // eslint-disable-line no-new
        }, true)) {
          TypedArray = wrapper(function (that, data, $offset, $length) {
            anInstance(that, TypedArray, NAME);
            var klass;
            // `ws` module bug, temporarily remove validation length for Uint8Array
            // https://github.com/websockets/ws/pull/645
            if (!isObject(data)) return new Base(strictToLength(data, ISNT_UINT8));
            if (data instanceof $ArrayBuffer || (klass = classof(data)) == ARRAY_BUFFER || klass == SHARED_BUFFER) {
              return $length !== undefined ? new Base(data, toOffset($offset, BYTES), $length) : $offset !== undefined ? new Base(data, toOffset($offset, BYTES)) : new Base(data);
            }
            if (TYPED_ARRAY in data) return fromList(TypedArray, data);
            return $from.call(TypedArray, data);
          });
          arrayForEach(TAC !== Function.prototype ? gOPN(Base).concat(gOPN(TAC)) : gOPN(Base), function (key) {
            if (!(key in TypedArray)) hide(TypedArray, key, Base[key]);
          });
          TypedArray[PROTOTYPE] = TypedArrayPrototype;
          if (!LIBRARY) TypedArrayPrototype.constructor = TypedArray;
        }
        var $nativeIterator = TypedArrayPrototype[ITERATOR],
            CORRECT_ITER_NAME = !!$nativeIterator && ($nativeIterator.name == 'values' || $nativeIterator.name == undefined),
            $iterator = $iterators.values;
        hide(TypedArray, TYPED_CONSTRUCTOR, true);
        hide(TypedArrayPrototype, TYPED_ARRAY, NAME);
        hide(TypedArrayPrototype, VIEW, true);
        hide(TypedArrayPrototype, DEF_CONSTRUCTOR, TypedArray);

        if (CLAMPED ? new TypedArray(1)[TAG] != NAME : !(TAG in TypedArrayPrototype)) {
          dP(TypedArrayPrototype, TAG, {
            get: function get() {
              return NAME;
            }
          });
        }

        O[NAME] = TypedArray;

        $export($export.G + $export.W + $export.F * (TypedArray != Base), O);

        $export($export.S, NAME, {
          BYTES_PER_ELEMENT: BYTES,
          from: $from,
          of: $of
        });

        if (!(BYTES_PER_ELEMENT in TypedArrayPrototype)) hide(TypedArrayPrototype, BYTES_PER_ELEMENT, BYTES);

        $export($export.P, NAME, proto);

        setSpecies(NAME);

        $export($export.P + $export.F * FORCED_SET, NAME, { set: $set });

        $export($export.P + $export.F * !CORRECT_ITER_NAME, NAME, $iterators);

        $export($export.P + $export.F * (TypedArrayPrototype.toString != arrayToString), NAME, { toString: arrayToString });

        $export($export.P + $export.F * fails(function () {
          new TypedArray(1).slice();
        }), NAME, { slice: $slice });

        $export($export.P + $export.F * (fails(function () {
          return [1, 2].toLocaleString() != new TypedArray([1, 2]).toLocaleString();
        }) || !fails(function () {
          TypedArrayPrototype.toLocaleString.call([1, 2]);
        })), NAME, { toLocaleString: $toLocaleString });

        Iterators[NAME] = CORRECT_ITER_NAME ? $nativeIterator : $iterator;
        if (!LIBRARY && !CORRECT_ITER_NAME) hide(TypedArrayPrototype, ITERATOR, $iterator);
      };
    } else module.exports = function () {/* empty */};
  }, { "./_an-instance": 6, "./_array-copy-within": 8, "./_array-fill": 9, "./_array-includes": 11, "./_array-methods": 12, "./_classof": 17, "./_ctx": 25, "./_descriptors": 28, "./_export": 32, "./_fails": 34, "./_global": 38, "./_has": 39, "./_hide": 40, "./_is-array-iter": 46, "./_is-object": 49, "./_iter-detect": 54, "./_iterators": 56, "./_library": 58, "./_object-create": 66, "./_object-dp": 67, "./_object-gopd": 70, "./_object-gopn": 72, "./_object-gpo": 74, "./_property-desc": 85, "./_redefine-all": 86, "./_same-value": 89, "./_set-species": 91, "./_species-constructor": 95, "./_to-index": 105, "./_to-integer": 106, "./_to-length": 108, "./_to-object": 109, "./_to-primitive": 110, "./_typed": 113, "./_typed-buffer": 112, "./_uid": 114, "./_wks": 117, "./core.get-iterator-method": 118, "./es6.array.iterator": 130 }], 112: [function (require, module, exports) {
    'use strict';

    var global = require('./_global'),
        DESCRIPTORS = require('./_descriptors'),
        LIBRARY = require('./_library'),
        $typed = require('./_typed'),
        hide = require('./_hide'),
        redefineAll = require('./_redefine-all'),
        fails = require('./_fails'),
        anInstance = require('./_an-instance'),
        toInteger = require('./_to-integer'),
        toLength = require('./_to-length'),
        gOPN = require('./_object-gopn').f,
        dP = require('./_object-dp').f,
        arrayFill = require('./_array-fill'),
        setToStringTag = require('./_set-to-string-tag'),
        ARRAY_BUFFER = 'ArrayBuffer',
        DATA_VIEW = 'DataView',
        PROTOTYPE = 'prototype',
        WRONG_LENGTH = 'Wrong length!',
        WRONG_INDEX = 'Wrong index!',
        $ArrayBuffer = global[ARRAY_BUFFER],
        $DataView = global[DATA_VIEW],
        Math = global.Math,
        RangeError = global.RangeError,
        Infinity = global.Infinity,
        BaseBuffer = $ArrayBuffer,
        abs = Math.abs,
        pow = Math.pow,
        floor = Math.floor,
        log = Math.log,
        LN2 = Math.LN2,
        BUFFER = 'buffer',
        BYTE_LENGTH = 'byteLength',
        BYTE_OFFSET = 'byteOffset',
        $BUFFER = DESCRIPTORS ? '_b' : BUFFER,
        $LENGTH = DESCRIPTORS ? '_l' : BYTE_LENGTH,
        $OFFSET = DESCRIPTORS ? '_o' : BYTE_OFFSET;

    // IEEE754 conversions based on https://github.com/feross/ieee754
    var packIEEE754 = function packIEEE754(value, mLen, nBytes) {
      var buffer = Array(nBytes),
          eLen = nBytes * 8 - mLen - 1,
          eMax = (1 << eLen) - 1,
          eBias = eMax >> 1,
          rt = mLen === 23 ? pow(2, -24) - pow(2, -77) : 0,
          i = 0,
          s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0,
          e,
          m,
          c;
      value = abs(value);
      if (value != value || value === Infinity) {
        m = value != value ? 1 : 0;
        e = eMax;
      } else {
        e = floor(log(value) / LN2);
        if (value * (c = pow(2, -e)) < 1) {
          e--;
          c *= 2;
        }
        if (e + eBias >= 1) {
          value += rt / c;
        } else {
          value += rt * pow(2, 1 - eBias);
        }
        if (value * c >= 2) {
          e++;
          c /= 2;
        }
        if (e + eBias >= eMax) {
          m = 0;
          e = eMax;
        } else if (e + eBias >= 1) {
          m = (value * c - 1) * pow(2, mLen);
          e = e + eBias;
        } else {
          m = value * pow(2, eBias - 1) * pow(2, mLen);
          e = 0;
        }
      }
      for (; mLen >= 8; buffer[i++] = m & 255, m /= 256, mLen -= 8) {}
      e = e << mLen | m;
      eLen += mLen;
      for (; eLen > 0; buffer[i++] = e & 255, e /= 256, eLen -= 8) {}
      buffer[--i] |= s * 128;
      return buffer;
    };
    var unpackIEEE754 = function unpackIEEE754(buffer, mLen, nBytes) {
      var eLen = nBytes * 8 - mLen - 1,
          eMax = (1 << eLen) - 1,
          eBias = eMax >> 1,
          nBits = eLen - 7,
          i = nBytes - 1,
          s = buffer[i--],
          e = s & 127,
          m;
      s >>= 7;
      for (; nBits > 0; e = e * 256 + buffer[i], i--, nBits -= 8) {}
      m = e & (1 << -nBits) - 1;
      e >>= -nBits;
      nBits += mLen;
      for (; nBits > 0; m = m * 256 + buffer[i], i--, nBits -= 8) {}
      if (e === 0) {
        e = 1 - eBias;
      } else if (e === eMax) {
        return m ? NaN : s ? -Infinity : Infinity;
      } else {
        m = m + pow(2, mLen);
        e = e - eBias;
      }return (s ? -1 : 1) * m * pow(2, e - mLen);
    };

    var unpackI32 = function unpackI32(bytes) {
      return bytes[3] << 24 | bytes[2] << 16 | bytes[1] << 8 | bytes[0];
    };
    var packI8 = function packI8(it) {
      return [it & 0xff];
    };
    var packI16 = function packI16(it) {
      return [it & 0xff, it >> 8 & 0xff];
    };
    var packI32 = function packI32(it) {
      return [it & 0xff, it >> 8 & 0xff, it >> 16 & 0xff, it >> 24 & 0xff];
    };
    var packF64 = function packF64(it) {
      return packIEEE754(it, 52, 8);
    };
    var packF32 = function packF32(it) {
      return packIEEE754(it, 23, 4);
    };

    var addGetter = function addGetter(C, key, internal) {
      dP(C[PROTOTYPE], key, { get: function get() {
          return this[internal];
        } });
    };

    var get = function get(view, bytes, index, isLittleEndian) {
      var numIndex = +index,
          intIndex = toInteger(numIndex);
      if (numIndex != intIndex || intIndex < 0 || intIndex + bytes > view[$LENGTH]) throw RangeError(WRONG_INDEX);
      var store = view[$BUFFER]._b,
          start = intIndex + view[$OFFSET],
          pack = store.slice(start, start + bytes);
      return isLittleEndian ? pack : pack.reverse();
    };
    var set = function set(view, bytes, index, conversion, value, isLittleEndian) {
      var numIndex = +index,
          intIndex = toInteger(numIndex);
      if (numIndex != intIndex || intIndex < 0 || intIndex + bytes > view[$LENGTH]) throw RangeError(WRONG_INDEX);
      var store = view[$BUFFER]._b,
          start = intIndex + view[$OFFSET],
          pack = conversion(+value);
      for (var i = 0; i < bytes; i++) {
        store[start + i] = pack[isLittleEndian ? i : bytes - i - 1];
      }
    };

    var validateArrayBufferArguments = function validateArrayBufferArguments(that, length) {
      anInstance(that, $ArrayBuffer, ARRAY_BUFFER);
      var numberLength = +length,
          byteLength = toLength(numberLength);
      if (numberLength != byteLength) throw RangeError(WRONG_LENGTH);
      return byteLength;
    };

    if (!$typed.ABV) {
      $ArrayBuffer = function ArrayBuffer(length) {
        var byteLength = validateArrayBufferArguments(this, length);
        this._b = arrayFill.call(Array(byteLength), 0);
        this[$LENGTH] = byteLength;
      };

      $DataView = function DataView(buffer, byteOffset, byteLength) {
        anInstance(this, $DataView, DATA_VIEW);
        anInstance(buffer, $ArrayBuffer, DATA_VIEW);
        var bufferLength = buffer[$LENGTH],
            offset = toInteger(byteOffset);
        if (offset < 0 || offset > bufferLength) throw RangeError('Wrong offset!');
        byteLength = byteLength === undefined ? bufferLength - offset : toLength(byteLength);
        if (offset + byteLength > bufferLength) throw RangeError(WRONG_LENGTH);
        this[$BUFFER] = buffer;
        this[$OFFSET] = offset;
        this[$LENGTH] = byteLength;
      };

      if (DESCRIPTORS) {
        addGetter($ArrayBuffer, BYTE_LENGTH, '_l');
        addGetter($DataView, BUFFER, '_b');
        addGetter($DataView, BYTE_LENGTH, '_l');
        addGetter($DataView, BYTE_OFFSET, '_o');
      }

      redefineAll($DataView[PROTOTYPE], {
        getInt8: function getInt8(byteOffset) {
          return get(this, 1, byteOffset)[0] << 24 >> 24;
        },
        getUint8: function getUint8(byteOffset) {
          return get(this, 1, byteOffset)[0];
        },
        getInt16: function getInt16(byteOffset /*, littleEndian */) {
          var bytes = get(this, 2, byteOffset, arguments[1]);
          return (bytes[1] << 8 | bytes[0]) << 16 >> 16;
        },
        getUint16: function getUint16(byteOffset /*, littleEndian */) {
          var bytes = get(this, 2, byteOffset, arguments[1]);
          return bytes[1] << 8 | bytes[0];
        },
        getInt32: function getInt32(byteOffset /*, littleEndian */) {
          return unpackI32(get(this, 4, byteOffset, arguments[1]));
        },
        getUint32: function getUint32(byteOffset /*, littleEndian */) {
          return unpackI32(get(this, 4, byteOffset, arguments[1])) >>> 0;
        },
        getFloat32: function getFloat32(byteOffset /*, littleEndian */) {
          return unpackIEEE754(get(this, 4, byteOffset, arguments[1]), 23, 4);
        },
        getFloat64: function getFloat64(byteOffset /*, littleEndian */) {
          return unpackIEEE754(get(this, 8, byteOffset, arguments[1]), 52, 8);
        },
        setInt8: function setInt8(byteOffset, value) {
          set(this, 1, byteOffset, packI8, value);
        },
        setUint8: function setUint8(byteOffset, value) {
          set(this, 1, byteOffset, packI8, value);
        },
        setInt16: function setInt16(byteOffset, value /*, littleEndian */) {
          set(this, 2, byteOffset, packI16, value, arguments[2]);
        },
        setUint16: function setUint16(byteOffset, value /*, littleEndian */) {
          set(this, 2, byteOffset, packI16, value, arguments[2]);
        },
        setInt32: function setInt32(byteOffset, value /*, littleEndian */) {
          set(this, 4, byteOffset, packI32, value, arguments[2]);
        },
        setUint32: function setUint32(byteOffset, value /*, littleEndian */) {
          set(this, 4, byteOffset, packI32, value, arguments[2]);
        },
        setFloat32: function setFloat32(byteOffset, value /*, littleEndian */) {
          set(this, 4, byteOffset, packF32, value, arguments[2]);
        },
        setFloat64: function setFloat64(byteOffset, value /*, littleEndian */) {
          set(this, 8, byteOffset, packF64, value, arguments[2]);
        }
      });
    } else {
      if (!fails(function () {
        new $ArrayBuffer(); // eslint-disable-line no-new
      }) || !fails(function () {
        new $ArrayBuffer(.5); // eslint-disable-line no-new
      })) {
        $ArrayBuffer = function ArrayBuffer(length) {
          return new BaseBuffer(validateArrayBufferArguments(this, length));
        };
        var ArrayBufferProto = $ArrayBuffer[PROTOTYPE] = BaseBuffer[PROTOTYPE];
        for (var keys = gOPN(BaseBuffer), j = 0, key; keys.length > j;) {
          if (!((key = keys[j++]) in $ArrayBuffer)) hide($ArrayBuffer, key, BaseBuffer[key]);
        };
        if (!LIBRARY) ArrayBufferProto.constructor = $ArrayBuffer;
      }
      // iOS Safari 7.x bug
      var view = new $DataView(new $ArrayBuffer(2)),
          $setInt8 = $DataView[PROTOTYPE].setInt8;
      view.setInt8(0, 2147483648);
      view.setInt8(1, 2147483649);
      if (view.getInt8(0) || !view.getInt8(1)) redefineAll($DataView[PROTOTYPE], {
        setInt8: function setInt8(byteOffset, value) {
          $setInt8.call(this, byteOffset, value << 24 >> 24);
        },
        setUint8: function setUint8(byteOffset, value) {
          $setInt8.call(this, byteOffset, value << 24 >> 24);
        }
      }, true);
    }
    setToStringTag($ArrayBuffer, ARRAY_BUFFER);
    setToStringTag($DataView, DATA_VIEW);
    hide($DataView[PROTOTYPE], $typed.VIEW, true);
    exports[ARRAY_BUFFER] = $ArrayBuffer;
    exports[DATA_VIEW] = $DataView;
  }, { "./_an-instance": 6, "./_array-fill": 9, "./_descriptors": 28, "./_fails": 34, "./_global": 38, "./_hide": 40, "./_library": 58, "./_object-dp": 67, "./_object-gopn": 72, "./_redefine-all": 86, "./_set-to-string-tag": 92, "./_to-integer": 106, "./_to-length": 108, "./_typed": 113 }], 113: [function (require, module, exports) {
    var global = require('./_global'),
        hide = require('./_hide'),
        uid = require('./_uid'),
        TYPED = uid('typed_array'),
        VIEW = uid('view'),
        ABV = !!(global.ArrayBuffer && global.DataView),
        CONSTR = ABV,
        i = 0,
        l = 9,
        Typed;

    var TypedArrayConstructors = 'Int8Array,Uint8Array,Uint8ClampedArray,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array'.split(',');

    while (i < l) {
      if (Typed = global[TypedArrayConstructors[i++]]) {
        hide(Typed.prototype, TYPED, true);
        hide(Typed.prototype, VIEW, true);
      } else CONSTR = false;
    }

    module.exports = {
      ABV: ABV,
      CONSTR: CONSTR,
      TYPED: TYPED,
      VIEW: VIEW
    };
  }, { "./_global": 38, "./_hide": 40, "./_uid": 114 }], 114: [function (require, module, exports) {
    var id = 0,
        px = Math.random();
    module.exports = function (key) {
      return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
    };
  }, {}], 115: [function (require, module, exports) {
    var global = require('./_global'),
        core = require('./_core'),
        LIBRARY = require('./_library'),
        wksExt = require('./_wks-ext'),
        defineProperty = require('./_object-dp').f;
    module.exports = function (name) {
      var $Symbol = core.Symbol || (core.Symbol = LIBRARY ? {} : global.Symbol || {});
      if (name.charAt(0) != '_' && !(name in $Symbol)) defineProperty($Symbol, name, { value: wksExt.f(name) });
    };
  }, { "./_core": 23, "./_global": 38, "./_library": 58, "./_object-dp": 67, "./_wks-ext": 116 }], 116: [function (require, module, exports) {
    exports.f = require('./_wks');
  }, { "./_wks": 117 }], 117: [function (require, module, exports) {
    var store = require('./_shared')('wks'),
        uid = require('./_uid'),
        _Symbol = require('./_global').Symbol,
        USE_SYMBOL = typeof _Symbol == 'function';

    var $exports = module.exports = function (name) {
      return store[name] || (store[name] = USE_SYMBOL && _Symbol[name] || (USE_SYMBOL ? _Symbol : uid)('Symbol.' + name));
    };

    $exports.store = store;
  }, { "./_global": 38, "./_shared": 94, "./_uid": 114 }], 118: [function (require, module, exports) {
    var classof = require('./_classof'),
        ITERATOR = require('./_wks')('iterator'),
        Iterators = require('./_iterators');
    module.exports = require('./_core').getIteratorMethod = function (it) {
      if (it != undefined) return it[ITERATOR] || it['@@iterator'] || Iterators[classof(it)];
    };
  }, { "./_classof": 17, "./_core": 23, "./_iterators": 56, "./_wks": 117 }], 119: [function (require, module, exports) {
    // https://github.com/benjamingr/RexExp.escape
    var $export = require('./_export'),
        $re = require('./_replacer')(/[\\^$*+?.()|[\]{}]/g, '\\$&');

    $export($export.S, 'RegExp', { escape: function escape(it) {
        return $re(it);
      } });
  }, { "./_export": 32, "./_replacer": 88 }], 120: [function (require, module, exports) {
    // 22.1.3.3 Array.prototype.copyWithin(target, start, end = this.length)
    var $export = require('./_export');

    $export($export.P, 'Array', { copyWithin: require('./_array-copy-within') });

    require('./_add-to-unscopables')('copyWithin');
  }, { "./_add-to-unscopables": 5, "./_array-copy-within": 8, "./_export": 32 }], 121: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        $every = require('./_array-methods')(4);

    $export($export.P + $export.F * !require('./_strict-method')([].every, true), 'Array', {
      // 22.1.3.5 / 15.4.4.16 Array.prototype.every(callbackfn [, thisArg])
      every: function every(callbackfn /* , thisArg */) {
        return $every(this, callbackfn, arguments[1]);
      }
    });
  }, { "./_array-methods": 12, "./_export": 32, "./_strict-method": 96 }], 122: [function (require, module, exports) {
    // 22.1.3.6 Array.prototype.fill(value, start = 0, end = this.length)
    var $export = require('./_export');

    $export($export.P, 'Array', { fill: require('./_array-fill') });

    require('./_add-to-unscopables')('fill');
  }, { "./_add-to-unscopables": 5, "./_array-fill": 9, "./_export": 32 }], 123: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        $filter = require('./_array-methods')(2);

    $export($export.P + $export.F * !require('./_strict-method')([].filter, true), 'Array', {
      // 22.1.3.7 / 15.4.4.20 Array.prototype.filter(callbackfn [, thisArg])
      filter: function filter(callbackfn /* , thisArg */) {
        return $filter(this, callbackfn, arguments[1]);
      }
    });
  }, { "./_array-methods": 12, "./_export": 32, "./_strict-method": 96 }], 124: [function (require, module, exports) {
    'use strict';
    // 22.1.3.9 Array.prototype.findIndex(predicate, thisArg = undefined)

    var $export = require('./_export'),
        $find = require('./_array-methods')(6),
        KEY = 'findIndex',
        forced = true;
    // Shouldn't skip holes
    if (KEY in []) Array(1)[KEY](function () {
      forced = false;
    });
    $export($export.P + $export.F * forced, 'Array', {
      findIndex: function findIndex(callbackfn /*, that = undefined */) {
        return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
      }
    });
    require('./_add-to-unscopables')(KEY);
  }, { "./_add-to-unscopables": 5, "./_array-methods": 12, "./_export": 32 }], 125: [function (require, module, exports) {
    'use strict';
    // 22.1.3.8 Array.prototype.find(predicate, thisArg = undefined)

    var $export = require('./_export'),
        $find = require('./_array-methods')(5),
        KEY = 'find',
        forced = true;
    // Shouldn't skip holes
    if (KEY in []) Array(1)[KEY](function () {
      forced = false;
    });
    $export($export.P + $export.F * forced, 'Array', {
      find: function find(callbackfn /*, that = undefined */) {
        return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
      }
    });
    require('./_add-to-unscopables')(KEY);
  }, { "./_add-to-unscopables": 5, "./_array-methods": 12, "./_export": 32 }], 126: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        $forEach = require('./_array-methods')(0),
        STRICT = require('./_strict-method')([].forEach, true);

    $export($export.P + $export.F * !STRICT, 'Array', {
      // 22.1.3.10 / 15.4.4.18 Array.prototype.forEach(callbackfn [, thisArg])
      forEach: function forEach(callbackfn /* , thisArg */) {
        return $forEach(this, callbackfn, arguments[1]);
      }
    });
  }, { "./_array-methods": 12, "./_export": 32, "./_strict-method": 96 }], 127: [function (require, module, exports) {
    'use strict';

    var ctx = require('./_ctx'),
        $export = require('./_export'),
        toObject = require('./_to-object'),
        call = require('./_iter-call'),
        isArrayIter = require('./_is-array-iter'),
        toLength = require('./_to-length'),
        createProperty = require('./_create-property'),
        getIterFn = require('./core.get-iterator-method');

    $export($export.S + $export.F * !require('./_iter-detect')(function (iter) {
      Array.from(iter);
    }), 'Array', {
      // 22.1.2.1 Array.from(arrayLike, mapfn = undefined, thisArg = undefined)
      from: function from(arrayLike /*, mapfn = undefined, thisArg = undefined*/) {
        var O = toObject(arrayLike),
            C = typeof this == 'function' ? this : Array,
            aLen = arguments.length,
            mapfn = aLen > 1 ? arguments[1] : undefined,
            mapping = mapfn !== undefined,
            index = 0,
            iterFn = getIterFn(O),
            length,
            result,
            step,
            iterator;
        if (mapping) mapfn = ctx(mapfn, aLen > 2 ? arguments[2] : undefined, 2);
        // if object isn't iterable or it's array with default iterator - use simple case
        if (iterFn != undefined && !(C == Array && isArrayIter(iterFn))) {
          for (iterator = iterFn.call(O), result = new C(); !(step = iterator.next()).done; index++) {
            createProperty(result, index, mapping ? call(iterator, mapfn, [step.value, index], true) : step.value);
          }
        } else {
          length = toLength(O.length);
          for (result = new C(length); length > index; index++) {
            createProperty(result, index, mapping ? mapfn(O[index], index) : O[index]);
          }
        }
        result.length = index;
        return result;
      }
    });
  }, { "./_create-property": 24, "./_ctx": 25, "./_export": 32, "./_is-array-iter": 46, "./_iter-call": 51, "./_iter-detect": 54, "./_to-length": 108, "./_to-object": 109, "./core.get-iterator-method": 118 }], 128: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        $indexOf = require('./_array-includes')(false),
        $native = [].indexOf,
        NEGATIVE_ZERO = !!$native && 1 / [1].indexOf(1, -0) < 0;

    $export($export.P + $export.F * (NEGATIVE_ZERO || !require('./_strict-method')($native)), 'Array', {
      // 22.1.3.11 / 15.4.4.14 Array.prototype.indexOf(searchElement [, fromIndex])
      indexOf: function indexOf(searchElement /*, fromIndex = 0 */) {
        return NEGATIVE_ZERO
        // convert -0 to +0
        ? $native.apply(this, arguments) || 0 : $indexOf(this, searchElement, arguments[1]);
      }
    });
  }, { "./_array-includes": 11, "./_export": 32, "./_strict-method": 96 }], 129: [function (require, module, exports) {
    // 22.1.2.2 / 15.4.3.2 Array.isArray(arg)
    var $export = require('./_export');

    $export($export.S, 'Array', { isArray: require('./_is-array') });
  }, { "./_export": 32, "./_is-array": 47 }], 130: [function (require, module, exports) {
    'use strict';

    var addToUnscopables = require('./_add-to-unscopables'),
        step = require('./_iter-step'),
        Iterators = require('./_iterators'),
        toIObject = require('./_to-iobject');

    // 22.1.3.4 Array.prototype.entries()
    // 22.1.3.13 Array.prototype.keys()
    // 22.1.3.29 Array.prototype.values()
    // 22.1.3.30 Array.prototype[@@iterator]()
    module.exports = require('./_iter-define')(Array, 'Array', function (iterated, kind) {
      this._t = toIObject(iterated); // target
      this._i = 0; // next index
      this._k = kind; // kind
      // 22.1.5.2.1 %ArrayIteratorPrototype%.next()
    }, function () {
      var O = this._t,
          kind = this._k,
          index = this._i++;
      if (!O || index >= O.length) {
        this._t = undefined;
        return step(1);
      }
      if (kind == 'keys') return step(0, index);
      if (kind == 'values') return step(0, O[index]);
      return step(0, [index, O[index]]);
    }, 'values');

    // argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
    Iterators.Arguments = Iterators.Array;

    addToUnscopables('keys');
    addToUnscopables('values');
    addToUnscopables('entries');
  }, { "./_add-to-unscopables": 5, "./_iter-define": 53, "./_iter-step": 55, "./_iterators": 56, "./_to-iobject": 107 }], 131: [function (require, module, exports) {
    'use strict';
    // 22.1.3.13 Array.prototype.join(separator)

    var $export = require('./_export'),
        toIObject = require('./_to-iobject'),
        arrayJoin = [].join;

    // fallback for not array-like strings
    $export($export.P + $export.F * (require('./_iobject') != Object || !require('./_strict-method')(arrayJoin)), 'Array', {
      join: function join(separator) {
        return arrayJoin.call(toIObject(this), separator === undefined ? ',' : separator);
      }
    });
  }, { "./_export": 32, "./_iobject": 45, "./_strict-method": 96, "./_to-iobject": 107 }], 132: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        toIObject = require('./_to-iobject'),
        toInteger = require('./_to-integer'),
        toLength = require('./_to-length'),
        $native = [].lastIndexOf,
        NEGATIVE_ZERO = !!$native && 1 / [1].lastIndexOf(1, -0) < 0;

    $export($export.P + $export.F * (NEGATIVE_ZERO || !require('./_strict-method')($native)), 'Array', {
      // 22.1.3.14 / 15.4.4.15 Array.prototype.lastIndexOf(searchElement [, fromIndex])
      lastIndexOf: function lastIndexOf(searchElement /*, fromIndex = @[*-1] */) {
        // convert -0 to +0
        if (NEGATIVE_ZERO) return $native.apply(this, arguments) || 0;
        var O = toIObject(this),
            length = toLength(O.length),
            index = length - 1;
        if (arguments.length > 1) index = Math.min(index, toInteger(arguments[1]));
        if (index < 0) index = length + index;
        for (; index >= 0; index--) {
          if (index in O) if (O[index] === searchElement) return index || 0;
        }return -1;
      }
    });
  }, { "./_export": 32, "./_strict-method": 96, "./_to-integer": 106, "./_to-iobject": 107, "./_to-length": 108 }], 133: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        $map = require('./_array-methods')(1);

    $export($export.P + $export.F * !require('./_strict-method')([].map, true), 'Array', {
      // 22.1.3.15 / 15.4.4.19 Array.prototype.map(callbackfn [, thisArg])
      map: function map(callbackfn /* , thisArg */) {
        return $map(this, callbackfn, arguments[1]);
      }
    });
  }, { "./_array-methods": 12, "./_export": 32, "./_strict-method": 96 }], 134: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        createProperty = require('./_create-property');

    // WebKit Array.of isn't generic
    $export($export.S + $export.F * require('./_fails')(function () {
      function F() {}
      return !(Array.of.call(F) instanceof F);
    }), 'Array', {
      // 22.1.2.3 Array.of( ...items)
      of: function of() /* ...args */{
        var index = 0,
            aLen = arguments.length,
            result = new (typeof this == 'function' ? this : Array)(aLen);
        while (aLen > index) {
          createProperty(result, index, arguments[index++]);
        }result.length = aLen;
        return result;
      }
    });
  }, { "./_create-property": 24, "./_export": 32, "./_fails": 34 }], 135: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        $reduce = require('./_array-reduce');

    $export($export.P + $export.F * !require('./_strict-method')([].reduceRight, true), 'Array', {
      // 22.1.3.19 / 15.4.4.22 Array.prototype.reduceRight(callbackfn [, initialValue])
      reduceRight: function reduceRight(callbackfn /* , initialValue */) {
        return $reduce(this, callbackfn, arguments.length, arguments[1], true);
      }
    });
  }, { "./_array-reduce": 13, "./_export": 32, "./_strict-method": 96 }], 136: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        $reduce = require('./_array-reduce');

    $export($export.P + $export.F * !require('./_strict-method')([].reduce, true), 'Array', {
      // 22.1.3.18 / 15.4.4.21 Array.prototype.reduce(callbackfn [, initialValue])
      reduce: function reduce(callbackfn /* , initialValue */) {
        return $reduce(this, callbackfn, arguments.length, arguments[1], false);
      }
    });
  }, { "./_array-reduce": 13, "./_export": 32, "./_strict-method": 96 }], 137: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        html = require('./_html'),
        cof = require('./_cof'),
        toIndex = require('./_to-index'),
        toLength = require('./_to-length'),
        arraySlice = [].slice;

    // fallback for not array-like ES3 strings and DOM objects
    $export($export.P + $export.F * require('./_fails')(function () {
      if (html) arraySlice.call(html);
    }), 'Array', {
      slice: function slice(begin, end) {
        var len = toLength(this.length),
            klass = cof(this);
        end = end === undefined ? len : end;
        if (klass == 'Array') return arraySlice.call(this, begin, end);
        var start = toIndex(begin, len),
            upTo = toIndex(end, len),
            size = toLength(upTo - start),
            cloned = Array(size),
            i = 0;
        for (; i < size; i++) {
          cloned[i] = klass == 'String' ? this.charAt(start + i) : this[start + i];
        }return cloned;
      }
    });
  }, { "./_cof": 18, "./_export": 32, "./_fails": 34, "./_html": 41, "./_to-index": 105, "./_to-length": 108 }], 138: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        $some = require('./_array-methods')(3);

    $export($export.P + $export.F * !require('./_strict-method')([].some, true), 'Array', {
      // 22.1.3.23 / 15.4.4.17 Array.prototype.some(callbackfn [, thisArg])
      some: function some(callbackfn /* , thisArg */) {
        return $some(this, callbackfn, arguments[1]);
      }
    });
  }, { "./_array-methods": 12, "./_export": 32, "./_strict-method": 96 }], 139: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        aFunction = require('./_a-function'),
        toObject = require('./_to-object'),
        fails = require('./_fails'),
        $sort = [].sort,
        test = [1, 2, 3];

    $export($export.P + $export.F * (fails(function () {
      // IE8-
      test.sort(undefined);
    }) || !fails(function () {
      // V8 bug
      test.sort(null);
      // Old WebKit
    }) || !require('./_strict-method')($sort)), 'Array', {
      // 22.1.3.25 Array.prototype.sort(comparefn)
      sort: function sort(comparefn) {
        return comparefn === undefined ? $sort.call(toObject(this)) : $sort.call(toObject(this), aFunction(comparefn));
      }
    });
  }, { "./_a-function": 3, "./_export": 32, "./_fails": 34, "./_strict-method": 96, "./_to-object": 109 }], 140: [function (require, module, exports) {
    require('./_set-species')('Array');
  }, { "./_set-species": 91 }], 141: [function (require, module, exports) {
    // 20.3.3.1 / 15.9.4.4 Date.now()
    var $export = require('./_export');

    $export($export.S, 'Date', { now: function now() {
        return new Date().getTime();
      } });
  }, { "./_export": 32 }], 142: [function (require, module, exports) {
    'use strict';
    // 20.3.4.36 / 15.9.5.43 Date.prototype.toISOString()

    var $export = require('./_export'),
        fails = require('./_fails'),
        getTime = Date.prototype.getTime;

    var lz = function lz(num) {
      return num > 9 ? num : '0' + num;
    };

    // PhantomJS / old WebKit has a broken implementations
    $export($export.P + $export.F * (fails(function () {
      return new Date(-5e13 - 1).toISOString() != '0385-07-25T07:06:39.999Z';
    }) || !fails(function () {
      new Date(NaN).toISOString();
    })), 'Date', {
      toISOString: function toISOString() {
        if (!isFinite(getTime.call(this))) throw RangeError('Invalid time value');
        var d = this,
            y = d.getUTCFullYear(),
            m = d.getUTCMilliseconds(),
            s = y < 0 ? '-' : y > 9999 ? '+' : '';
        return s + ('00000' + Math.abs(y)).slice(s ? -6 : -4) + '-' + lz(d.getUTCMonth() + 1) + '-' + lz(d.getUTCDate()) + 'T' + lz(d.getUTCHours()) + ':' + lz(d.getUTCMinutes()) + ':' + lz(d.getUTCSeconds()) + '.' + (m > 99 ? m : '0' + lz(m)) + 'Z';
      }
    });
  }, { "./_export": 32, "./_fails": 34 }], 143: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        toObject = require('./_to-object'),
        toPrimitive = require('./_to-primitive');

    $export($export.P + $export.F * require('./_fails')(function () {
      return new Date(NaN).toJSON() !== null || Date.prototype.toJSON.call({ toISOString: function toISOString() {
          return 1;
        } }) !== 1;
    }), 'Date', {
      toJSON: function toJSON(key) {
        var O = toObject(this),
            pv = toPrimitive(O);
        return typeof pv == 'number' && !isFinite(pv) ? null : O.toISOString();
      }
    });
  }, { "./_export": 32, "./_fails": 34, "./_to-object": 109, "./_to-primitive": 110 }], 144: [function (require, module, exports) {
    var TO_PRIMITIVE = require('./_wks')('toPrimitive'),
        proto = Date.prototype;

    if (!(TO_PRIMITIVE in proto)) require('./_hide')(proto, TO_PRIMITIVE, require('./_date-to-primitive'));
  }, { "./_date-to-primitive": 26, "./_hide": 40, "./_wks": 117 }], 145: [function (require, module, exports) {
    var DateProto = Date.prototype,
        INVALID_DATE = 'Invalid Date',
        TO_STRING = 'toString',
        $toString = DateProto[TO_STRING],
        getTime = DateProto.getTime;
    if (new Date(NaN) + '' != INVALID_DATE) {
      require('./_redefine')(DateProto, TO_STRING, function toString() {
        var value = getTime.call(this);
        return value === value ? $toString.call(this) : INVALID_DATE;
      });
    }
  }, { "./_redefine": 87 }], 146: [function (require, module, exports) {
    // 19.2.3.2 / 15.3.4.5 Function.prototype.bind(thisArg, args...)
    var $export = require('./_export');

    $export($export.P, 'Function', { bind: require('./_bind') });
  }, { "./_bind": 16, "./_export": 32 }], 147: [function (require, module, exports) {
    'use strict';

    var isObject = require('./_is-object'),
        getPrototypeOf = require('./_object-gpo'),
        HAS_INSTANCE = require('./_wks')('hasInstance'),
        FunctionProto = Function.prototype;
    // 19.2.3.6 Function.prototype[@@hasInstance](V)
    if (!(HAS_INSTANCE in FunctionProto)) require('./_object-dp').f(FunctionProto, HAS_INSTANCE, { value: function value(O) {
        if (typeof this != 'function' || !isObject(O)) return false;
        if (!isObject(this.prototype)) return O instanceof this;
        // for environment w/o native `@@hasInstance` logic enough `instanceof`, but add this:
        while (O = getPrototypeOf(O)) {
          if (this.prototype === O) return true;
        }return false;
      } });
  }, { "./_is-object": 49, "./_object-dp": 67, "./_object-gpo": 74, "./_wks": 117 }], 148: [function (require, module, exports) {
    var dP = require('./_object-dp').f,
        createDesc = require('./_property-desc'),
        has = require('./_has'),
        FProto = Function.prototype,
        nameRE = /^\s*function ([^ (]*)/,
        NAME = 'name';

    var isExtensible = Object.isExtensible || function () {
      return true;
    };

    // 19.2.4.2 name
    NAME in FProto || require('./_descriptors') && dP(FProto, NAME, {
      configurable: true,
      get: function get() {
        try {
          var that = this,
              name = ('' + that).match(nameRE)[1];
          has(that, NAME) || !isExtensible(that) || dP(that, NAME, createDesc(5, name));
          return name;
        } catch (e) {
          return '';
        }
      }
    });
  }, { "./_descriptors": 28, "./_has": 39, "./_object-dp": 67, "./_property-desc": 85 }], 149: [function (require, module, exports) {
    'use strict';

    var strong = require('./_collection-strong');

    // 23.1 Map Objects
    module.exports = require('./_collection')('Map', function (get) {
      return function Map() {
        return get(this, arguments.length > 0 ? arguments[0] : undefined);
      };
    }, {
      // 23.1.3.6 Map.prototype.get(key)
      get: function get(key) {
        var entry = strong.getEntry(this, key);
        return entry && entry.v;
      },
      // 23.1.3.9 Map.prototype.set(key, value)
      set: function set(key, value) {
        return strong.def(this, key === 0 ? 0 : key, value);
      }
    }, strong, true);
  }, { "./_collection": 22, "./_collection-strong": 19 }], 150: [function (require, module, exports) {
    // 20.2.2.3 Math.acosh(x)
    var $export = require('./_export'),
        log1p = require('./_math-log1p'),
        sqrt = Math.sqrt,
        $acosh = Math.acosh;

    $export($export.S + $export.F * !($acosh
    // V8 bug: https://code.google.com/p/v8/issues/detail?id=3509
    && Math.floor($acosh(Number.MAX_VALUE)) == 710
    // Tor Browser bug: Math.acosh(Infinity) -> NaN 
    && $acosh(Infinity) == Infinity), 'Math', {
      acosh: function acosh(x) {
        return (x = +x) < 1 ? NaN : x > 94906265.62425156 ? Math.log(x) + Math.LN2 : log1p(x - 1 + sqrt(x - 1) * sqrt(x + 1));
      }
    });
  }, { "./_export": 32, "./_math-log1p": 60 }], 151: [function (require, module, exports) {
    // 20.2.2.5 Math.asinh(x)
    var $export = require('./_export'),
        $asinh = Math.asinh;

    function asinh(x) {
      return !isFinite(x = +x) || x == 0 ? x : x < 0 ? -asinh(-x) : Math.log(x + Math.sqrt(x * x + 1));
    }

    // Tor Browser bug: Math.asinh(0) -> -0 
    $export($export.S + $export.F * !($asinh && 1 / $asinh(0) > 0), 'Math', { asinh: asinh });
  }, { "./_export": 32 }], 152: [function (require, module, exports) {
    // 20.2.2.7 Math.atanh(x)
    var $export = require('./_export'),
        $atanh = Math.atanh;

    // Tor Browser bug: Math.atanh(-0) -> 0 
    $export($export.S + $export.F * !($atanh && 1 / $atanh(-0) < 0), 'Math', {
      atanh: function atanh(x) {
        return (x = +x) == 0 ? x : Math.log((1 + x) / (1 - x)) / 2;
      }
    });
  }, { "./_export": 32 }], 153: [function (require, module, exports) {
    // 20.2.2.9 Math.cbrt(x)
    var $export = require('./_export'),
        sign = require('./_math-sign');

    $export($export.S, 'Math', {
      cbrt: function cbrt(x) {
        return sign(x = +x) * Math.pow(Math.abs(x), 1 / 3);
      }
    });
  }, { "./_export": 32, "./_math-sign": 61 }], 154: [function (require, module, exports) {
    // 20.2.2.11 Math.clz32(x)
    var $export = require('./_export');

    $export($export.S, 'Math', {
      clz32: function clz32(x) {
        return (x >>>= 0) ? 31 - Math.floor(Math.log(x + 0.5) * Math.LOG2E) : 32;
      }
    });
  }, { "./_export": 32 }], 155: [function (require, module, exports) {
    // 20.2.2.12 Math.cosh(x)
    var $export = require('./_export'),
        exp = Math.exp;

    $export($export.S, 'Math', {
      cosh: function cosh(x) {
        return (exp(x = +x) + exp(-x)) / 2;
      }
    });
  }, { "./_export": 32 }], 156: [function (require, module, exports) {
    // 20.2.2.14 Math.expm1(x)
    var $export = require('./_export'),
        $expm1 = require('./_math-expm1');

    $export($export.S + $export.F * ($expm1 != Math.expm1), 'Math', { expm1: $expm1 });
  }, { "./_export": 32, "./_math-expm1": 59 }], 157: [function (require, module, exports) {
    // 20.2.2.16 Math.fround(x)
    var $export = require('./_export'),
        sign = require('./_math-sign'),
        pow = Math.pow,
        EPSILON = pow(2, -52),
        EPSILON32 = pow(2, -23),
        MAX32 = pow(2, 127) * (2 - EPSILON32),
        MIN32 = pow(2, -126);

    var roundTiesToEven = function roundTiesToEven(n) {
      return n + 1 / EPSILON - 1 / EPSILON;
    };

    $export($export.S, 'Math', {
      fround: function fround(x) {
        var $abs = Math.abs(x),
            $sign = sign(x),
            a,
            result;
        if ($abs < MIN32) return $sign * roundTiesToEven($abs / MIN32 / EPSILON32) * MIN32 * EPSILON32;
        a = (1 + EPSILON32 / EPSILON) * $abs;
        result = a - (a - $abs);
        if (result > MAX32 || result != result) return $sign * Infinity;
        return $sign * result;
      }
    });
  }, { "./_export": 32, "./_math-sign": 61 }], 158: [function (require, module, exports) {
    // 20.2.2.17 Math.hypot([value1[, value2[, … ]]])
    var $export = require('./_export'),
        abs = Math.abs;

    $export($export.S, 'Math', {
      hypot: function hypot(value1, value2) {
        // eslint-disable-line no-unused-vars
        var sum = 0,
            i = 0,
            aLen = arguments.length,
            larg = 0,
            arg,
            div;
        while (i < aLen) {
          arg = abs(arguments[i++]);
          if (larg < arg) {
            div = larg / arg;
            sum = sum * div * div + 1;
            larg = arg;
          } else if (arg > 0) {
            div = arg / larg;
            sum += div * div;
          } else sum += arg;
        }
        return larg === Infinity ? Infinity : larg * Math.sqrt(sum);
      }
    });
  }, { "./_export": 32 }], 159: [function (require, module, exports) {
    // 20.2.2.18 Math.imul(x, y)
    var $export = require('./_export'),
        $imul = Math.imul;

    // some WebKit versions fails with big numbers, some has wrong arity
    $export($export.S + $export.F * require('./_fails')(function () {
      return $imul(0xffffffff, 5) != -5 || $imul.length != 2;
    }), 'Math', {
      imul: function imul(x, y) {
        var UINT16 = 0xffff,
            xn = +x,
            yn = +y,
            xl = UINT16 & xn,
            yl = UINT16 & yn;
        return 0 | xl * yl + ((UINT16 & xn >>> 16) * yl + xl * (UINT16 & yn >>> 16) << 16 >>> 0);
      }
    });
  }, { "./_export": 32, "./_fails": 34 }], 160: [function (require, module, exports) {
    // 20.2.2.21 Math.log10(x)
    var $export = require('./_export');

    $export($export.S, 'Math', {
      log10: function log10(x) {
        return Math.log(x) / Math.LN10;
      }
    });
  }, { "./_export": 32 }], 161: [function (require, module, exports) {
    // 20.2.2.20 Math.log1p(x)
    var $export = require('./_export');

    $export($export.S, 'Math', { log1p: require('./_math-log1p') });
  }, { "./_export": 32, "./_math-log1p": 60 }], 162: [function (require, module, exports) {
    // 20.2.2.22 Math.log2(x)
    var $export = require('./_export');

    $export($export.S, 'Math', {
      log2: function log2(x) {
        return Math.log(x) / Math.LN2;
      }
    });
  }, { "./_export": 32 }], 163: [function (require, module, exports) {
    // 20.2.2.28 Math.sign(x)
    var $export = require('./_export');

    $export($export.S, 'Math', { sign: require('./_math-sign') });
  }, { "./_export": 32, "./_math-sign": 61 }], 164: [function (require, module, exports) {
    // 20.2.2.30 Math.sinh(x)
    var $export = require('./_export'),
        expm1 = require('./_math-expm1'),
        exp = Math.exp;

    // V8 near Chromium 38 has a problem with very small numbers
    $export($export.S + $export.F * require('./_fails')(function () {
      return !Math.sinh(-2e-17) != -2e-17;
    }), 'Math', {
      sinh: function sinh(x) {
        return Math.abs(x = +x) < 1 ? (expm1(x) - expm1(-x)) / 2 : (exp(x - 1) - exp(-x - 1)) * (Math.E / 2);
      }
    });
  }, { "./_export": 32, "./_fails": 34, "./_math-expm1": 59 }], 165: [function (require, module, exports) {
    // 20.2.2.33 Math.tanh(x)
    var $export = require('./_export'),
        expm1 = require('./_math-expm1'),
        exp = Math.exp;

    $export($export.S, 'Math', {
      tanh: function tanh(x) {
        var a = expm1(x = +x),
            b = expm1(-x);
        return a == Infinity ? 1 : b == Infinity ? -1 : (a - b) / (exp(x) + exp(-x));
      }
    });
  }, { "./_export": 32, "./_math-expm1": 59 }], 166: [function (require, module, exports) {
    // 20.2.2.34 Math.trunc(x)
    var $export = require('./_export');

    $export($export.S, 'Math', {
      trunc: function trunc(it) {
        return (it > 0 ? Math.floor : Math.ceil)(it);
      }
    });
  }, { "./_export": 32 }], 167: [function (require, module, exports) {
    'use strict';

    var global = require('./_global'),
        has = require('./_has'),
        cof = require('./_cof'),
        inheritIfRequired = require('./_inherit-if-required'),
        toPrimitive = require('./_to-primitive'),
        fails = require('./_fails'),
        gOPN = require('./_object-gopn').f,
        gOPD = require('./_object-gopd').f,
        dP = require('./_object-dp').f,
        $trim = require('./_string-trim').trim,
        NUMBER = 'Number',
        $Number = global[NUMBER],
        Base = $Number,
        proto = $Number.prototype
    // Opera ~12 has broken Object#toString
    ,
        BROKEN_COF = cof(require('./_object-create')(proto)) == NUMBER,
        TRIM = 'trim' in String.prototype;

    // 7.1.3 ToNumber(argument)
    var toNumber = function toNumber(argument) {
      var it = toPrimitive(argument, false);
      if (typeof it == 'string' && it.length > 2) {
        it = TRIM ? it.trim() : $trim(it, 3);
        var first = it.charCodeAt(0),
            third,
            radix,
            maxCode;
        if (first === 43 || first === 45) {
          third = it.charCodeAt(2);
          if (third === 88 || third === 120) return NaN; // Number('+0x1') should be NaN, old V8 fix
        } else if (first === 48) {
          switch (it.charCodeAt(1)) {
            case 66:case 98:
              radix = 2;maxCode = 49;break; // fast equal /^0b[01]+$/i
            case 79:case 111:
              radix = 8;maxCode = 55;break; // fast equal /^0o[0-7]+$/i
            default:
              return +it;
          }
          for (var digits = it.slice(2), i = 0, l = digits.length, code; i < l; i++) {
            code = digits.charCodeAt(i);
            // parseInt parses a string to a first unavailable symbol
            // but ToNumber should return NaN if a string contains unavailable symbols
            if (code < 48 || code > maxCode) return NaN;
          }return parseInt(digits, radix);
        }
      }return +it;
    };

    if (!$Number(' 0o1') || !$Number('0b1') || $Number('+0x1')) {
      $Number = function Number(value) {
        var it = arguments.length < 1 ? 0 : value,
            that = this;
        return that instanceof $Number
        // check on 1..constructor(foo) case
        && (BROKEN_COF ? fails(function () {
          proto.valueOf.call(that);
        }) : cof(that) != NUMBER) ? inheritIfRequired(new Base(toNumber(it)), that, $Number) : toNumber(it);
      };
      for (var keys = require('./_descriptors') ? gOPN(Base) : (
      // ES3:
      'MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,' +
      // ES6 (in case, if modules with ES6 Number statics required before):
      'EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,' + 'MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger').split(','), j = 0, key; keys.length > j; j++) {
        if (has(Base, key = keys[j]) && !has($Number, key)) {
          dP($Number, key, gOPD(Base, key));
        }
      }
      $Number.prototype = proto;
      proto.constructor = $Number;
      require('./_redefine')(global, NUMBER, $Number);
    }
  }, { "./_cof": 18, "./_descriptors": 28, "./_fails": 34, "./_global": 38, "./_has": 39, "./_inherit-if-required": 43, "./_object-create": 66, "./_object-dp": 67, "./_object-gopd": 70, "./_object-gopn": 72, "./_redefine": 87, "./_string-trim": 102, "./_to-primitive": 110 }], 168: [function (require, module, exports) {
    // 20.1.2.1 Number.EPSILON
    var $export = require('./_export');

    $export($export.S, 'Number', { EPSILON: Math.pow(2, -52) });
  }, { "./_export": 32 }], 169: [function (require, module, exports) {
    // 20.1.2.2 Number.isFinite(number)
    var $export = require('./_export'),
        _isFinite = require('./_global').isFinite;

    $export($export.S, 'Number', {
      isFinite: function isFinite(it) {
        return typeof it == 'number' && _isFinite(it);
      }
    });
  }, { "./_export": 32, "./_global": 38 }], 170: [function (require, module, exports) {
    // 20.1.2.3 Number.isInteger(number)
    var $export = require('./_export');

    $export($export.S, 'Number', { isInteger: require('./_is-integer') });
  }, { "./_export": 32, "./_is-integer": 48 }], 171: [function (require, module, exports) {
    // 20.1.2.4 Number.isNaN(number)
    var $export = require('./_export');

    $export($export.S, 'Number', {
      isNaN: function isNaN(number) {
        return number != number;
      }
    });
  }, { "./_export": 32 }], 172: [function (require, module, exports) {
    // 20.1.2.5 Number.isSafeInteger(number)
    var $export = require('./_export'),
        isInteger = require('./_is-integer'),
        abs = Math.abs;

    $export($export.S, 'Number', {
      isSafeInteger: function isSafeInteger(number) {
        return isInteger(number) && abs(number) <= 0x1fffffffffffff;
      }
    });
  }, { "./_export": 32, "./_is-integer": 48 }], 173: [function (require, module, exports) {
    // 20.1.2.6 Number.MAX_SAFE_INTEGER
    var $export = require('./_export');

    $export($export.S, 'Number', { MAX_SAFE_INTEGER: 0x1fffffffffffff });
  }, { "./_export": 32 }], 174: [function (require, module, exports) {
    // 20.1.2.10 Number.MIN_SAFE_INTEGER
    var $export = require('./_export');

    $export($export.S, 'Number', { MIN_SAFE_INTEGER: -0x1fffffffffffff });
  }, { "./_export": 32 }], 175: [function (require, module, exports) {
    var $export = require('./_export'),
        $parseFloat = require('./_parse-float');
    // 20.1.2.12 Number.parseFloat(string)
    $export($export.S + $export.F * (Number.parseFloat != $parseFloat), 'Number', { parseFloat: $parseFloat });
  }, { "./_export": 32, "./_parse-float": 81 }], 176: [function (require, module, exports) {
    var $export = require('./_export'),
        $parseInt = require('./_parse-int');
    // 20.1.2.13 Number.parseInt(string, radix)
    $export($export.S + $export.F * (Number.parseInt != $parseInt), 'Number', { parseInt: $parseInt });
  }, { "./_export": 32, "./_parse-int": 82 }], 177: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        toInteger = require('./_to-integer'),
        aNumberValue = require('./_a-number-value'),
        repeat = require('./_string-repeat'),
        $toFixed = 1..toFixed,
        floor = Math.floor,
        data = [0, 0, 0, 0, 0, 0],
        ERROR = 'Number.toFixed: incorrect invocation!',
        ZERO = '0';

    var multiply = function multiply(n, c) {
      var i = -1,
          c2 = c;
      while (++i < 6) {
        c2 += n * data[i];
        data[i] = c2 % 1e7;
        c2 = floor(c2 / 1e7);
      }
    };
    var divide = function divide(n) {
      var i = 6,
          c = 0;
      while (--i >= 0) {
        c += data[i];
        data[i] = floor(c / n);
        c = c % n * 1e7;
      }
    };
    var numToString = function numToString() {
      var i = 6,
          s = '';
      while (--i >= 0) {
        if (s !== '' || i === 0 || data[i] !== 0) {
          var t = String(data[i]);
          s = s === '' ? t : s + repeat.call(ZERO, 7 - t.length) + t;
        }
      }return s;
    };
    var pow = function pow(x, n, acc) {
      return n === 0 ? acc : n % 2 === 1 ? pow(x, n - 1, acc * x) : pow(x * x, n / 2, acc);
    };
    var log = function log(x) {
      var n = 0,
          x2 = x;
      while (x2 >= 4096) {
        n += 12;
        x2 /= 4096;
      }
      while (x2 >= 2) {
        n += 1;
        x2 /= 2;
      }return n;
    };

    $export($export.P + $export.F * (!!$toFixed && (0.00008.toFixed(3) !== '0.000' || 0.9.toFixed(0) !== '1' || 1.255.toFixed(2) !== '1.25' || 1000000000000000128..toFixed(0) !== '1000000000000000128') || !require('./_fails')(function () {
      // V8 ~ Android 4.3-
      $toFixed.call({});
    })), 'Number', {
      toFixed: function toFixed(fractionDigits) {
        var x = aNumberValue(this, ERROR),
            f = toInteger(fractionDigits),
            s = '',
            m = ZERO,
            e,
            z,
            j,
            k;
        if (f < 0 || f > 20) throw RangeError(ERROR);
        if (x != x) return 'NaN';
        if (x <= -1e21 || x >= 1e21) return String(x);
        if (x < 0) {
          s = '-';
          x = -x;
        }
        if (x > 1e-21) {
          e = log(x * pow(2, 69, 1)) - 69;
          z = e < 0 ? x * pow(2, -e, 1) : x / pow(2, e, 1);
          z *= 0x10000000000000;
          e = 52 - e;
          if (e > 0) {
            multiply(0, z);
            j = f;
            while (j >= 7) {
              multiply(1e7, 0);
              j -= 7;
            }
            multiply(pow(10, j, 1), 0);
            j = e - 1;
            while (j >= 23) {
              divide(1 << 23);
              j -= 23;
            }
            divide(1 << j);
            multiply(1, 1);
            divide(2);
            m = numToString();
          } else {
            multiply(0, z);
            multiply(1 << -e, 0);
            m = numToString() + repeat.call(ZERO, f);
          }
        }
        if (f > 0) {
          k = m.length;
          m = s + (k <= f ? '0.' + repeat.call(ZERO, f - k) + m : m.slice(0, k - f) + '.' + m.slice(k - f));
        } else {
          m = s + m;
        }return m;
      }
    });
  }, { "./_a-number-value": 4, "./_export": 32, "./_fails": 34, "./_string-repeat": 101, "./_to-integer": 106 }], 178: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        $fails = require('./_fails'),
        aNumberValue = require('./_a-number-value'),
        $toPrecision = 1..toPrecision;

    $export($export.P + $export.F * ($fails(function () {
      // IE7-
      return $toPrecision.call(1, undefined) !== '1';
    }) || !$fails(function () {
      // V8 ~ Android 4.3-
      $toPrecision.call({});
    })), 'Number', {
      toPrecision: function toPrecision(precision) {
        var that = aNumberValue(this, 'Number#toPrecision: incorrect invocation!');
        return precision === undefined ? $toPrecision.call(that) : $toPrecision.call(that, precision);
      }
    });
  }, { "./_a-number-value": 4, "./_export": 32, "./_fails": 34 }], 179: [function (require, module, exports) {
    // 19.1.3.1 Object.assign(target, source)
    var $export = require('./_export');

    $export($export.S + $export.F, 'Object', { assign: require('./_object-assign') });
  }, { "./_export": 32, "./_object-assign": 65 }], 180: [function (require, module, exports) {
    var $export = require('./_export');
    // 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
    $export($export.S, 'Object', { create: require('./_object-create') });
  }, { "./_export": 32, "./_object-create": 66 }], 181: [function (require, module, exports) {
    var $export = require('./_export');
    // 19.1.2.3 / 15.2.3.7 Object.defineProperties(O, Properties)
    $export($export.S + $export.F * !require('./_descriptors'), 'Object', { defineProperties: require('./_object-dps') });
  }, { "./_descriptors": 28, "./_export": 32, "./_object-dps": 68 }], 182: [function (require, module, exports) {
    var $export = require('./_export');
    // 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
    $export($export.S + $export.F * !require('./_descriptors'), 'Object', { defineProperty: require('./_object-dp').f });
  }, { "./_descriptors": 28, "./_export": 32, "./_object-dp": 67 }], 183: [function (require, module, exports) {
    // 19.1.2.5 Object.freeze(O)
    var isObject = require('./_is-object'),
        meta = require('./_meta').onFreeze;

    require('./_object-sap')('freeze', function ($freeze) {
      return function freeze(it) {
        return $freeze && isObject(it) ? $freeze(meta(it)) : it;
      };
    });
  }, { "./_is-object": 49, "./_meta": 62, "./_object-sap": 78 }], 184: [function (require, module, exports) {
    // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
    var toIObject = require('./_to-iobject'),
        $getOwnPropertyDescriptor = require('./_object-gopd').f;

    require('./_object-sap')('getOwnPropertyDescriptor', function () {
      return function getOwnPropertyDescriptor(it, key) {
        return $getOwnPropertyDescriptor(toIObject(it), key);
      };
    });
  }, { "./_object-gopd": 70, "./_object-sap": 78, "./_to-iobject": 107 }], 185: [function (require, module, exports) {
    // 19.1.2.7 Object.getOwnPropertyNames(O)
    require('./_object-sap')('getOwnPropertyNames', function () {
      return require('./_object-gopn-ext').f;
    });
  }, { "./_object-gopn-ext": 71, "./_object-sap": 78 }], 186: [function (require, module, exports) {
    // 19.1.2.9 Object.getPrototypeOf(O)
    var toObject = require('./_to-object'),
        $getPrototypeOf = require('./_object-gpo');

    require('./_object-sap')('getPrototypeOf', function () {
      return function getPrototypeOf(it) {
        return $getPrototypeOf(toObject(it));
      };
    });
  }, { "./_object-gpo": 74, "./_object-sap": 78, "./_to-object": 109 }], 187: [function (require, module, exports) {
    // 19.1.2.11 Object.isExtensible(O)
    var isObject = require('./_is-object');

    require('./_object-sap')('isExtensible', function ($isExtensible) {
      return function isExtensible(it) {
        return isObject(it) ? $isExtensible ? $isExtensible(it) : true : false;
      };
    });
  }, { "./_is-object": 49, "./_object-sap": 78 }], 188: [function (require, module, exports) {
    // 19.1.2.12 Object.isFrozen(O)
    var isObject = require('./_is-object');

    require('./_object-sap')('isFrozen', function ($isFrozen) {
      return function isFrozen(it) {
        return isObject(it) ? $isFrozen ? $isFrozen(it) : false : true;
      };
    });
  }, { "./_is-object": 49, "./_object-sap": 78 }], 189: [function (require, module, exports) {
    // 19.1.2.13 Object.isSealed(O)
    var isObject = require('./_is-object');

    require('./_object-sap')('isSealed', function ($isSealed) {
      return function isSealed(it) {
        return isObject(it) ? $isSealed ? $isSealed(it) : false : true;
      };
    });
  }, { "./_is-object": 49, "./_object-sap": 78 }], 190: [function (require, module, exports) {
    // 19.1.3.10 Object.is(value1, value2)
    var $export = require('./_export');
    $export($export.S, 'Object', { is: require('./_same-value') });
  }, { "./_export": 32, "./_same-value": 89 }], 191: [function (require, module, exports) {
    // 19.1.2.14 Object.keys(O)
    var toObject = require('./_to-object'),
        $keys = require('./_object-keys');

    require('./_object-sap')('keys', function () {
      return function keys(it) {
        return $keys(toObject(it));
      };
    });
  }, { "./_object-keys": 76, "./_object-sap": 78, "./_to-object": 109 }], 192: [function (require, module, exports) {
    // 19.1.2.15 Object.preventExtensions(O)
    var isObject = require('./_is-object'),
        meta = require('./_meta').onFreeze;

    require('./_object-sap')('preventExtensions', function ($preventExtensions) {
      return function preventExtensions(it) {
        return $preventExtensions && isObject(it) ? $preventExtensions(meta(it)) : it;
      };
    });
  }, { "./_is-object": 49, "./_meta": 62, "./_object-sap": 78 }], 193: [function (require, module, exports) {
    // 19.1.2.17 Object.seal(O)
    var isObject = require('./_is-object'),
        meta = require('./_meta').onFreeze;

    require('./_object-sap')('seal', function ($seal) {
      return function seal(it) {
        return $seal && isObject(it) ? $seal(meta(it)) : it;
      };
    });
  }, { "./_is-object": 49, "./_meta": 62, "./_object-sap": 78 }], 194: [function (require, module, exports) {
    // 19.1.3.19 Object.setPrototypeOf(O, proto)
    var $export = require('./_export');
    $export($export.S, 'Object', { setPrototypeOf: require('./_set-proto').set });
  }, { "./_export": 32, "./_set-proto": 90 }], 195: [function (require, module, exports) {
    'use strict';
    // 19.1.3.6 Object.prototype.toString()

    var classof = require('./_classof'),
        test = {};
    test[require('./_wks')('toStringTag')] = 'z';
    if (test + '' != '[object z]') {
      require('./_redefine')(Object.prototype, 'toString', function toString() {
        return '[object ' + classof(this) + ']';
      }, true);
    }
  }, { "./_classof": 17, "./_redefine": 87, "./_wks": 117 }], 196: [function (require, module, exports) {
    var $export = require('./_export'),
        $parseFloat = require('./_parse-float');
    // 18.2.4 parseFloat(string)
    $export($export.G + $export.F * (parseFloat != $parseFloat), { parseFloat: $parseFloat });
  }, { "./_export": 32, "./_parse-float": 81 }], 197: [function (require, module, exports) {
    var $export = require('./_export'),
        $parseInt = require('./_parse-int');
    // 18.2.5 parseInt(string, radix)
    $export($export.G + $export.F * (parseInt != $parseInt), { parseInt: $parseInt });
  }, { "./_export": 32, "./_parse-int": 82 }], 198: [function (require, module, exports) {
    'use strict';

    var LIBRARY = require('./_library'),
        global = require('./_global'),
        ctx = require('./_ctx'),
        classof = require('./_classof'),
        $export = require('./_export'),
        isObject = require('./_is-object'),
        aFunction = require('./_a-function'),
        anInstance = require('./_an-instance'),
        forOf = require('./_for-of'),
        speciesConstructor = require('./_species-constructor'),
        task = require('./_task').set,
        microtask = require('./_microtask')(),
        PROMISE = 'Promise',
        TypeError = global.TypeError,
        process = global.process,
        $Promise = global[PROMISE],
        process = global.process,
        isNode = classof(process) == 'process',
        empty = function empty() {/* empty */},
        Internal,
        GenericPromiseCapability,
        Wrapper;

    var USE_NATIVE = !!function () {
      try {
        // correct subclassing with @@species support
        var promise = $Promise.resolve(1),
            FakePromise = (promise.constructor = {})[require('./_wks')('species')] = function (exec) {
          exec(empty, empty);
        };
        // unhandled rejections tracking support, NodeJS Promise without it fails @@species test
        return (isNode || typeof PromiseRejectionEvent == 'function') && promise.then(empty) instanceof FakePromise;
      } catch (e) {/* empty */}
    }();

    // helpers
    var sameConstructor = function sameConstructor(a, b) {
      // with library wrapper special case
      return a === b || a === $Promise && b === Wrapper;
    };
    var isThenable = function isThenable(it) {
      var then;
      return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
    };
    var newPromiseCapability = function newPromiseCapability(C) {
      return sameConstructor($Promise, C) ? new PromiseCapability(C) : new GenericPromiseCapability(C);
    };
    var PromiseCapability = GenericPromiseCapability = function GenericPromiseCapability(C) {
      var resolve, reject;
      this.promise = new C(function ($$resolve, $$reject) {
        if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
        resolve = $$resolve;
        reject = $$reject;
      });
      this.resolve = aFunction(resolve);
      this.reject = aFunction(reject);
    };
    var perform = function perform(exec) {
      try {
        exec();
      } catch (e) {
        return { error: e };
      }
    };
    var notify = function notify(promise, isReject) {
      if (promise._n) return;
      promise._n = true;
      var chain = promise._c;
      microtask(function () {
        var value = promise._v,
            ok = promise._s == 1,
            i = 0;
        var run = function run(reaction) {
          var handler = ok ? reaction.ok : reaction.fail,
              resolve = reaction.resolve,
              reject = reaction.reject,
              domain = reaction.domain,
              result,
              then;
          try {
            if (handler) {
              if (!ok) {
                if (promise._h == 2) onHandleUnhandled(promise);
                promise._h = 1;
              }
              if (handler === true) result = value;else {
                if (domain) domain.enter();
                result = handler(value);
                if (domain) domain.exit();
              }
              if (result === reaction.promise) {
                reject(TypeError('Promise-chain cycle'));
              } else if (then = isThenable(result)) {
                then.call(result, resolve, reject);
              } else resolve(result);
            } else reject(value);
          } catch (e) {
            reject(e);
          }
        };
        while (chain.length > i) {
          run(chain[i++]);
        } // variable length - can't use forEach
        promise._c = [];
        promise._n = false;
        if (isReject && !promise._h) onUnhandled(promise);
      });
    };
    var onUnhandled = function onUnhandled(promise) {
      task.call(global, function () {
        var value = promise._v,
            abrupt,
            handler,
            console;
        if (isUnhandled(promise)) {
          abrupt = perform(function () {
            if (isNode) {
              process.emit('unhandledRejection', value, promise);
            } else if (handler = global.onunhandledrejection) {
              handler({ promise: promise, reason: value });
            } else if ((console = global.console) && console.error) {
              console.error('Unhandled promise rejection', value);
            }
          });
          // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
          promise._h = isNode || isUnhandled(promise) ? 2 : 1;
        }promise._a = undefined;
        if (abrupt) throw abrupt.error;
      });
    };
    var isUnhandled = function isUnhandled(promise) {
      if (promise._h == 1) return false;
      var chain = promise._a || promise._c,
          i = 0,
          reaction;
      while (chain.length > i) {
        reaction = chain[i++];
        if (reaction.fail || !isUnhandled(reaction.promise)) return false;
      }return true;
    };
    var onHandleUnhandled = function onHandleUnhandled(promise) {
      task.call(global, function () {
        var handler;
        if (isNode) {
          process.emit('rejectionHandled', promise);
        } else if (handler = global.onrejectionhandled) {
          handler({ promise: promise, reason: promise._v });
        }
      });
    };
    var $reject = function $reject(value) {
      var promise = this;
      if (promise._d) return;
      promise._d = true;
      promise = promise._w || promise; // unwrap
      promise._v = value;
      promise._s = 2;
      if (!promise._a) promise._a = promise._c.slice();
      notify(promise, true);
    };
    var $resolve = function $resolve(value) {
      var promise = this,
          then;
      if (promise._d) return;
      promise._d = true;
      promise = promise._w || promise; // unwrap
      try {
        if (promise === value) throw TypeError("Promise can't be resolved itself");
        if (then = isThenable(value)) {
          microtask(function () {
            var wrapper = { _w: promise, _d: false }; // wrap
            try {
              then.call(value, ctx($resolve, wrapper, 1), ctx($reject, wrapper, 1));
            } catch (e) {
              $reject.call(wrapper, e);
            }
          });
        } else {
          promise._v = value;
          promise._s = 1;
          notify(promise, false);
        }
      } catch (e) {
        $reject.call({ _w: promise, _d: false }, e); // wrap
      }
    };

    // constructor polyfill
    if (!USE_NATIVE) {
      // 25.4.3.1 Promise(executor)
      $Promise = function Promise(executor) {
        anInstance(this, $Promise, PROMISE, '_h');
        aFunction(executor);
        Internal.call(this);
        try {
          executor(ctx($resolve, this, 1), ctx($reject, this, 1));
        } catch (err) {
          $reject.call(this, err);
        }
      };
      Internal = function Promise(executor) {
        this._c = []; // <- awaiting reactions
        this._a = undefined; // <- checked in isUnhandled reactions
        this._s = 0; // <- state
        this._d = false; // <- done
        this._v = undefined; // <- value
        this._h = 0; // <- rejection state, 0 - default, 1 - handled, 2 - unhandled
        this._n = false; // <- notify
      };
      Internal.prototype = require('./_redefine-all')($Promise.prototype, {
        // 25.4.5.3 Promise.prototype.then(onFulfilled, onRejected)
        then: function then(onFulfilled, onRejected) {
          var reaction = newPromiseCapability(speciesConstructor(this, $Promise));
          reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
          reaction.fail = typeof onRejected == 'function' && onRejected;
          reaction.domain = isNode ? process.domain : undefined;
          this._c.push(reaction);
          if (this._a) this._a.push(reaction);
          if (this._s) notify(this, false);
          return reaction.promise;
        },
        // 25.4.5.1 Promise.prototype.catch(onRejected)
        'catch': function _catch(onRejected) {
          return this.then(undefined, onRejected);
        }
      });
      PromiseCapability = function PromiseCapability() {
        var promise = new Internal();
        this.promise = promise;
        this.resolve = ctx($resolve, promise, 1);
        this.reject = ctx($reject, promise, 1);
      };
    }

    $export($export.G + $export.W + $export.F * !USE_NATIVE, { Promise: $Promise });
    require('./_set-to-string-tag')($Promise, PROMISE);
    require('./_set-species')(PROMISE);
    Wrapper = require('./_core')[PROMISE];

    // statics
    $export($export.S + $export.F * !USE_NATIVE, PROMISE, {
      // 25.4.4.5 Promise.reject(r)
      reject: function reject(r) {
        var capability = newPromiseCapability(this),
            $$reject = capability.reject;
        $$reject(r);
        return capability.promise;
      }
    });
    $export($export.S + $export.F * (LIBRARY || !USE_NATIVE), PROMISE, {
      // 25.4.4.6 Promise.resolve(x)
      resolve: function resolve(x) {
        // instanceof instead of internal slot check because we should fix it without replacement native Promise core
        if (x instanceof $Promise && sameConstructor(x.constructor, this)) return x;
        var capability = newPromiseCapability(this),
            $$resolve = capability.resolve;
        $$resolve(x);
        return capability.promise;
      }
    });
    $export($export.S + $export.F * !(USE_NATIVE && require('./_iter-detect')(function (iter) {
      $Promise.all(iter)['catch'](empty);
    })), PROMISE, {
      // 25.4.4.1 Promise.all(iterable)
      all: function all(iterable) {
        var C = this,
            capability = newPromiseCapability(C),
            resolve = capability.resolve,
            reject = capability.reject;
        var abrupt = perform(function () {
          var values = [],
              index = 0,
              remaining = 1;
          forOf(iterable, false, function (promise) {
            var $index = index++,
                alreadyCalled = false;
            values.push(undefined);
            remaining++;
            C.resolve(promise).then(function (value) {
              if (alreadyCalled) return;
              alreadyCalled = true;
              values[$index] = value;
              --remaining || resolve(values);
            }, reject);
          });
          --remaining || resolve(values);
        });
        if (abrupt) reject(abrupt.error);
        return capability.promise;
      },
      // 25.4.4.4 Promise.race(iterable)
      race: function race(iterable) {
        var C = this,
            capability = newPromiseCapability(C),
            reject = capability.reject;
        var abrupt = perform(function () {
          forOf(iterable, false, function (promise) {
            C.resolve(promise).then(capability.resolve, reject);
          });
        });
        if (abrupt) reject(abrupt.error);
        return capability.promise;
      }
    });
  }, { "./_a-function": 3, "./_an-instance": 6, "./_classof": 17, "./_core": 23, "./_ctx": 25, "./_export": 32, "./_for-of": 37, "./_global": 38, "./_is-object": 49, "./_iter-detect": 54, "./_library": 58, "./_microtask": 64, "./_redefine-all": 86, "./_set-species": 91, "./_set-to-string-tag": 92, "./_species-constructor": 95, "./_task": 104, "./_wks": 117 }], 199: [function (require, module, exports) {
    // 26.1.1 Reflect.apply(target, thisArgument, argumentsList)
    var $export = require('./_export'),
        aFunction = require('./_a-function'),
        anObject = require('./_an-object'),
        rApply = (require('./_global').Reflect || {}).apply,
        fApply = Function.apply;
    // MS Edge argumentsList argument is optional
    $export($export.S + $export.F * !require('./_fails')(function () {
      rApply(function () {});
    }), 'Reflect', {
      apply: function apply(target, thisArgument, argumentsList) {
        var T = aFunction(target),
            L = anObject(argumentsList);
        return rApply ? rApply(T, thisArgument, L) : fApply.call(T, thisArgument, L);
      }
    });
  }, { "./_a-function": 3, "./_an-object": 7, "./_export": 32, "./_fails": 34, "./_global": 38 }], 200: [function (require, module, exports) {
    // 26.1.2 Reflect.construct(target, argumentsList [, newTarget])
    var $export = require('./_export'),
        create = require('./_object-create'),
        aFunction = require('./_a-function'),
        anObject = require('./_an-object'),
        isObject = require('./_is-object'),
        fails = require('./_fails'),
        bind = require('./_bind'),
        rConstruct = (require('./_global').Reflect || {}).construct;

    // MS Edge supports only 2 arguments and argumentsList argument is optional
    // FF Nightly sets third argument as `new.target`, but does not create `this` from it
    var NEW_TARGET_BUG = fails(function () {
      function F() {}
      return !(rConstruct(function () {}, [], F) instanceof F);
    });
    var ARGS_BUG = !fails(function () {
      rConstruct(function () {});
    });

    $export($export.S + $export.F * (NEW_TARGET_BUG || ARGS_BUG), 'Reflect', {
      construct: function construct(Target, args /*, newTarget*/) {
        aFunction(Target);
        anObject(args);
        var newTarget = arguments.length < 3 ? Target : aFunction(arguments[2]);
        if (ARGS_BUG && !NEW_TARGET_BUG) return rConstruct(Target, args, newTarget);
        if (Target == newTarget) {
          // w/o altered newTarget, optimization for 0-4 arguments
          switch (args.length) {
            case 0:
              return new Target();
            case 1:
              return new Target(args[0]);
            case 2:
              return new Target(args[0], args[1]);
            case 3:
              return new Target(args[0], args[1], args[2]);
            case 4:
              return new Target(args[0], args[1], args[2], args[3]);
          }
          // w/o altered newTarget, lot of arguments case
          var $args = [null];
          $args.push.apply($args, args);
          return new (bind.apply(Target, $args))();
        }
        // with altered newTarget, not support built-in constructors
        var proto = newTarget.prototype,
            instance = create(isObject(proto) ? proto : Object.prototype),
            result = Function.apply.call(Target, instance, args);
        return isObject(result) ? result : instance;
      }
    });
  }, { "./_a-function": 3, "./_an-object": 7, "./_bind": 16, "./_export": 32, "./_fails": 34, "./_global": 38, "./_is-object": 49, "./_object-create": 66 }], 201: [function (require, module, exports) {
    // 26.1.3 Reflect.defineProperty(target, propertyKey, attributes)
    var dP = require('./_object-dp'),
        $export = require('./_export'),
        anObject = require('./_an-object'),
        toPrimitive = require('./_to-primitive');

    // MS Edge has broken Reflect.defineProperty - throwing instead of returning false
    $export($export.S + $export.F * require('./_fails')(function () {
      Reflect.defineProperty(dP.f({}, 1, { value: 1 }), 1, { value: 2 });
    }), 'Reflect', {
      defineProperty: function defineProperty(target, propertyKey, attributes) {
        anObject(target);
        propertyKey = toPrimitive(propertyKey, true);
        anObject(attributes);
        try {
          dP.f(target, propertyKey, attributes);
          return true;
        } catch (e) {
          return false;
        }
      }
    });
  }, { "./_an-object": 7, "./_export": 32, "./_fails": 34, "./_object-dp": 67, "./_to-primitive": 110 }], 202: [function (require, module, exports) {
    // 26.1.4 Reflect.deleteProperty(target, propertyKey)
    var $export = require('./_export'),
        gOPD = require('./_object-gopd').f,
        anObject = require('./_an-object');

    $export($export.S, 'Reflect', {
      deleteProperty: function deleteProperty(target, propertyKey) {
        var desc = gOPD(anObject(target), propertyKey);
        return desc && !desc.configurable ? false : delete target[propertyKey];
      }
    });
  }, { "./_an-object": 7, "./_export": 32, "./_object-gopd": 70 }], 203: [function (require, module, exports) {
    'use strict';
    // 26.1.5 Reflect.enumerate(target)

    var $export = require('./_export'),
        anObject = require('./_an-object');
    var Enumerate = function Enumerate(iterated) {
      this._t = anObject(iterated); // target
      this._i = 0; // next index
      var keys = this._k = [] // keys
      ,
          key;
      for (key in iterated) {
        keys.push(key);
      }
    };
    require('./_iter-create')(Enumerate, 'Object', function () {
      var that = this,
          keys = that._k,
          key;
      do {
        if (that._i >= keys.length) return { value: undefined, done: true };
      } while (!((key = keys[that._i++]) in that._t));
      return { value: key, done: false };
    });

    $export($export.S, 'Reflect', {
      enumerate: function enumerate(target) {
        return new Enumerate(target);
      }
    });
  }, { "./_an-object": 7, "./_export": 32, "./_iter-create": 52 }], 204: [function (require, module, exports) {
    // 26.1.7 Reflect.getOwnPropertyDescriptor(target, propertyKey)
    var gOPD = require('./_object-gopd'),
        $export = require('./_export'),
        anObject = require('./_an-object');

    $export($export.S, 'Reflect', {
      getOwnPropertyDescriptor: function getOwnPropertyDescriptor(target, propertyKey) {
        return gOPD.f(anObject(target), propertyKey);
      }
    });
  }, { "./_an-object": 7, "./_export": 32, "./_object-gopd": 70 }], 205: [function (require, module, exports) {
    // 26.1.8 Reflect.getPrototypeOf(target)
    var $export = require('./_export'),
        getProto = require('./_object-gpo'),
        anObject = require('./_an-object');

    $export($export.S, 'Reflect', {
      getPrototypeOf: function getPrototypeOf(target) {
        return getProto(anObject(target));
      }
    });
  }, { "./_an-object": 7, "./_export": 32, "./_object-gpo": 74 }], 206: [function (require, module, exports) {
    // 26.1.6 Reflect.get(target, propertyKey [, receiver])
    var gOPD = require('./_object-gopd'),
        getPrototypeOf = require('./_object-gpo'),
        has = require('./_has'),
        $export = require('./_export'),
        isObject = require('./_is-object'),
        anObject = require('./_an-object');

    function get(target, propertyKey /*, receiver*/) {
      var receiver = arguments.length < 3 ? target : arguments[2],
          desc,
          proto;
      if (anObject(target) === receiver) return target[propertyKey];
      if (desc = gOPD.f(target, propertyKey)) return has(desc, 'value') ? desc.value : desc.get !== undefined ? desc.get.call(receiver) : undefined;
      if (isObject(proto = getPrototypeOf(target))) return get(proto, propertyKey, receiver);
    }

    $export($export.S, 'Reflect', { get: get });
  }, { "./_an-object": 7, "./_export": 32, "./_has": 39, "./_is-object": 49, "./_object-gopd": 70, "./_object-gpo": 74 }], 207: [function (require, module, exports) {
    // 26.1.9 Reflect.has(target, propertyKey)
    var $export = require('./_export');

    $export($export.S, 'Reflect', {
      has: function has(target, propertyKey) {
        return propertyKey in target;
      }
    });
  }, { "./_export": 32 }], 208: [function (require, module, exports) {
    // 26.1.10 Reflect.isExtensible(target)
    var $export = require('./_export'),
        anObject = require('./_an-object'),
        $isExtensible = Object.isExtensible;

    $export($export.S, 'Reflect', {
      isExtensible: function isExtensible(target) {
        anObject(target);
        return $isExtensible ? $isExtensible(target) : true;
      }
    });
  }, { "./_an-object": 7, "./_export": 32 }], 209: [function (require, module, exports) {
    // 26.1.11 Reflect.ownKeys(target)
    var $export = require('./_export');

    $export($export.S, 'Reflect', { ownKeys: require('./_own-keys') });
  }, { "./_export": 32, "./_own-keys": 80 }], 210: [function (require, module, exports) {
    // 26.1.12 Reflect.preventExtensions(target)
    var $export = require('./_export'),
        anObject = require('./_an-object'),
        $preventExtensions = Object.preventExtensions;

    $export($export.S, 'Reflect', {
      preventExtensions: function preventExtensions(target) {
        anObject(target);
        try {
          if ($preventExtensions) $preventExtensions(target);
          return true;
        } catch (e) {
          return false;
        }
      }
    });
  }, { "./_an-object": 7, "./_export": 32 }], 211: [function (require, module, exports) {
    // 26.1.14 Reflect.setPrototypeOf(target, proto)
    var $export = require('./_export'),
        setProto = require('./_set-proto');

    if (setProto) $export($export.S, 'Reflect', {
      setPrototypeOf: function setPrototypeOf(target, proto) {
        setProto.check(target, proto);
        try {
          setProto.set(target, proto);
          return true;
        } catch (e) {
          return false;
        }
      }
    });
  }, { "./_export": 32, "./_set-proto": 90 }], 212: [function (require, module, exports) {
    // 26.1.13 Reflect.set(target, propertyKey, V [, receiver])
    var dP = require('./_object-dp'),
        gOPD = require('./_object-gopd'),
        getPrototypeOf = require('./_object-gpo'),
        has = require('./_has'),
        $export = require('./_export'),
        createDesc = require('./_property-desc'),
        anObject = require('./_an-object'),
        isObject = require('./_is-object');

    function set(target, propertyKey, V /*, receiver*/) {
      var receiver = arguments.length < 4 ? target : arguments[3],
          ownDesc = gOPD.f(anObject(target), propertyKey),
          existingDescriptor,
          proto;
      if (!ownDesc) {
        if (isObject(proto = getPrototypeOf(target))) {
          return set(proto, propertyKey, V, receiver);
        }
        ownDesc = createDesc(0);
      }
      if (has(ownDesc, 'value')) {
        if (ownDesc.writable === false || !isObject(receiver)) return false;
        existingDescriptor = gOPD.f(receiver, propertyKey) || createDesc(0);
        existingDescriptor.value = V;
        dP.f(receiver, propertyKey, existingDescriptor);
        return true;
      }
      return ownDesc.set === undefined ? false : (ownDesc.set.call(receiver, V), true);
    }

    $export($export.S, 'Reflect', { set: set });
  }, { "./_an-object": 7, "./_export": 32, "./_has": 39, "./_is-object": 49, "./_object-dp": 67, "./_object-gopd": 70, "./_object-gpo": 74, "./_property-desc": 85 }], 213: [function (require, module, exports) {
    var global = require('./_global'),
        inheritIfRequired = require('./_inherit-if-required'),
        dP = require('./_object-dp').f,
        gOPN = require('./_object-gopn').f,
        isRegExp = require('./_is-regexp'),
        $flags = require('./_flags'),
        $RegExp = global.RegExp,
        Base = $RegExp,
        proto = $RegExp.prototype,
        re1 = /a/g,
        re2 = /a/g
    // "new" creates a new object, old webkit buggy here
    ,
        CORRECT_NEW = new $RegExp(re1) !== re1;

    if (require('./_descriptors') && (!CORRECT_NEW || require('./_fails')(function () {
      re2[require('./_wks')('match')] = false;
      // RegExp constructor can alter flags and IsRegExp works correct with @@match
      return $RegExp(re1) != re1 || $RegExp(re2) == re2 || $RegExp(re1, 'i') != '/a/i';
    }))) {
      $RegExp = function RegExp(p, f) {
        var tiRE = this instanceof $RegExp,
            piRE = isRegExp(p),
            fiU = f === undefined;
        return !tiRE && piRE && p.constructor === $RegExp && fiU ? p : inheritIfRequired(CORRECT_NEW ? new Base(piRE && !fiU ? p.source : p, f) : Base((piRE = p instanceof $RegExp) ? p.source : p, piRE && fiU ? $flags.call(p) : f), tiRE ? this : proto, $RegExp);
      };
      var proxy = function proxy(key) {
        key in $RegExp || dP($RegExp, key, {
          configurable: true,
          get: function get() {
            return Base[key];
          },
          set: function set(it) {
            Base[key] = it;
          }
        });
      };
      for (var keys = gOPN(Base), i = 0; keys.length > i;) {
        proxy(keys[i++]);
      }proto.constructor = $RegExp;
      $RegExp.prototype = proto;
      require('./_redefine')(global, 'RegExp', $RegExp);
    }

    require('./_set-species')('RegExp');
  }, { "./_descriptors": 28, "./_fails": 34, "./_flags": 36, "./_global": 38, "./_inherit-if-required": 43, "./_is-regexp": 50, "./_object-dp": 67, "./_object-gopn": 72, "./_redefine": 87, "./_set-species": 91, "./_wks": 117 }], 214: [function (require, module, exports) {
    // 21.2.5.3 get RegExp.prototype.flags()
    if (require('./_descriptors') && /./g.flags != 'g') require('./_object-dp').f(RegExp.prototype, 'flags', {
      configurable: true,
      get: require('./_flags')
    });
  }, { "./_descriptors": 28, "./_flags": 36, "./_object-dp": 67 }], 215: [function (require, module, exports) {
    // @@match logic
    require('./_fix-re-wks')('match', 1, function (defined, MATCH, $match) {
      // 21.1.3.11 String.prototype.match(regexp)
      return [function match(regexp) {
        'use strict';

        var O = defined(this),
            fn = regexp == undefined ? undefined : regexp[MATCH];
        return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[MATCH](String(O));
      }, $match];
    });
  }, { "./_fix-re-wks": 35 }], 216: [function (require, module, exports) {
    // @@replace logic
    require('./_fix-re-wks')('replace', 2, function (defined, REPLACE, $replace) {
      // 21.1.3.14 String.prototype.replace(searchValue, replaceValue)
      return [function replace(searchValue, replaceValue) {
        'use strict';

        var O = defined(this),
            fn = searchValue == undefined ? undefined : searchValue[REPLACE];
        return fn !== undefined ? fn.call(searchValue, O, replaceValue) : $replace.call(String(O), searchValue, replaceValue);
      }, $replace];
    });
  }, { "./_fix-re-wks": 35 }], 217: [function (require, module, exports) {
    // @@search logic
    require('./_fix-re-wks')('search', 1, function (defined, SEARCH, $search) {
      // 21.1.3.15 String.prototype.search(regexp)
      return [function search(regexp) {
        'use strict';

        var O = defined(this),
            fn = regexp == undefined ? undefined : regexp[SEARCH];
        return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[SEARCH](String(O));
      }, $search];
    });
  }, { "./_fix-re-wks": 35 }], 218: [function (require, module, exports) {
    // @@split logic
    require('./_fix-re-wks')('split', 2, function (defined, SPLIT, $split) {
      'use strict';

      var isRegExp = require('./_is-regexp'),
          _split = $split,
          $push = [].push,
          $SPLIT = 'split',
          LENGTH = 'length',
          LAST_INDEX = 'lastIndex';
      if ('abbc'[$SPLIT](/(b)*/)[1] == 'c' || 'test'[$SPLIT](/(?:)/, -1)[LENGTH] != 4 || 'ab'[$SPLIT](/(?:ab)*/)[LENGTH] != 2 || '.'[$SPLIT](/(.?)(.?)/)[LENGTH] != 4 || '.'[$SPLIT](/()()/)[LENGTH] > 1 || ''[$SPLIT](/.?/)[LENGTH]) {
        var NPCG = /()??/.exec('')[1] === undefined; // nonparticipating capturing group
        // based on es5-shim implementation, need to rework it
        $split = function $split(separator, limit) {
          var string = String(this);
          if (separator === undefined && limit === 0) return [];
          // If `separator` is not a regex, use native split
          if (!isRegExp(separator)) return _split.call(string, separator, limit);
          var output = [];
          var flags = (separator.ignoreCase ? 'i' : '') + (separator.multiline ? 'm' : '') + (separator.unicode ? 'u' : '') + (separator.sticky ? 'y' : '');
          var lastLastIndex = 0;
          var splitLimit = limit === undefined ? 4294967295 : limit >>> 0;
          // Make `global` and avoid `lastIndex` issues by working with a copy
          var separatorCopy = new RegExp(separator.source, flags + 'g');
          var separator2, match, lastIndex, lastLength, i;
          // Doesn't need flags gy, but they don't hurt
          if (!NPCG) separator2 = new RegExp('^' + separatorCopy.source + '$(?!\\s)', flags);
          while (match = separatorCopy.exec(string)) {
            // `separatorCopy.lastIndex` is not reliable cross-browser
            lastIndex = match.index + match[0][LENGTH];
            if (lastIndex > lastLastIndex) {
              output.push(string.slice(lastLastIndex, match.index));
              // Fix browsers whose `exec` methods don't consistently return `undefined` for NPCG
              if (!NPCG && match[LENGTH] > 1) match[0].replace(separator2, function () {
                for (i = 1; i < arguments[LENGTH] - 2; i++) {
                  if (arguments[i] === undefined) match[i] = undefined;
                }
              });
              if (match[LENGTH] > 1 && match.index < string[LENGTH]) $push.apply(output, match.slice(1));
              lastLength = match[0][LENGTH];
              lastLastIndex = lastIndex;
              if (output[LENGTH] >= splitLimit) break;
            }
            if (separatorCopy[LAST_INDEX] === match.index) separatorCopy[LAST_INDEX]++; // Avoid an infinite loop
          }
          if (lastLastIndex === string[LENGTH]) {
            if (lastLength || !separatorCopy.test('')) output.push('');
          } else output.push(string.slice(lastLastIndex));
          return output[LENGTH] > splitLimit ? output.slice(0, splitLimit) : output;
        };
        // Chakra, V8
      } else if ('0'[$SPLIT](undefined, 0)[LENGTH]) {
        $split = function $split(separator, limit) {
          return separator === undefined && limit === 0 ? [] : _split.call(this, separator, limit);
        };
      }
      // 21.1.3.17 String.prototype.split(separator, limit)
      return [function split(separator, limit) {
        var O = defined(this),
            fn = separator == undefined ? undefined : separator[SPLIT];
        return fn !== undefined ? fn.call(separator, O, limit) : $split.call(String(O), separator, limit);
      }, $split];
    });
  }, { "./_fix-re-wks": 35, "./_is-regexp": 50 }], 219: [function (require, module, exports) {
    'use strict';

    require('./es6.regexp.flags');
    var anObject = require('./_an-object'),
        $flags = require('./_flags'),
        DESCRIPTORS = require('./_descriptors'),
        TO_STRING = 'toString',
        $toString = /./[TO_STRING];

    var define = function define(fn) {
      require('./_redefine')(RegExp.prototype, TO_STRING, fn, true);
    };

    // 21.2.5.14 RegExp.prototype.toString()
    if (require('./_fails')(function () {
      return $toString.call({ source: 'a', flags: 'b' }) != '/a/b';
    })) {
      define(function toString() {
        var R = anObject(this);
        return '/'.concat(R.source, '/', 'flags' in R ? R.flags : !DESCRIPTORS && R instanceof RegExp ? $flags.call(R) : undefined);
      });
      // FF44- RegExp#toString has a wrong name
    } else if ($toString.name != TO_STRING) {
      define(function toString() {
        return $toString.call(this);
      });
    }
  }, { "./_an-object": 7, "./_descriptors": 28, "./_fails": 34, "./_flags": 36, "./_redefine": 87, "./es6.regexp.flags": 214 }], 220: [function (require, module, exports) {
    'use strict';

    var strong = require('./_collection-strong');

    // 23.2 Set Objects
    module.exports = require('./_collection')('Set', function (get) {
      return function Set() {
        return get(this, arguments.length > 0 ? arguments[0] : undefined);
      };
    }, {
      // 23.2.3.1 Set.prototype.add(value)
      add: function add(value) {
        return strong.def(this, value = value === 0 ? 0 : value, value);
      }
    }, strong);
  }, { "./_collection": 22, "./_collection-strong": 19 }], 221: [function (require, module, exports) {
    'use strict';
    // B.2.3.2 String.prototype.anchor(name)

    require('./_string-html')('anchor', function (createHTML) {
      return function anchor(name) {
        return createHTML(this, 'a', 'name', name);
      };
    });
  }, { "./_string-html": 99 }], 222: [function (require, module, exports) {
    'use strict';
    // B.2.3.3 String.prototype.big()

    require('./_string-html')('big', function (createHTML) {
      return function big() {
        return createHTML(this, 'big', '', '');
      };
    });
  }, { "./_string-html": 99 }], 223: [function (require, module, exports) {
    'use strict';
    // B.2.3.4 String.prototype.blink()

    require('./_string-html')('blink', function (createHTML) {
      return function blink() {
        return createHTML(this, 'blink', '', '');
      };
    });
  }, { "./_string-html": 99 }], 224: [function (require, module, exports) {
    'use strict';
    // B.2.3.5 String.prototype.bold()

    require('./_string-html')('bold', function (createHTML) {
      return function bold() {
        return createHTML(this, 'b', '', '');
      };
    });
  }, { "./_string-html": 99 }], 225: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        $at = require('./_string-at')(false);
    $export($export.P, 'String', {
      // 21.1.3.3 String.prototype.codePointAt(pos)
      codePointAt: function codePointAt(pos) {
        return $at(this, pos);
      }
    });
  }, { "./_export": 32, "./_string-at": 97 }], 226: [function (require, module, exports) {
    // 21.1.3.6 String.prototype.endsWith(searchString [, endPosition])
    'use strict';

    var $export = require('./_export'),
        toLength = require('./_to-length'),
        context = require('./_string-context'),
        ENDS_WITH = 'endsWith',
        $endsWith = ''[ENDS_WITH];

    $export($export.P + $export.F * require('./_fails-is-regexp')(ENDS_WITH), 'String', {
      endsWith: function endsWith(searchString /*, endPosition = @length */) {
        var that = context(this, searchString, ENDS_WITH),
            endPosition = arguments.length > 1 ? arguments[1] : undefined,
            len = toLength(that.length),
            end = endPosition === undefined ? len : Math.min(toLength(endPosition), len),
            search = String(searchString);
        return $endsWith ? $endsWith.call(that, search, end) : that.slice(end - search.length, end) === search;
      }
    });
  }, { "./_export": 32, "./_fails-is-regexp": 33, "./_string-context": 98, "./_to-length": 108 }], 227: [function (require, module, exports) {
    'use strict';
    // B.2.3.6 String.prototype.fixed()

    require('./_string-html')('fixed', function (createHTML) {
      return function fixed() {
        return createHTML(this, 'tt', '', '');
      };
    });
  }, { "./_string-html": 99 }], 228: [function (require, module, exports) {
    'use strict';
    // B.2.3.7 String.prototype.fontcolor(color)

    require('./_string-html')('fontcolor', function (createHTML) {
      return function fontcolor(color) {
        return createHTML(this, 'font', 'color', color);
      };
    });
  }, { "./_string-html": 99 }], 229: [function (require, module, exports) {
    'use strict';
    // B.2.3.8 String.prototype.fontsize(size)

    require('./_string-html')('fontsize', function (createHTML) {
      return function fontsize(size) {
        return createHTML(this, 'font', 'size', size);
      };
    });
  }, { "./_string-html": 99 }], 230: [function (require, module, exports) {
    var $export = require('./_export'),
        toIndex = require('./_to-index'),
        fromCharCode = String.fromCharCode,
        $fromCodePoint = String.fromCodePoint;

    // length should be 1, old FF problem
    $export($export.S + $export.F * (!!$fromCodePoint && $fromCodePoint.length != 1), 'String', {
      // 21.1.2.2 String.fromCodePoint(...codePoints)
      fromCodePoint: function fromCodePoint(x) {
        // eslint-disable-line no-unused-vars
        var res = [],
            aLen = arguments.length,
            i = 0,
            code;
        while (aLen > i) {
          code = +arguments[i++];
          if (toIndex(code, 0x10ffff) !== code) throw RangeError(code + ' is not a valid code point');
          res.push(code < 0x10000 ? fromCharCode(code) : fromCharCode(((code -= 0x10000) >> 10) + 0xd800, code % 0x400 + 0xdc00));
        }return res.join('');
      }
    });
  }, { "./_export": 32, "./_to-index": 105 }], 231: [function (require, module, exports) {
    // 21.1.3.7 String.prototype.includes(searchString, position = 0)
    'use strict';

    var $export = require('./_export'),
        context = require('./_string-context'),
        INCLUDES = 'includes';

    $export($export.P + $export.F * require('./_fails-is-regexp')(INCLUDES), 'String', {
      includes: function includes(searchString /*, position = 0 */) {
        return !!~context(this, searchString, INCLUDES).indexOf(searchString, arguments.length > 1 ? arguments[1] : undefined);
      }
    });
  }, { "./_export": 32, "./_fails-is-regexp": 33, "./_string-context": 98 }], 232: [function (require, module, exports) {
    'use strict';
    // B.2.3.9 String.prototype.italics()

    require('./_string-html')('italics', function (createHTML) {
      return function italics() {
        return createHTML(this, 'i', '', '');
      };
    });
  }, { "./_string-html": 99 }], 233: [function (require, module, exports) {
    'use strict';

    var $at = require('./_string-at')(true);

    // 21.1.3.27 String.prototype[@@iterator]()
    require('./_iter-define')(String, 'String', function (iterated) {
      this._t = String(iterated); // target
      this._i = 0; // next index
      // 21.1.5.2.1 %StringIteratorPrototype%.next()
    }, function () {
      var O = this._t,
          index = this._i,
          point;
      if (index >= O.length) return { value: undefined, done: true };
      point = $at(O, index);
      this._i += point.length;
      return { value: point, done: false };
    });
  }, { "./_iter-define": 53, "./_string-at": 97 }], 234: [function (require, module, exports) {
    'use strict';
    // B.2.3.10 String.prototype.link(url)

    require('./_string-html')('link', function (createHTML) {
      return function link(url) {
        return createHTML(this, 'a', 'href', url);
      };
    });
  }, { "./_string-html": 99 }], 235: [function (require, module, exports) {
    var $export = require('./_export'),
        toIObject = require('./_to-iobject'),
        toLength = require('./_to-length');

    $export($export.S, 'String', {
      // 21.1.2.4 String.raw(callSite, ...substitutions)
      raw: function raw(callSite) {
        var tpl = toIObject(callSite.raw),
            len = toLength(tpl.length),
            aLen = arguments.length,
            res = [],
            i = 0;
        while (len > i) {
          res.push(String(tpl[i++]));
          if (i < aLen) res.push(String(arguments[i]));
        }return res.join('');
      }
    });
  }, { "./_export": 32, "./_to-iobject": 107, "./_to-length": 108 }], 236: [function (require, module, exports) {
    var $export = require('./_export');

    $export($export.P, 'String', {
      // 21.1.3.13 String.prototype.repeat(count)
      repeat: require('./_string-repeat')
    });
  }, { "./_export": 32, "./_string-repeat": 101 }], 237: [function (require, module, exports) {
    'use strict';
    // B.2.3.11 String.prototype.small()

    require('./_string-html')('small', function (createHTML) {
      return function small() {
        return createHTML(this, 'small', '', '');
      };
    });
  }, { "./_string-html": 99 }], 238: [function (require, module, exports) {
    // 21.1.3.18 String.prototype.startsWith(searchString [, position ])
    'use strict';

    var $export = require('./_export'),
        toLength = require('./_to-length'),
        context = require('./_string-context'),
        STARTS_WITH = 'startsWith',
        $startsWith = ''[STARTS_WITH];

    $export($export.P + $export.F * require('./_fails-is-regexp')(STARTS_WITH), 'String', {
      startsWith: function startsWith(searchString /*, position = 0 */) {
        var that = context(this, searchString, STARTS_WITH),
            index = toLength(Math.min(arguments.length > 1 ? arguments[1] : undefined, that.length)),
            search = String(searchString);
        return $startsWith ? $startsWith.call(that, search, index) : that.slice(index, index + search.length) === search;
      }
    });
  }, { "./_export": 32, "./_fails-is-regexp": 33, "./_string-context": 98, "./_to-length": 108 }], 239: [function (require, module, exports) {
    'use strict';
    // B.2.3.12 String.prototype.strike()

    require('./_string-html')('strike', function (createHTML) {
      return function strike() {
        return createHTML(this, 'strike', '', '');
      };
    });
  }, { "./_string-html": 99 }], 240: [function (require, module, exports) {
    'use strict';
    // B.2.3.13 String.prototype.sub()

    require('./_string-html')('sub', function (createHTML) {
      return function sub() {
        return createHTML(this, 'sub', '', '');
      };
    });
  }, { "./_string-html": 99 }], 241: [function (require, module, exports) {
    'use strict';
    // B.2.3.14 String.prototype.sup()

    require('./_string-html')('sup', function (createHTML) {
      return function sup() {
        return createHTML(this, 'sup', '', '');
      };
    });
  }, { "./_string-html": 99 }], 242: [function (require, module, exports) {
    'use strict';
    // 21.1.3.25 String.prototype.trim()

    require('./_string-trim')('trim', function ($trim) {
      return function trim() {
        return $trim(this, 3);
      };
    });
  }, { "./_string-trim": 102 }], 243: [function (require, module, exports) {
    'use strict';
    // ECMAScript 6 symbols shim

    var global = require('./_global'),
        has = require('./_has'),
        DESCRIPTORS = require('./_descriptors'),
        $export = require('./_export'),
        redefine = require('./_redefine'),
        META = require('./_meta').KEY,
        $fails = require('./_fails'),
        shared = require('./_shared'),
        setToStringTag = require('./_set-to-string-tag'),
        uid = require('./_uid'),
        wks = require('./_wks'),
        wksExt = require('./_wks-ext'),
        wksDefine = require('./_wks-define'),
        keyOf = require('./_keyof'),
        enumKeys = require('./_enum-keys'),
        isArray = require('./_is-array'),
        anObject = require('./_an-object'),
        toIObject = require('./_to-iobject'),
        toPrimitive = require('./_to-primitive'),
        createDesc = require('./_property-desc'),
        _create = require('./_object-create'),
        gOPNExt = require('./_object-gopn-ext'),
        $GOPD = require('./_object-gopd'),
        $DP = require('./_object-dp'),
        $keys = require('./_object-keys'),
        gOPD = $GOPD.f,
        dP = $DP.f,
        gOPN = gOPNExt.f,
        $Symbol = global.Symbol,
        $JSON = global.JSON,
        _stringify = $JSON && $JSON.stringify,
        PROTOTYPE = 'prototype',
        HIDDEN = wks('_hidden'),
        TO_PRIMITIVE = wks('toPrimitive'),
        isEnum = {}.propertyIsEnumerable,
        SymbolRegistry = shared('symbol-registry'),
        AllSymbols = shared('symbols'),
        OPSymbols = shared('op-symbols'),
        ObjectProto = Object[PROTOTYPE],
        USE_NATIVE = typeof $Symbol == 'function',
        QObject = global.QObject;
    // Don't use setters in Qt Script, https://github.com/zloirock/core-js/issues/173
    var setter = !QObject || !QObject[PROTOTYPE] || !QObject[PROTOTYPE].findChild;

    // fallback for old Android, https://code.google.com/p/v8/issues/detail?id=687
    var setSymbolDesc = DESCRIPTORS && $fails(function () {
      return _create(dP({}, 'a', {
        get: function get() {
          return dP(this, 'a', { value: 7 }).a;
        }
      })).a != 7;
    }) ? function (it, key, D) {
      var protoDesc = gOPD(ObjectProto, key);
      if (protoDesc) delete ObjectProto[key];
      dP(it, key, D);
      if (protoDesc && it !== ObjectProto) dP(ObjectProto, key, protoDesc);
    } : dP;

    var wrap = function wrap(tag) {
      var sym = AllSymbols[tag] = _create($Symbol[PROTOTYPE]);
      sym._k = tag;
      return sym;
    };

    var isSymbol = USE_NATIVE && _typeof($Symbol.iterator) == 'symbol' ? function (it) {
      return (typeof it === "undefined" ? "undefined" : _typeof(it)) == 'symbol';
    } : function (it) {
      return it instanceof $Symbol;
    };

    var $defineProperty = function defineProperty(it, key, D) {
      if (it === ObjectProto) $defineProperty(OPSymbols, key, D);
      anObject(it);
      key = toPrimitive(key, true);
      anObject(D);
      if (has(AllSymbols, key)) {
        if (!D.enumerable) {
          if (!has(it, HIDDEN)) dP(it, HIDDEN, createDesc(1, {}));
          it[HIDDEN][key] = true;
        } else {
          if (has(it, HIDDEN) && it[HIDDEN][key]) it[HIDDEN][key] = false;
          D = _create(D, { enumerable: createDesc(0, false) });
        }return setSymbolDesc(it, key, D);
      }return dP(it, key, D);
    };
    var $defineProperties = function defineProperties(it, P) {
      anObject(it);
      var keys = enumKeys(P = toIObject(P)),
          i = 0,
          l = keys.length,
          key;
      while (l > i) {
        $defineProperty(it, key = keys[i++], P[key]);
      }return it;
    };
    var $create = function create(it, P) {
      return P === undefined ? _create(it) : $defineProperties(_create(it), P);
    };
    var $propertyIsEnumerable = function propertyIsEnumerable(key) {
      var E = isEnum.call(this, key = toPrimitive(key, true));
      if (this === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return false;
      return E || !has(this, key) || !has(AllSymbols, key) || has(this, HIDDEN) && this[HIDDEN][key] ? E : true;
    };
    var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(it, key) {
      it = toIObject(it);
      key = toPrimitive(key, true);
      if (it === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return;
      var D = gOPD(it, key);
      if (D && has(AllSymbols, key) && !(has(it, HIDDEN) && it[HIDDEN][key])) D.enumerable = true;
      return D;
    };
    var $getOwnPropertyNames = function getOwnPropertyNames(it) {
      var names = gOPN(toIObject(it)),
          result = [],
          i = 0,
          key;
      while (names.length > i) {
        if (!has(AllSymbols, key = names[i++]) && key != HIDDEN && key != META) result.push(key);
      }return result;
    };
    var $getOwnPropertySymbols = function getOwnPropertySymbols(it) {
      var IS_OP = it === ObjectProto,
          names = gOPN(IS_OP ? OPSymbols : toIObject(it)),
          result = [],
          i = 0,
          key;
      while (names.length > i) {
        if (has(AllSymbols, key = names[i++]) && (IS_OP ? has(ObjectProto, key) : true)) result.push(AllSymbols[key]);
      }return result;
    };

    // 19.4.1.1 Symbol([description])
    if (!USE_NATIVE) {
      $Symbol = function _Symbol2() {
        if (this instanceof $Symbol) throw TypeError('Symbol is not a constructor!');
        var tag = uid(arguments.length > 0 ? arguments[0] : undefined);
        var $set = function $set(value) {
          if (this === ObjectProto) $set.call(OPSymbols, value);
          if (has(this, HIDDEN) && has(this[HIDDEN], tag)) this[HIDDEN][tag] = false;
          setSymbolDesc(this, tag, createDesc(1, value));
        };
        if (DESCRIPTORS && setter) setSymbolDesc(ObjectProto, tag, { configurable: true, set: $set });
        return wrap(tag);
      };
      redefine($Symbol[PROTOTYPE], 'toString', function toString() {
        return this._k;
      });

      $GOPD.f = $getOwnPropertyDescriptor;
      $DP.f = $defineProperty;
      require('./_object-gopn').f = gOPNExt.f = $getOwnPropertyNames;
      require('./_object-pie').f = $propertyIsEnumerable;
      require('./_object-gops').f = $getOwnPropertySymbols;

      if (DESCRIPTORS && !require('./_library')) {
        redefine(ObjectProto, 'propertyIsEnumerable', $propertyIsEnumerable, true);
      }

      wksExt.f = function (name) {
        return wrap(wks(name));
      };
    }

    $export($export.G + $export.W + $export.F * !USE_NATIVE, { Symbol: $Symbol });

    for (var symbols =
    // 19.4.2.2, 19.4.2.3, 19.4.2.4, 19.4.2.6, 19.4.2.8, 19.4.2.9, 19.4.2.10, 19.4.2.11, 19.4.2.12, 19.4.2.13, 19.4.2.14
    'hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables'.split(','), i = 0; symbols.length > i;) {
      wks(symbols[i++]);
    }for (var symbols = $keys(wks.store), i = 0; symbols.length > i;) {
      wksDefine(symbols[i++]);
    }$export($export.S + $export.F * !USE_NATIVE, 'Symbol', {
      // 19.4.2.1 Symbol.for(key)
      'for': function _for(key) {
        return has(SymbolRegistry, key += '') ? SymbolRegistry[key] : SymbolRegistry[key] = $Symbol(key);
      },
      // 19.4.2.5 Symbol.keyFor(sym)
      keyFor: function keyFor(key) {
        if (isSymbol(key)) return keyOf(SymbolRegistry, key);
        throw TypeError(key + ' is not a symbol!');
      },
      useSetter: function useSetter() {
        setter = true;
      },
      useSimple: function useSimple() {
        setter = false;
      }
    });

    $export($export.S + $export.F * !USE_NATIVE, 'Object', {
      // 19.1.2.2 Object.create(O [, Properties])
      create: $create,
      // 19.1.2.4 Object.defineProperty(O, P, Attributes)
      defineProperty: $defineProperty,
      // 19.1.2.3 Object.defineProperties(O, Properties)
      defineProperties: $defineProperties,
      // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
      getOwnPropertyDescriptor: $getOwnPropertyDescriptor,
      // 19.1.2.7 Object.getOwnPropertyNames(O)
      getOwnPropertyNames: $getOwnPropertyNames,
      // 19.1.2.8 Object.getOwnPropertySymbols(O)
      getOwnPropertySymbols: $getOwnPropertySymbols
    });

    // 24.3.2 JSON.stringify(value [, replacer [, space]])
    $JSON && $export($export.S + $export.F * (!USE_NATIVE || $fails(function () {
      var S = $Symbol();
      // MS Edge converts symbol values to JSON as {}
      // WebKit converts symbol values to JSON as null
      // V8 throws on boxed symbols
      return _stringify([S]) != '[null]' || _stringify({ a: S }) != '{}' || _stringify(Object(S)) != '{}';
    })), 'JSON', {
      stringify: function stringify(it) {
        if (it === undefined || isSymbol(it)) return; // IE8 returns string on undefined
        var args = [it],
            i = 1,
            replacer,
            $replacer;
        while (arguments.length > i) {
          args.push(arguments[i++]);
        }replacer = args[1];
        if (typeof replacer == 'function') $replacer = replacer;
        if ($replacer || !isArray(replacer)) replacer = function replacer(key, value) {
          if ($replacer) value = $replacer.call(this, key, value);
          if (!isSymbol(value)) return value;
        };
        args[1] = replacer;
        return _stringify.apply($JSON, args);
      }
    });

    // 19.4.3.4 Symbol.prototype[@@toPrimitive](hint)
    $Symbol[PROTOTYPE][TO_PRIMITIVE] || require('./_hide')($Symbol[PROTOTYPE], TO_PRIMITIVE, $Symbol[PROTOTYPE].valueOf);
    // 19.4.3.5 Symbol.prototype[@@toStringTag]
    setToStringTag($Symbol, 'Symbol');
    // 20.2.1.9 Math[@@toStringTag]
    setToStringTag(Math, 'Math', true);
    // 24.3.3 JSON[@@toStringTag]
    setToStringTag(global.JSON, 'JSON', true);
  }, { "./_an-object": 7, "./_descriptors": 28, "./_enum-keys": 31, "./_export": 32, "./_fails": 34, "./_global": 38, "./_has": 39, "./_hide": 40, "./_is-array": 47, "./_keyof": 57, "./_library": 58, "./_meta": 62, "./_object-create": 66, "./_object-dp": 67, "./_object-gopd": 70, "./_object-gopn": 72, "./_object-gopn-ext": 71, "./_object-gops": 73, "./_object-keys": 76, "./_object-pie": 77, "./_property-desc": 85, "./_redefine": 87, "./_set-to-string-tag": 92, "./_shared": 94, "./_to-iobject": 107, "./_to-primitive": 110, "./_uid": 114, "./_wks": 117, "./_wks-define": 115, "./_wks-ext": 116 }], 244: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        $typed = require('./_typed'),
        buffer = require('./_typed-buffer'),
        anObject = require('./_an-object'),
        toIndex = require('./_to-index'),
        toLength = require('./_to-length'),
        isObject = require('./_is-object'),
        ArrayBuffer = require('./_global').ArrayBuffer,
        speciesConstructor = require('./_species-constructor'),
        $ArrayBuffer = buffer.ArrayBuffer,
        $DataView = buffer.DataView,
        $isView = $typed.ABV && ArrayBuffer.isView,
        $slice = $ArrayBuffer.prototype.slice,
        VIEW = $typed.VIEW,
        ARRAY_BUFFER = 'ArrayBuffer';

    $export($export.G + $export.W + $export.F * (ArrayBuffer !== $ArrayBuffer), { ArrayBuffer: $ArrayBuffer });

    $export($export.S + $export.F * !$typed.CONSTR, ARRAY_BUFFER, {
      // 24.1.3.1 ArrayBuffer.isView(arg)
      isView: function isView(it) {
        return $isView && $isView(it) || isObject(it) && VIEW in it;
      }
    });

    $export($export.P + $export.U + $export.F * require('./_fails')(function () {
      return !new $ArrayBuffer(2).slice(1, undefined).byteLength;
    }), ARRAY_BUFFER, {
      // 24.1.4.3 ArrayBuffer.prototype.slice(start, end)
      slice: function slice(start, end) {
        if ($slice !== undefined && end === undefined) return $slice.call(anObject(this), start); // FF fix
        var len = anObject(this).byteLength,
            first = toIndex(start, len),
            final = toIndex(end === undefined ? len : end, len),
            result = new (speciesConstructor(this, $ArrayBuffer))(toLength(final - first)),
            viewS = new $DataView(this),
            viewT = new $DataView(result),
            index = 0;
        while (first < final) {
          viewT.setUint8(index++, viewS.getUint8(first++));
        }return result;
      }
    });

    require('./_set-species')(ARRAY_BUFFER);
  }, { "./_an-object": 7, "./_export": 32, "./_fails": 34, "./_global": 38, "./_is-object": 49, "./_set-species": 91, "./_species-constructor": 95, "./_to-index": 105, "./_to-length": 108, "./_typed": 113, "./_typed-buffer": 112 }], 245: [function (require, module, exports) {
    var $export = require('./_export');
    $export($export.G + $export.W + $export.F * !require('./_typed').ABV, {
      DataView: require('./_typed-buffer').DataView
    });
  }, { "./_export": 32, "./_typed": 113, "./_typed-buffer": 112 }], 246: [function (require, module, exports) {
    require('./_typed-array')('Float32', 4, function (init) {
      return function Float32Array(data, byteOffset, length) {
        return init(this, data, byteOffset, length);
      };
    });
  }, { "./_typed-array": 111 }], 247: [function (require, module, exports) {
    require('./_typed-array')('Float64', 8, function (init) {
      return function Float64Array(data, byteOffset, length) {
        return init(this, data, byteOffset, length);
      };
    });
  }, { "./_typed-array": 111 }], 248: [function (require, module, exports) {
    require('./_typed-array')('Int16', 2, function (init) {
      return function Int16Array(data, byteOffset, length) {
        return init(this, data, byteOffset, length);
      };
    });
  }, { "./_typed-array": 111 }], 249: [function (require, module, exports) {
    require('./_typed-array')('Int32', 4, function (init) {
      return function Int32Array(data, byteOffset, length) {
        return init(this, data, byteOffset, length);
      };
    });
  }, { "./_typed-array": 111 }], 250: [function (require, module, exports) {
    require('./_typed-array')('Int8', 1, function (init) {
      return function Int8Array(data, byteOffset, length) {
        return init(this, data, byteOffset, length);
      };
    });
  }, { "./_typed-array": 111 }], 251: [function (require, module, exports) {
    require('./_typed-array')('Uint16', 2, function (init) {
      return function Uint16Array(data, byteOffset, length) {
        return init(this, data, byteOffset, length);
      };
    });
  }, { "./_typed-array": 111 }], 252: [function (require, module, exports) {
    require('./_typed-array')('Uint32', 4, function (init) {
      return function Uint32Array(data, byteOffset, length) {
        return init(this, data, byteOffset, length);
      };
    });
  }, { "./_typed-array": 111 }], 253: [function (require, module, exports) {
    require('./_typed-array')('Uint8', 1, function (init) {
      return function Uint8Array(data, byteOffset, length) {
        return init(this, data, byteOffset, length);
      };
    });
  }, { "./_typed-array": 111 }], 254: [function (require, module, exports) {
    require('./_typed-array')('Uint8', 1, function (init) {
      return function Uint8ClampedArray(data, byteOffset, length) {
        return init(this, data, byteOffset, length);
      };
    }, true);
  }, { "./_typed-array": 111 }], 255: [function (require, module, exports) {
    'use strict';

    var each = require('./_array-methods')(0),
        redefine = require('./_redefine'),
        meta = require('./_meta'),
        assign = require('./_object-assign'),
        weak = require('./_collection-weak'),
        isObject = require('./_is-object'),
        getWeak = meta.getWeak,
        isExtensible = Object.isExtensible,
        uncaughtFrozenStore = weak.ufstore,
        tmp = {},
        InternalMap;

    var wrapper = function wrapper(get) {
      return function WeakMap() {
        return get(this, arguments.length > 0 ? arguments[0] : undefined);
      };
    };

    var methods = {
      // 23.3.3.3 WeakMap.prototype.get(key)
      get: function get(key) {
        if (isObject(key)) {
          var data = getWeak(key);
          if (data === true) return uncaughtFrozenStore(this).get(key);
          return data ? data[this._i] : undefined;
        }
      },
      // 23.3.3.5 WeakMap.prototype.set(key, value)
      set: function set(key, value) {
        return weak.def(this, key, value);
      }
    };

    // 23.3 WeakMap Objects
    var $WeakMap = module.exports = require('./_collection')('WeakMap', wrapper, methods, weak, true, true);

    // IE11 WeakMap frozen keys fix
    if (new $WeakMap().set((Object.freeze || Object)(tmp), 7).get(tmp) != 7) {
      InternalMap = weak.getConstructor(wrapper);
      assign(InternalMap.prototype, methods);
      meta.NEED = true;
      each(['delete', 'has', 'get', 'set'], function (key) {
        var proto = $WeakMap.prototype,
            method = proto[key];
        redefine(proto, key, function (a, b) {
          // store frozen objects on internal weakmap shim
          if (isObject(a) && !isExtensible(a)) {
            if (!this._f) this._f = new InternalMap();
            var result = this._f[key](a, b);
            return key == 'set' ? this : result;
            // store all the rest on native weakmap
          }return method.call(this, a, b);
        });
      });
    }
  }, { "./_array-methods": 12, "./_collection": 22, "./_collection-weak": 21, "./_is-object": 49, "./_meta": 62, "./_object-assign": 65, "./_redefine": 87 }], 256: [function (require, module, exports) {
    'use strict';

    var weak = require('./_collection-weak');

    // 23.4 WeakSet Objects
    require('./_collection')('WeakSet', function (get) {
      return function WeakSet() {
        return get(this, arguments.length > 0 ? arguments[0] : undefined);
      };
    }, {
      // 23.4.3.1 WeakSet.prototype.add(value)
      add: function add(value) {
        return weak.def(this, value, true);
      }
    }, weak, false, true);
  }, { "./_collection": 22, "./_collection-weak": 21 }], 257: [function (require, module, exports) {
    'use strict';
    // https://github.com/tc39/Array.prototype.includes

    var $export = require('./_export'),
        $includes = require('./_array-includes')(true);

    $export($export.P, 'Array', {
      includes: function includes(el /*, fromIndex = 0 */) {
        return $includes(this, el, arguments.length > 1 ? arguments[1] : undefined);
      }
    });

    require('./_add-to-unscopables')('includes');
  }, { "./_add-to-unscopables": 5, "./_array-includes": 11, "./_export": 32 }], 258: [function (require, module, exports) {
    // https://github.com/rwaldron/tc39-notes/blob/master/es6/2014-09/sept-25.md#510-globalasap-for-enqueuing-a-microtask
    var $export = require('./_export'),
        microtask = require('./_microtask')(),
        process = require('./_global').process,
        isNode = require('./_cof')(process) == 'process';

    $export($export.G, {
      asap: function asap(fn) {
        var domain = isNode && process.domain;
        microtask(domain ? domain.bind(fn) : fn);
      }
    });
  }, { "./_cof": 18, "./_export": 32, "./_global": 38, "./_microtask": 64 }], 259: [function (require, module, exports) {
    // https://github.com/ljharb/proposal-is-error
    var $export = require('./_export'),
        cof = require('./_cof');

    $export($export.S, 'Error', {
      isError: function isError(it) {
        return cof(it) === 'Error';
      }
    });
  }, { "./_cof": 18, "./_export": 32 }], 260: [function (require, module, exports) {
    // https://github.com/DavidBruant/Map-Set.prototype.toJSON
    var $export = require('./_export');

    $export($export.P + $export.R, 'Map', { toJSON: require('./_collection-to-json')('Map') });
  }, { "./_collection-to-json": 20, "./_export": 32 }], 261: [function (require, module, exports) {
    // https://gist.github.com/BrendanEich/4294d5c212a6d2254703
    var $export = require('./_export');

    $export($export.S, 'Math', {
      iaddh: function iaddh(x0, x1, y0, y1) {
        var $x0 = x0 >>> 0,
            $x1 = x1 >>> 0,
            $y0 = y0 >>> 0;
        return $x1 + (y1 >>> 0) + (($x0 & $y0 | ($x0 | $y0) & ~($x0 + $y0 >>> 0)) >>> 31) | 0;
      }
    });
  }, { "./_export": 32 }], 262: [function (require, module, exports) {
    // https://gist.github.com/BrendanEich/4294d5c212a6d2254703
    var $export = require('./_export');

    $export($export.S, 'Math', {
      imulh: function imulh(u, v) {
        var UINT16 = 0xffff,
            $u = +u,
            $v = +v,
            u0 = $u & UINT16,
            v0 = $v & UINT16,
            u1 = $u >> 16,
            v1 = $v >> 16,
            t = (u1 * v0 >>> 0) + (u0 * v0 >>> 16);
        return u1 * v1 + (t >> 16) + ((u0 * v1 >>> 0) + (t & UINT16) >> 16);
      }
    });
  }, { "./_export": 32 }], 263: [function (require, module, exports) {
    // https://gist.github.com/BrendanEich/4294d5c212a6d2254703
    var $export = require('./_export');

    $export($export.S, 'Math', {
      isubh: function isubh(x0, x1, y0, y1) {
        var $x0 = x0 >>> 0,
            $x1 = x1 >>> 0,
            $y0 = y0 >>> 0;
        return $x1 - (y1 >>> 0) - ((~$x0 & $y0 | ~($x0 ^ $y0) & $x0 - $y0 >>> 0) >>> 31) | 0;
      }
    });
  }, { "./_export": 32 }], 264: [function (require, module, exports) {
    // https://gist.github.com/BrendanEich/4294d5c212a6d2254703
    var $export = require('./_export');

    $export($export.S, 'Math', {
      umulh: function umulh(u, v) {
        var UINT16 = 0xffff,
            $u = +u,
            $v = +v,
            u0 = $u & UINT16,
            v0 = $v & UINT16,
            u1 = $u >>> 16,
            v1 = $v >>> 16,
            t = (u1 * v0 >>> 0) + (u0 * v0 >>> 16);
        return u1 * v1 + (t >>> 16) + ((u0 * v1 >>> 0) + (t & UINT16) >>> 16);
      }
    });
  }, { "./_export": 32 }], 265: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        toObject = require('./_to-object'),
        aFunction = require('./_a-function'),
        $defineProperty = require('./_object-dp');

    // B.2.2.2 Object.prototype.__defineGetter__(P, getter)
    require('./_descriptors') && $export($export.P + require('./_object-forced-pam'), 'Object', {
      __defineGetter__: function __defineGetter__(P, getter) {
        $defineProperty.f(toObject(this), P, { get: aFunction(getter), enumerable: true, configurable: true });
      }
    });
  }, { "./_a-function": 3, "./_descriptors": 28, "./_export": 32, "./_object-dp": 67, "./_object-forced-pam": 69, "./_to-object": 109 }], 266: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        toObject = require('./_to-object'),
        aFunction = require('./_a-function'),
        $defineProperty = require('./_object-dp');

    // B.2.2.3 Object.prototype.__defineSetter__(P, setter)
    require('./_descriptors') && $export($export.P + require('./_object-forced-pam'), 'Object', {
      __defineSetter__: function __defineSetter__(P, setter) {
        $defineProperty.f(toObject(this), P, { set: aFunction(setter), enumerable: true, configurable: true });
      }
    });
  }, { "./_a-function": 3, "./_descriptors": 28, "./_export": 32, "./_object-dp": 67, "./_object-forced-pam": 69, "./_to-object": 109 }], 267: [function (require, module, exports) {
    // https://github.com/tc39/proposal-object-values-entries
    var $export = require('./_export'),
        $entries = require('./_object-to-array')(true);

    $export($export.S, 'Object', {
      entries: function entries(it) {
        return $entries(it);
      }
    });
  }, { "./_export": 32, "./_object-to-array": 79 }], 268: [function (require, module, exports) {
    // https://github.com/tc39/proposal-object-getownpropertydescriptors
    var $export = require('./_export'),
        ownKeys = require('./_own-keys'),
        toIObject = require('./_to-iobject'),
        gOPD = require('./_object-gopd'),
        createProperty = require('./_create-property');

    $export($export.S, 'Object', {
      getOwnPropertyDescriptors: function getOwnPropertyDescriptors(object) {
        var O = toIObject(object),
            getDesc = gOPD.f,
            keys = ownKeys(O),
            result = {},
            i = 0,
            key;
        while (keys.length > i) {
          createProperty(result, key = keys[i++], getDesc(O, key));
        }return result;
      }
    });
  }, { "./_create-property": 24, "./_export": 32, "./_object-gopd": 70, "./_own-keys": 80, "./_to-iobject": 107 }], 269: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        toObject = require('./_to-object'),
        toPrimitive = require('./_to-primitive'),
        getPrototypeOf = require('./_object-gpo'),
        getOwnPropertyDescriptor = require('./_object-gopd').f;

    // B.2.2.4 Object.prototype.__lookupGetter__(P)
    require('./_descriptors') && $export($export.P + require('./_object-forced-pam'), 'Object', {
      __lookupGetter__: function __lookupGetter__(P) {
        var O = toObject(this),
            K = toPrimitive(P, true),
            D;
        do {
          if (D = getOwnPropertyDescriptor(O, K)) return D.get;
        } while (O = getPrototypeOf(O));
      }
    });
  }, { "./_descriptors": 28, "./_export": 32, "./_object-forced-pam": 69, "./_object-gopd": 70, "./_object-gpo": 74, "./_to-object": 109, "./_to-primitive": 110 }], 270: [function (require, module, exports) {
    'use strict';

    var $export = require('./_export'),
        toObject = require('./_to-object'),
        toPrimitive = require('./_to-primitive'),
        getPrototypeOf = require('./_object-gpo'),
        getOwnPropertyDescriptor = require('./_object-gopd').f;

    // B.2.2.5 Object.prototype.__lookupSetter__(P)
    require('./_descriptors') && $export($export.P + require('./_object-forced-pam'), 'Object', {
      __lookupSetter__: function __lookupSetter__(P) {
        var O = toObject(this),
            K = toPrimitive(P, true),
            D;
        do {
          if (D = getOwnPropertyDescriptor(O, K)) return D.set;
        } while (O = getPrototypeOf(O));
      }
    });
  }, { "./_descriptors": 28, "./_export": 32, "./_object-forced-pam": 69, "./_object-gopd": 70, "./_object-gpo": 74, "./_to-object": 109, "./_to-primitive": 110 }], 271: [function (require, module, exports) {
    // https://github.com/tc39/proposal-object-values-entries
    var $export = require('./_export'),
        $values = require('./_object-to-array')(false);

    $export($export.S, 'Object', {
      values: function values(it) {
        return $values(it);
      }
    });
  }, { "./_export": 32, "./_object-to-array": 79 }], 272: [function (require, module, exports) {
    'use strict';
    // https://github.com/zenparsing/es-observable

    var $export = require('./_export'),
        global = require('./_global'),
        core = require('./_core'),
        microtask = require('./_microtask')(),
        OBSERVABLE = require('./_wks')('observable'),
        aFunction = require('./_a-function'),
        anObject = require('./_an-object'),
        anInstance = require('./_an-instance'),
        redefineAll = require('./_redefine-all'),
        hide = require('./_hide'),
        forOf = require('./_for-of'),
        RETURN = forOf.RETURN;

    var getMethod = function getMethod(fn) {
      return fn == null ? undefined : aFunction(fn);
    };

    var cleanupSubscription = function cleanupSubscription(subscription) {
      var cleanup = subscription._c;
      if (cleanup) {
        subscription._c = undefined;
        cleanup();
      }
    };

    var subscriptionClosed = function subscriptionClosed(subscription) {
      return subscription._o === undefined;
    };

    var closeSubscription = function closeSubscription(subscription) {
      if (!subscriptionClosed(subscription)) {
        subscription._o = undefined;
        cleanupSubscription(subscription);
      }
    };

    var Subscription = function Subscription(observer, subscriber) {
      anObject(observer);
      this._c = undefined;
      this._o = observer;
      observer = new SubscriptionObserver(this);
      try {
        var cleanup = subscriber(observer),
            subscription = cleanup;
        if (cleanup != null) {
          if (typeof cleanup.unsubscribe === 'function') cleanup = function cleanup() {
            subscription.unsubscribe();
          };else aFunction(cleanup);
          this._c = cleanup;
        }
      } catch (e) {
        observer.error(e);
        return;
      }if (subscriptionClosed(this)) cleanupSubscription(this);
    };

    Subscription.prototype = redefineAll({}, {
      unsubscribe: function unsubscribe() {
        closeSubscription(this);
      }
    });

    var SubscriptionObserver = function SubscriptionObserver(subscription) {
      this._s = subscription;
    };

    SubscriptionObserver.prototype = redefineAll({}, {
      next: function next(value) {
        var subscription = this._s;
        if (!subscriptionClosed(subscription)) {
          var observer = subscription._o;
          try {
            var m = getMethod(observer.next);
            if (m) return m.call(observer, value);
          } catch (e) {
            try {
              closeSubscription(subscription);
            } finally {
              throw e;
            }
          }
        }
      },
      error: function error(value) {
        var subscription = this._s;
        if (subscriptionClosed(subscription)) throw value;
        var observer = subscription._o;
        subscription._o = undefined;
        try {
          var m = getMethod(observer.error);
          if (!m) throw value;
          value = m.call(observer, value);
        } catch (e) {
          try {
            cleanupSubscription(subscription);
          } finally {
            throw e;
          }
        }cleanupSubscription(subscription);
        return value;
      },
      complete: function complete(value) {
        var subscription = this._s;
        if (!subscriptionClosed(subscription)) {
          var observer = subscription._o;
          subscription._o = undefined;
          try {
            var m = getMethod(observer.complete);
            value = m ? m.call(observer, value) : undefined;
          } catch (e) {
            try {
              cleanupSubscription(subscription);
            } finally {
              throw e;
            }
          }cleanupSubscription(subscription);
          return value;
        }
      }
    });

    var $Observable = function Observable(subscriber) {
      anInstance(this, $Observable, 'Observable', '_f')._f = aFunction(subscriber);
    };

    redefineAll($Observable.prototype, {
      subscribe: function subscribe(observer) {
        return new Subscription(observer, this._f);
      },
      forEach: function forEach(fn) {
        var that = this;
        return new (core.Promise || global.Promise)(function (resolve, reject) {
          aFunction(fn);
          var subscription = that.subscribe({
            next: function next(value) {
              try {
                return fn(value);
              } catch (e) {
                reject(e);
                subscription.unsubscribe();
              }
            },
            error: reject,
            complete: resolve
          });
        });
      }
    });

    redefineAll($Observable, {
      from: function from(x) {
        var C = typeof this === 'function' ? this : $Observable;
        var method = getMethod(anObject(x)[OBSERVABLE]);
        if (method) {
          var observable = anObject(method.call(x));
          return observable.constructor === C ? observable : new C(function (observer) {
            return observable.subscribe(observer);
          });
        }
        return new C(function (observer) {
          var done = false;
          microtask(function () {
            if (!done) {
              try {
                if (forOf(x, false, function (it) {
                  observer.next(it);
                  if (done) return RETURN;
                }) === RETURN) return;
              } catch (e) {
                if (done) throw e;
                observer.error(e);
                return;
              }observer.complete();
            }
          });
          return function () {
            done = true;
          };
        });
      },
      of: function of() {
        for (var i = 0, l = arguments.length, items = Array(l); i < l;) {
          items[i] = arguments[i++];
        }return new (typeof this === 'function' ? this : $Observable)(function (observer) {
          var done = false;
          microtask(function () {
            if (!done) {
              for (var i = 0; i < items.length; ++i) {
                observer.next(items[i]);
                if (done) return;
              }observer.complete();
            }
          });
          return function () {
            done = true;
          };
        });
      }
    });

    hide($Observable.prototype, OBSERVABLE, function () {
      return this;
    });

    $export($export.G, { Observable: $Observable });

    require('./_set-species')('Observable');
  }, { "./_a-function": 3, "./_an-instance": 6, "./_an-object": 7, "./_core": 23, "./_export": 32, "./_for-of": 37, "./_global": 38, "./_hide": 40, "./_microtask": 64, "./_redefine-all": 86, "./_set-species": 91, "./_wks": 117 }], 273: [function (require, module, exports) {
    var metadata = require('./_metadata'),
        anObject = require('./_an-object'),
        toMetaKey = metadata.key,
        ordinaryDefineOwnMetadata = metadata.set;

    metadata.exp({ defineMetadata: function defineMetadata(metadataKey, metadataValue, target, targetKey) {
        ordinaryDefineOwnMetadata(metadataKey, metadataValue, anObject(target), toMetaKey(targetKey));
      } });
  }, { "./_an-object": 7, "./_metadata": 63 }], 274: [function (require, module, exports) {
    var metadata = require('./_metadata'),
        anObject = require('./_an-object'),
        toMetaKey = metadata.key,
        getOrCreateMetadataMap = metadata.map,
        store = metadata.store;

    metadata.exp({ deleteMetadata: function deleteMetadata(metadataKey, target /*, targetKey */) {
        var targetKey = arguments.length < 3 ? undefined : toMetaKey(arguments[2]),
            metadataMap = getOrCreateMetadataMap(anObject(target), targetKey, false);
        if (metadataMap === undefined || !metadataMap['delete'](metadataKey)) return false;
        if (metadataMap.size) return true;
        var targetMetadata = store.get(target);
        targetMetadata['delete'](targetKey);
        return !!targetMetadata.size || store['delete'](target);
      } });
  }, { "./_an-object": 7, "./_metadata": 63 }], 275: [function (require, module, exports) {
    var Set = require('./es6.set'),
        from = require('./_array-from-iterable'),
        metadata = require('./_metadata'),
        anObject = require('./_an-object'),
        getPrototypeOf = require('./_object-gpo'),
        ordinaryOwnMetadataKeys = metadata.keys,
        toMetaKey = metadata.key;

    var ordinaryMetadataKeys = function ordinaryMetadataKeys(O, P) {
      var oKeys = ordinaryOwnMetadataKeys(O, P),
          parent = getPrototypeOf(O);
      if (parent === null) return oKeys;
      var pKeys = ordinaryMetadataKeys(parent, P);
      return pKeys.length ? oKeys.length ? from(new Set(oKeys.concat(pKeys))) : pKeys : oKeys;
    };

    metadata.exp({ getMetadataKeys: function getMetadataKeys(target /*, targetKey */) {
        return ordinaryMetadataKeys(anObject(target), arguments.length < 2 ? undefined : toMetaKey(arguments[1]));
      } });
  }, { "./_an-object": 7, "./_array-from-iterable": 10, "./_metadata": 63, "./_object-gpo": 74, "./es6.set": 220 }], 276: [function (require, module, exports) {
    var metadata = require('./_metadata'),
        anObject = require('./_an-object'),
        getPrototypeOf = require('./_object-gpo'),
        ordinaryHasOwnMetadata = metadata.has,
        ordinaryGetOwnMetadata = metadata.get,
        toMetaKey = metadata.key;

    var ordinaryGetMetadata = function ordinaryGetMetadata(MetadataKey, O, P) {
      var hasOwn = ordinaryHasOwnMetadata(MetadataKey, O, P);
      if (hasOwn) return ordinaryGetOwnMetadata(MetadataKey, O, P);
      var parent = getPrototypeOf(O);
      return parent !== null ? ordinaryGetMetadata(MetadataKey, parent, P) : undefined;
    };

    metadata.exp({ getMetadata: function getMetadata(metadataKey, target /*, targetKey */) {
        return ordinaryGetMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
      } });
  }, { "./_an-object": 7, "./_metadata": 63, "./_object-gpo": 74 }], 277: [function (require, module, exports) {
    var metadata = require('./_metadata'),
        anObject = require('./_an-object'),
        ordinaryOwnMetadataKeys = metadata.keys,
        toMetaKey = metadata.key;

    metadata.exp({ getOwnMetadataKeys: function getOwnMetadataKeys(target /*, targetKey */) {
        return ordinaryOwnMetadataKeys(anObject(target), arguments.length < 2 ? undefined : toMetaKey(arguments[1]));
      } });
  }, { "./_an-object": 7, "./_metadata": 63 }], 278: [function (require, module, exports) {
    var metadata = require('./_metadata'),
        anObject = require('./_an-object'),
        ordinaryGetOwnMetadata = metadata.get,
        toMetaKey = metadata.key;

    metadata.exp({ getOwnMetadata: function getOwnMetadata(metadataKey, target /*, targetKey */) {
        return ordinaryGetOwnMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
      } });
  }, { "./_an-object": 7, "./_metadata": 63 }], 279: [function (require, module, exports) {
    var metadata = require('./_metadata'),
        anObject = require('./_an-object'),
        getPrototypeOf = require('./_object-gpo'),
        ordinaryHasOwnMetadata = metadata.has,
        toMetaKey = metadata.key;

    var ordinaryHasMetadata = function ordinaryHasMetadata(MetadataKey, O, P) {
      var hasOwn = ordinaryHasOwnMetadata(MetadataKey, O, P);
      if (hasOwn) return true;
      var parent = getPrototypeOf(O);
      return parent !== null ? ordinaryHasMetadata(MetadataKey, parent, P) : false;
    };

    metadata.exp({ hasMetadata: function hasMetadata(metadataKey, target /*, targetKey */) {
        return ordinaryHasMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
      } });
  }, { "./_an-object": 7, "./_metadata": 63, "./_object-gpo": 74 }], 280: [function (require, module, exports) {
    var metadata = require('./_metadata'),
        anObject = require('./_an-object'),
        ordinaryHasOwnMetadata = metadata.has,
        toMetaKey = metadata.key;

    metadata.exp({ hasOwnMetadata: function hasOwnMetadata(metadataKey, target /*, targetKey */) {
        return ordinaryHasOwnMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
      } });
  }, { "./_an-object": 7, "./_metadata": 63 }], 281: [function (require, module, exports) {
    var metadata = require('./_metadata'),
        anObject = require('./_an-object'),
        aFunction = require('./_a-function'),
        toMetaKey = metadata.key,
        ordinaryDefineOwnMetadata = metadata.set;

    metadata.exp({ metadata: function metadata(metadataKey, metadataValue) {
        return function decorator(target, targetKey) {
          ordinaryDefineOwnMetadata(metadataKey, metadataValue, (targetKey !== undefined ? anObject : aFunction)(target), toMetaKey(targetKey));
        };
      } });
  }, { "./_a-function": 3, "./_an-object": 7, "./_metadata": 63 }], 282: [function (require, module, exports) {
    // https://github.com/DavidBruant/Map-Set.prototype.toJSON
    var $export = require('./_export');

    $export($export.P + $export.R, 'Set', { toJSON: require('./_collection-to-json')('Set') });
  }, { "./_collection-to-json": 20, "./_export": 32 }], 283: [function (require, module, exports) {
    'use strict';
    // https://github.com/mathiasbynens/String.prototype.at

    var $export = require('./_export'),
        $at = require('./_string-at')(true);

    $export($export.P, 'String', {
      at: function at(pos) {
        return $at(this, pos);
      }
    });
  }, { "./_export": 32, "./_string-at": 97 }], 284: [function (require, module, exports) {
    'use strict';
    // https://tc39.github.io/String.prototype.matchAll/

    var $export = require('./_export'),
        defined = require('./_defined'),
        toLength = require('./_to-length'),
        isRegExp = require('./_is-regexp'),
        getFlags = require('./_flags'),
        RegExpProto = RegExp.prototype;

    var $RegExpStringIterator = function $RegExpStringIterator(regexp, string) {
      this._r = regexp;
      this._s = string;
    };

    require('./_iter-create')($RegExpStringIterator, 'RegExp String', function next() {
      var match = this._r.exec(this._s);
      return { value: match, done: match === null };
    });

    $export($export.P, 'String', {
      matchAll: function matchAll(regexp) {
        defined(this);
        if (!isRegExp(regexp)) throw TypeError(regexp + ' is not a regexp!');
        var S = String(this),
            flags = 'flags' in RegExpProto ? String(regexp.flags) : getFlags.call(regexp),
            rx = new RegExp(regexp.source, ~flags.indexOf('g') ? flags : 'g' + flags);
        rx.lastIndex = toLength(regexp.lastIndex);
        return new $RegExpStringIterator(rx, S);
      }
    });
  }, { "./_defined": 27, "./_export": 32, "./_flags": 36, "./_is-regexp": 50, "./_iter-create": 52, "./_to-length": 108 }], 285: [function (require, module, exports) {
    'use strict';
    // https://github.com/tc39/proposal-string-pad-start-end

    var $export = require('./_export'),
        $pad = require('./_string-pad');

    $export($export.P, 'String', {
      padEnd: function padEnd(maxLength /*, fillString = ' ' */) {
        return $pad(this, maxLength, arguments.length > 1 ? arguments[1] : undefined, false);
      }
    });
  }, { "./_export": 32, "./_string-pad": 100 }], 286: [function (require, module, exports) {
    'use strict';
    // https://github.com/tc39/proposal-string-pad-start-end

    var $export = require('./_export'),
        $pad = require('./_string-pad');

    $export($export.P, 'String', {
      padStart: function padStart(maxLength /*, fillString = ' ' */) {
        return $pad(this, maxLength, arguments.length > 1 ? arguments[1] : undefined, true);
      }
    });
  }, { "./_export": 32, "./_string-pad": 100 }], 287: [function (require, module, exports) {
    'use strict';
    // https://github.com/sebmarkbage/ecmascript-string-left-right-trim

    require('./_string-trim')('trimLeft', function ($trim) {
      return function trimLeft() {
        return $trim(this, 1);
      };
    }, 'trimStart');
  }, { "./_string-trim": 102 }], 288: [function (require, module, exports) {
    'use strict';
    // https://github.com/sebmarkbage/ecmascript-string-left-right-trim

    require('./_string-trim')('trimRight', function ($trim) {
      return function trimRight() {
        return $trim(this, 2);
      };
    }, 'trimEnd');
  }, { "./_string-trim": 102 }], 289: [function (require, module, exports) {
    require('./_wks-define')('asyncIterator');
  }, { "./_wks-define": 115 }], 290: [function (require, module, exports) {
    require('./_wks-define')('observable');
  }, { "./_wks-define": 115 }], 291: [function (require, module, exports) {
    // https://github.com/ljharb/proposal-global
    var $export = require('./_export');

    $export($export.S, 'System', { global: require('./_global') });
  }, { "./_export": 32, "./_global": 38 }], 292: [function (require, module, exports) {
    var $iterators = require('./es6.array.iterator'),
        redefine = require('./_redefine'),
        global = require('./_global'),
        hide = require('./_hide'),
        Iterators = require('./_iterators'),
        wks = require('./_wks'),
        ITERATOR = wks('iterator'),
        TO_STRING_TAG = wks('toStringTag'),
        ArrayValues = Iterators.Array;

    for (var collections = ['NodeList', 'DOMTokenList', 'MediaList', 'StyleSheetList', 'CSSRuleList'], i = 0; i < 5; i++) {
      var NAME = collections[i],
          Collection = global[NAME],
          proto = Collection && Collection.prototype,
          key;
      if (proto) {
        if (!proto[ITERATOR]) hide(proto, ITERATOR, ArrayValues);
        if (!proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
        Iterators[NAME] = ArrayValues;
        for (key in $iterators) {
          if (!proto[key]) redefine(proto, key, $iterators[key], true);
        }
      }
    }
  }, { "./_global": 38, "./_hide": 40, "./_iterators": 56, "./_redefine": 87, "./_wks": 117, "./es6.array.iterator": 130 }], 293: [function (require, module, exports) {
    var $export = require('./_export'),
        $task = require('./_task');
    $export($export.G + $export.B, {
      setImmediate: $task.set,
      clearImmediate: $task.clear
    });
  }, { "./_export": 32, "./_task": 104 }], 294: [function (require, module, exports) {
    // ie9- setTimeout & setInterval additional parameters fix
    var global = require('./_global'),
        $export = require('./_export'),
        invoke = require('./_invoke'),
        partial = require('./_partial'),
        navigator = global.navigator,
        MSIE = !!navigator && /MSIE .\./.test(navigator.userAgent); // <- dirty ie9- check
    var wrap = function wrap(set) {
      return MSIE ? function (fn, time /*, ...args */) {
        return set(invoke(partial, [].slice.call(arguments, 2), typeof fn == 'function' ? fn : Function(fn)), time);
      } : set;
    };
    $export($export.G + $export.B + $export.F * MSIE, {
      setTimeout: wrap(global.setTimeout),
      setInterval: wrap(global.setInterval)
    });
  }, { "./_export": 32, "./_global": 38, "./_invoke": 44, "./_partial": 83 }], 295: [function (require, module, exports) {
    require('./modules/es6.symbol');
    require('./modules/es6.object.create');
    require('./modules/es6.object.define-property');
    require('./modules/es6.object.define-properties');
    require('./modules/es6.object.get-own-property-descriptor');
    require('./modules/es6.object.get-prototype-of');
    require('./modules/es6.object.keys');
    require('./modules/es6.object.get-own-property-names');
    require('./modules/es6.object.freeze');
    require('./modules/es6.object.seal');
    require('./modules/es6.object.prevent-extensions');
    require('./modules/es6.object.is-frozen');
    require('./modules/es6.object.is-sealed');
    require('./modules/es6.object.is-extensible');
    require('./modules/es6.object.assign');
    require('./modules/es6.object.is');
    require('./modules/es6.object.set-prototype-of');
    require('./modules/es6.object.to-string');
    require('./modules/es6.function.bind');
    require('./modules/es6.function.name');
    require('./modules/es6.function.has-instance');
    require('./modules/es6.parse-int');
    require('./modules/es6.parse-float');
    require('./modules/es6.number.constructor');
    require('./modules/es6.number.to-fixed');
    require('./modules/es6.number.to-precision');
    require('./modules/es6.number.epsilon');
    require('./modules/es6.number.is-finite');
    require('./modules/es6.number.is-integer');
    require('./modules/es6.number.is-nan');
    require('./modules/es6.number.is-safe-integer');
    require('./modules/es6.number.max-safe-integer');
    require('./modules/es6.number.min-safe-integer');
    require('./modules/es6.number.parse-float');
    require('./modules/es6.number.parse-int');
    require('./modules/es6.math.acosh');
    require('./modules/es6.math.asinh');
    require('./modules/es6.math.atanh');
    require('./modules/es6.math.cbrt');
    require('./modules/es6.math.clz32');
    require('./modules/es6.math.cosh');
    require('./modules/es6.math.expm1');
    require('./modules/es6.math.fround');
    require('./modules/es6.math.hypot');
    require('./modules/es6.math.imul');
    require('./modules/es6.math.log10');
    require('./modules/es6.math.log1p');
    require('./modules/es6.math.log2');
    require('./modules/es6.math.sign');
    require('./modules/es6.math.sinh');
    require('./modules/es6.math.tanh');
    require('./modules/es6.math.trunc');
    require('./modules/es6.string.from-code-point');
    require('./modules/es6.string.raw');
    require('./modules/es6.string.trim');
    require('./modules/es6.string.iterator');
    require('./modules/es6.string.code-point-at');
    require('./modules/es6.string.ends-with');
    require('./modules/es6.string.includes');
    require('./modules/es6.string.repeat');
    require('./modules/es6.string.starts-with');
    require('./modules/es6.string.anchor');
    require('./modules/es6.string.big');
    require('./modules/es6.string.blink');
    require('./modules/es6.string.bold');
    require('./modules/es6.string.fixed');
    require('./modules/es6.string.fontcolor');
    require('./modules/es6.string.fontsize');
    require('./modules/es6.string.italics');
    require('./modules/es6.string.link');
    require('./modules/es6.string.small');
    require('./modules/es6.string.strike');
    require('./modules/es6.string.sub');
    require('./modules/es6.string.sup');
    require('./modules/es6.date.now');
    require('./modules/es6.date.to-json');
    require('./modules/es6.date.to-iso-string');
    require('./modules/es6.date.to-string');
    require('./modules/es6.date.to-primitive');
    require('./modules/es6.array.is-array');
    require('./modules/es6.array.from');
    require('./modules/es6.array.of');
    require('./modules/es6.array.join');
    require('./modules/es6.array.slice');
    require('./modules/es6.array.sort');
    require('./modules/es6.array.for-each');
    require('./modules/es6.array.map');
    require('./modules/es6.array.filter');
    require('./modules/es6.array.some');
    require('./modules/es6.array.every');
    require('./modules/es6.array.reduce');
    require('./modules/es6.array.reduce-right');
    require('./modules/es6.array.index-of');
    require('./modules/es6.array.last-index-of');
    require('./modules/es6.array.copy-within');
    require('./modules/es6.array.fill');
    require('./modules/es6.array.find');
    require('./modules/es6.array.find-index');
    require('./modules/es6.array.species');
    require('./modules/es6.array.iterator');
    require('./modules/es6.regexp.constructor');
    require('./modules/es6.regexp.to-string');
    require('./modules/es6.regexp.flags');
    require('./modules/es6.regexp.match');
    require('./modules/es6.regexp.replace');
    require('./modules/es6.regexp.search');
    require('./modules/es6.regexp.split');
    require('./modules/es6.promise');
    require('./modules/es6.map');
    require('./modules/es6.set');
    require('./modules/es6.weak-map');
    require('./modules/es6.weak-set');
    require('./modules/es6.typed.array-buffer');
    require('./modules/es6.typed.data-view');
    require('./modules/es6.typed.int8-array');
    require('./modules/es6.typed.uint8-array');
    require('./modules/es6.typed.uint8-clamped-array');
    require('./modules/es6.typed.int16-array');
    require('./modules/es6.typed.uint16-array');
    require('./modules/es6.typed.int32-array');
    require('./modules/es6.typed.uint32-array');
    require('./modules/es6.typed.float32-array');
    require('./modules/es6.typed.float64-array');
    require('./modules/es6.reflect.apply');
    require('./modules/es6.reflect.construct');
    require('./modules/es6.reflect.define-property');
    require('./modules/es6.reflect.delete-property');
    require('./modules/es6.reflect.enumerate');
    require('./modules/es6.reflect.get');
    require('./modules/es6.reflect.get-own-property-descriptor');
    require('./modules/es6.reflect.get-prototype-of');
    require('./modules/es6.reflect.has');
    require('./modules/es6.reflect.is-extensible');
    require('./modules/es6.reflect.own-keys');
    require('./modules/es6.reflect.prevent-extensions');
    require('./modules/es6.reflect.set');
    require('./modules/es6.reflect.set-prototype-of');
    require('./modules/es7.array.includes');
    require('./modules/es7.string.at');
    require('./modules/es7.string.pad-start');
    require('./modules/es7.string.pad-end');
    require('./modules/es7.string.trim-left');
    require('./modules/es7.string.trim-right');
    require('./modules/es7.string.match-all');
    require('./modules/es7.symbol.async-iterator');
    require('./modules/es7.symbol.observable');
    require('./modules/es7.object.get-own-property-descriptors');
    require('./modules/es7.object.values');
    require('./modules/es7.object.entries');
    require('./modules/es7.object.define-getter');
    require('./modules/es7.object.define-setter');
    require('./modules/es7.object.lookup-getter');
    require('./modules/es7.object.lookup-setter');
    require('./modules/es7.map.to-json');
    require('./modules/es7.set.to-json');
    require('./modules/es7.system.global');
    require('./modules/es7.error.is-error');
    require('./modules/es7.math.iaddh');
    require('./modules/es7.math.isubh');
    require('./modules/es7.math.imulh');
    require('./modules/es7.math.umulh');
    require('./modules/es7.reflect.define-metadata');
    require('./modules/es7.reflect.delete-metadata');
    require('./modules/es7.reflect.get-metadata');
    require('./modules/es7.reflect.get-metadata-keys');
    require('./modules/es7.reflect.get-own-metadata');
    require('./modules/es7.reflect.get-own-metadata-keys');
    require('./modules/es7.reflect.has-metadata');
    require('./modules/es7.reflect.has-own-metadata');
    require('./modules/es7.reflect.metadata');
    require('./modules/es7.asap');
    require('./modules/es7.observable');
    require('./modules/web.timers');
    require('./modules/web.immediate');
    require('./modules/web.dom.iterable');
    module.exports = require('./modules/_core');
  }, { "./modules/_core": 23, "./modules/es6.array.copy-within": 120, "./modules/es6.array.every": 121, "./modules/es6.array.fill": 122, "./modules/es6.array.filter": 123, "./modules/es6.array.find": 125, "./modules/es6.array.find-index": 124, "./modules/es6.array.for-each": 126, "./modules/es6.array.from": 127, "./modules/es6.array.index-of": 128, "./modules/es6.array.is-array": 129, "./modules/es6.array.iterator": 130, "./modules/es6.array.join": 131, "./modules/es6.array.last-index-of": 132, "./modules/es6.array.map": 133, "./modules/es6.array.of": 134, "./modules/es6.array.reduce": 136, "./modules/es6.array.reduce-right": 135, "./modules/es6.array.slice": 137, "./modules/es6.array.some": 138, "./modules/es6.array.sort": 139, "./modules/es6.array.species": 140, "./modules/es6.date.now": 141, "./modules/es6.date.to-iso-string": 142, "./modules/es6.date.to-json": 143, "./modules/es6.date.to-primitive": 144, "./modules/es6.date.to-string": 145, "./modules/es6.function.bind": 146, "./modules/es6.function.has-instance": 147, "./modules/es6.function.name": 148, "./modules/es6.map": 149, "./modules/es6.math.acosh": 150, "./modules/es6.math.asinh": 151, "./modules/es6.math.atanh": 152, "./modules/es6.math.cbrt": 153, "./modules/es6.math.clz32": 154, "./modules/es6.math.cosh": 155, "./modules/es6.math.expm1": 156, "./modules/es6.math.fround": 157, "./modules/es6.math.hypot": 158, "./modules/es6.math.imul": 159, "./modules/es6.math.log10": 160, "./modules/es6.math.log1p": 161, "./modules/es6.math.log2": 162, "./modules/es6.math.sign": 163, "./modules/es6.math.sinh": 164, "./modules/es6.math.tanh": 165, "./modules/es6.math.trunc": 166, "./modules/es6.number.constructor": 167, "./modules/es6.number.epsilon": 168, "./modules/es6.number.is-finite": 169, "./modules/es6.number.is-integer": 170, "./modules/es6.number.is-nan": 171, "./modules/es6.number.is-safe-integer": 172, "./modules/es6.number.max-safe-integer": 173, "./modules/es6.number.min-safe-integer": 174, "./modules/es6.number.parse-float": 175, "./modules/es6.number.parse-int": 176, "./modules/es6.number.to-fixed": 177, "./modules/es6.number.to-precision": 178, "./modules/es6.object.assign": 179, "./modules/es6.object.create": 180, "./modules/es6.object.define-properties": 181, "./modules/es6.object.define-property": 182, "./modules/es6.object.freeze": 183, "./modules/es6.object.get-own-property-descriptor": 184, "./modules/es6.object.get-own-property-names": 185, "./modules/es6.object.get-prototype-of": 186, "./modules/es6.object.is": 190, "./modules/es6.object.is-extensible": 187, "./modules/es6.object.is-frozen": 188, "./modules/es6.object.is-sealed": 189, "./modules/es6.object.keys": 191, "./modules/es6.object.prevent-extensions": 192, "./modules/es6.object.seal": 193, "./modules/es6.object.set-prototype-of": 194, "./modules/es6.object.to-string": 195, "./modules/es6.parse-float": 196, "./modules/es6.parse-int": 197, "./modules/es6.promise": 198, "./modules/es6.reflect.apply": 199, "./modules/es6.reflect.construct": 200, "./modules/es6.reflect.define-property": 201, "./modules/es6.reflect.delete-property": 202, "./modules/es6.reflect.enumerate": 203, "./modules/es6.reflect.get": 206, "./modules/es6.reflect.get-own-property-descriptor": 204, "./modules/es6.reflect.get-prototype-of": 205, "./modules/es6.reflect.has": 207, "./modules/es6.reflect.is-extensible": 208, "./modules/es6.reflect.own-keys": 209, "./modules/es6.reflect.prevent-extensions": 210, "./modules/es6.reflect.set": 212, "./modules/es6.reflect.set-prototype-of": 211, "./modules/es6.regexp.constructor": 213, "./modules/es6.regexp.flags": 214, "./modules/es6.regexp.match": 215, "./modules/es6.regexp.replace": 216, "./modules/es6.regexp.search": 217, "./modules/es6.regexp.split": 218, "./modules/es6.regexp.to-string": 219, "./modules/es6.set": 220, "./modules/es6.string.anchor": 221, "./modules/es6.string.big": 222, "./modules/es6.string.blink": 223, "./modules/es6.string.bold": 224, "./modules/es6.string.code-point-at": 225, "./modules/es6.string.ends-with": 226, "./modules/es6.string.fixed": 227, "./modules/es6.string.fontcolor": 228, "./modules/es6.string.fontsize": 229, "./modules/es6.string.from-code-point": 230, "./modules/es6.string.includes": 231, "./modules/es6.string.italics": 232, "./modules/es6.string.iterator": 233, "./modules/es6.string.link": 234, "./modules/es6.string.raw": 235, "./modules/es6.string.repeat": 236, "./modules/es6.string.small": 237, "./modules/es6.string.starts-with": 238, "./modules/es6.string.strike": 239, "./modules/es6.string.sub": 240, "./modules/es6.string.sup": 241, "./modules/es6.string.trim": 242, "./modules/es6.symbol": 243, "./modules/es6.typed.array-buffer": 244, "./modules/es6.typed.data-view": 245, "./modules/es6.typed.float32-array": 246, "./modules/es6.typed.float64-array": 247, "./modules/es6.typed.int16-array": 248, "./modules/es6.typed.int32-array": 249, "./modules/es6.typed.int8-array": 250, "./modules/es6.typed.uint16-array": 251, "./modules/es6.typed.uint32-array": 252, "./modules/es6.typed.uint8-array": 253, "./modules/es6.typed.uint8-clamped-array": 254, "./modules/es6.weak-map": 255, "./modules/es6.weak-set": 256, "./modules/es7.array.includes": 257, "./modules/es7.asap": 258, "./modules/es7.error.is-error": 259, "./modules/es7.map.to-json": 260, "./modules/es7.math.iaddh": 261, "./modules/es7.math.imulh": 262, "./modules/es7.math.isubh": 263, "./modules/es7.math.umulh": 264, "./modules/es7.object.define-getter": 265, "./modules/es7.object.define-setter": 266, "./modules/es7.object.entries": 267, "./modules/es7.object.get-own-property-descriptors": 268, "./modules/es7.object.lookup-getter": 269, "./modules/es7.object.lookup-setter": 270, "./modules/es7.object.values": 271, "./modules/es7.observable": 272, "./modules/es7.reflect.define-metadata": 273, "./modules/es7.reflect.delete-metadata": 274, "./modules/es7.reflect.get-metadata": 276, "./modules/es7.reflect.get-metadata-keys": 275, "./modules/es7.reflect.get-own-metadata": 278, "./modules/es7.reflect.get-own-metadata-keys": 277, "./modules/es7.reflect.has-metadata": 279, "./modules/es7.reflect.has-own-metadata": 280, "./modules/es7.reflect.metadata": 281, "./modules/es7.set.to-json": 282, "./modules/es7.string.at": 283, "./modules/es7.string.match-all": 284, "./modules/es7.string.pad-end": 285, "./modules/es7.string.pad-start": 286, "./modules/es7.string.trim-left": 287, "./modules/es7.string.trim-right": 288, "./modules/es7.symbol.async-iterator": 289, "./modules/es7.symbol.observable": 290, "./modules/es7.system.global": 291, "./modules/web.dom.iterable": 292, "./modules/web.immediate": 293, "./modules/web.timers": 294 }], 296: [function (require, module, exports) {
    (function (global) {
      /**
       * Copyright (c) 2014, Facebook, Inc.
       * All rights reserved.
       *
       * This source code is licensed under the BSD-style license found in the
       * https://raw.github.com/facebook/regenerator/master/LICENSE file. An
       * additional grant of patent rights can be found in the PATENTS file in
       * the same directory.
       */

      !function (global) {
        "use strict";

        var Op = Object.prototype;
        var hasOwn = Op.hasOwnProperty;
        var undefined; // More compressible than void 0.
        var $Symbol = typeof Symbol === "function" ? Symbol : {};
        var iteratorSymbol = $Symbol.iterator || "@@iterator";
        var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
        var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

        var inModule = (typeof module === "undefined" ? "undefined" : _typeof(module)) === "object";
        var runtime = global.regeneratorRuntime;
        if (runtime) {
          if (inModule) {
            // If regeneratorRuntime is defined globally and we're in a module,
            // make the exports object identical to regeneratorRuntime.
            module.exports = runtime;
          }
          // Don't bother evaluating the rest of this file if the runtime was
          // already defined globally.
          return;
        }

        // Define the runtime globally (as expected by generated code) as either
        // module.exports (if we're in a module) or a new, empty object.
        runtime = global.regeneratorRuntime = inModule ? module.exports : {};

        function wrap(innerFn, outerFn, self, tryLocsList) {
          // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
          var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
          var generator = Object.create(protoGenerator.prototype);
          var context = new Context(tryLocsList || []);

          // The ._invoke method unifies the implementations of the .next,
          // .throw, and .return methods.
          generator._invoke = makeInvokeMethod(innerFn, self, context);

          return generator;
        }
        runtime.wrap = wrap;

        // Try/catch helper to minimize deoptimizations. Returns a completion
        // record like context.tryEntries[i].completion. This interface could
        // have been (and was previously) designed to take a closure to be
        // invoked without arguments, but in all the cases we care about we
        // already have an existing method we want to call, so there's no need
        // to create a new function object. We can even get away with assuming
        // the method takes exactly one argument, since that happens to be true
        // in every case, so we don't have to touch the arguments object. The
        // only additional allocation required is the completion record, which
        // has a stable shape and so hopefully should be cheap to allocate.
        function tryCatch(fn, obj, arg) {
          try {
            return { type: "normal", arg: fn.call(obj, arg) };
          } catch (err) {
            return { type: "throw", arg: err };
          }
        }

        var GenStateSuspendedStart = "suspendedStart";
        var GenStateSuspendedYield = "suspendedYield";
        var GenStateExecuting = "executing";
        var GenStateCompleted = "completed";

        // Returning this object from the innerFn has the same effect as
        // breaking out of the dispatch switch statement.
        var ContinueSentinel = {};

        // Dummy constructor functions that we use as the .constructor and
        // .constructor.prototype properties for functions that return Generator
        // objects. For full spec compliance, you may wish to configure your
        // minifier not to mangle the names of these two functions.
        function Generator() {}
        function GeneratorFunction() {}
        function GeneratorFunctionPrototype() {}

        // This is a polyfill for %IteratorPrototype% for environments that
        // don't natively support it.
        var IteratorPrototype = {};
        IteratorPrototype[iteratorSymbol] = function () {
          return this;
        };

        var getProto = Object.getPrototypeOf;
        var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
        if (NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
          // This environment has a native %IteratorPrototype%; use it instead
          // of the polyfill.
          IteratorPrototype = NativeIteratorPrototype;
        }

        var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
        GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
        GeneratorFunctionPrototype.constructor = GeneratorFunction;
        GeneratorFunctionPrototype[toStringTagSymbol] = GeneratorFunction.displayName = "GeneratorFunction";

        // Helper for defining the .next, .throw, and .return methods of the
        // Iterator interface in terms of a single ._invoke method.
        function defineIteratorMethods(prototype) {
          ["next", "throw", "return"].forEach(function (method) {
            prototype[method] = function (arg) {
              return this._invoke(method, arg);
            };
          });
        }

        runtime.isGeneratorFunction = function (genFun) {
          var ctor = typeof genFun === "function" && genFun.constructor;
          return ctor ? ctor === GeneratorFunction ||
          // For the native GeneratorFunction constructor, the best we can
          // do is to check its .name property.
          (ctor.displayName || ctor.name) === "GeneratorFunction" : false;
        };

        runtime.mark = function (genFun) {
          if (Object.setPrototypeOf) {
            Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
          } else {
            genFun.__proto__ = GeneratorFunctionPrototype;
            if (!(toStringTagSymbol in genFun)) {
              genFun[toStringTagSymbol] = "GeneratorFunction";
            }
          }
          genFun.prototype = Object.create(Gp);
          return genFun;
        };

        // Within the body of any async function, `await x` is transformed to
        // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
        // `hasOwn.call(value, "__await")` to determine if the yielded value is
        // meant to be awaited.
        runtime.awrap = function (arg) {
          return { __await: arg };
        };

        function AsyncIterator(generator) {
          function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if (record.type === "throw") {
              reject(record.arg);
            } else {
              var result = record.arg;
              var value = result.value;
              if (value && (typeof value === "undefined" ? "undefined" : _typeof(value)) === "object" && hasOwn.call(value, "__await")) {
                return Promise.resolve(value.__await).then(function (value) {
                  invoke("next", value, resolve, reject);
                }, function (err) {
                  invoke("throw", err, resolve, reject);
                });
              }

              return Promise.resolve(value).then(function (unwrapped) {
                // When a yielded Promise is resolved, its final value becomes
                // the .value of the Promise<{value,done}> result for the
                // current iteration. If the Promise is rejected, however, the
                // result for this iteration will be rejected with the same
                // reason. Note that rejections of yielded Promises are not
                // thrown back into the generator function, as is the case
                // when an awaited Promise is rejected. This difference in
                // behavior between yield and await is important, because it
                // allows the consumer to decide what to do with the yielded
                // rejection (swallow it and continue, manually .throw it back
                // into the generator, abandon iteration, whatever). With
                // await, by contrast, there is no opportunity to examine the
                // rejection reason outside the generator function, so the
                // only option is to throw it from the await expression, and
                // let the generator function handle the exception.
                result.value = unwrapped;
                resolve(result);
              }, reject);
            }
          }

          if (_typeof(global.process) === "object" && global.process.domain) {
            invoke = global.process.domain.bind(invoke);
          }

          var previousPromise;

          function enqueue(method, arg) {
            function callInvokeWithMethodAndArg() {
              return new Promise(function (resolve, reject) {
                invoke(method, arg, resolve, reject);
              });
            }

            return previousPromise =
            // If enqueue has been called before, then we want to wait until
            // all previous Promises have been resolved before calling invoke,
            // so that results are always delivered in the correct order. If
            // enqueue has not been called before, then it is important to
            // call invoke immediately, without waiting on a callback to fire,
            // so that the async generator function has the opportunity to do
            // any necessary setup in a predictable way. This predictability
            // is why the Promise constructor synchronously invokes its
            // executor callback, and why async functions synchronously
            // execute code before the first await. Since we implement simple
            // async functions in terms of async generators, it is especially
            // important to get this right, even though it requires care.
            previousPromise ? previousPromise.then(callInvokeWithMethodAndArg,
            // Avoid propagating failures to Promises returned by later
            // invocations of the iterator.
            callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
          }

          // Define the unified helper method that is used to implement .next,
          // .throw, and .return (see defineIteratorMethods).
          this._invoke = enqueue;
        }

        defineIteratorMethods(AsyncIterator.prototype);
        AsyncIterator.prototype[asyncIteratorSymbol] = function () {
          return this;
        };
        runtime.AsyncIterator = AsyncIterator;

        // Note that simple async functions are implemented on top of
        // AsyncIterator objects; they just return a Promise for the value of
        // the final result produced by the iterator.
        runtime.async = function (innerFn, outerFn, self, tryLocsList) {
          var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList));

          return runtime.isGeneratorFunction(outerFn) ? iter // If outerFn is a generator, return the full iterator.
          : iter.next().then(function (result) {
            return result.done ? result.value : iter.next();
          });
        };

        function makeInvokeMethod(innerFn, self, context) {
          var state = GenStateSuspendedStart;

          return function invoke(method, arg) {
            if (state === GenStateExecuting) {
              throw new Error("Generator is already running");
            }

            if (state === GenStateCompleted) {
              if (method === "throw") {
                throw arg;
              }

              // Be forgiving, per 25.3.3.3.3 of the spec:
              // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
              return doneResult();
            }

            context.method = method;
            context.arg = arg;

            while (true) {
              var delegate = context.delegate;
              if (delegate) {
                var delegateResult = maybeInvokeDelegate(delegate, context);
                if (delegateResult) {
                  if (delegateResult === ContinueSentinel) continue;
                  return delegateResult;
                }
              }

              if (context.method === "next") {
                // Setting context._sent for legacy support of Babel's
                // function.sent implementation.
                context.sent = context._sent = context.arg;
              } else if (context.method === "throw") {
                if (state === GenStateSuspendedStart) {
                  state = GenStateCompleted;
                  throw context.arg;
                }

                context.dispatchException(context.arg);
              } else if (context.method === "return") {
                context.abrupt("return", context.arg);
              }

              state = GenStateExecuting;

              var record = tryCatch(innerFn, self, context);
              if (record.type === "normal") {
                // If an exception is thrown from innerFn, we leave state ===
                // GenStateExecuting and loop back for another invocation.
                state = context.done ? GenStateCompleted : GenStateSuspendedYield;

                if (record.arg === ContinueSentinel) {
                  continue;
                }

                return {
                  value: record.arg,
                  done: context.done
                };
              } else if (record.type === "throw") {
                state = GenStateCompleted;
                // Dispatch the exception by looping back around to the
                // context.dispatchException(context.arg) call above.
                context.method = "throw";
                context.arg = record.arg;
              }
            }
          };
        }

        // Call delegate.iterator[context.method](context.arg) and handle the
        // result, either by returning a { value, done } result from the
        // delegate iterator, or by modifying context.method and context.arg,
        // setting context.delegate to null, and returning the ContinueSentinel.
        function maybeInvokeDelegate(delegate, context) {
          var method = delegate.iterator[context.method];
          if (method === undefined) {
            // A .throw or .return when the delegate iterator has no .throw
            // method always terminates the yield* loop.
            context.delegate = null;

            if (context.method === "throw") {
              if (delegate.iterator.return) {
                // If the delegate iterator has a return method, give it a
                // chance to clean up.
                context.method = "return";
                context.arg = undefined;
                maybeInvokeDelegate(delegate, context);

                if (context.method === "throw") {
                  // If maybeInvokeDelegate(context) changed context.method from
                  // "return" to "throw", let that override the TypeError below.
                  return ContinueSentinel;
                }
              }

              context.method = "throw";
              context.arg = new TypeError("The iterator does not provide a 'throw' method");
            }

            return ContinueSentinel;
          }

          var record = tryCatch(method, delegate.iterator, context.arg);

          if (record.type === "throw") {
            context.method = "throw";
            context.arg = record.arg;
            context.delegate = null;
            return ContinueSentinel;
          }

          var info = record.arg;

          if (!info) {
            context.method = "throw";
            context.arg = new TypeError("iterator result is not an object");
            context.delegate = null;
            return ContinueSentinel;
          }

          if (info.done) {
            // Assign the result of the finished delegate to the temporary
            // variable specified by delegate.resultName (see delegateYield).
            context[delegate.resultName] = info.value;

            // Resume execution at the desired location (see delegateYield).
            context.next = delegate.nextLoc;

            // If context.method was "throw" but the delegate handled the
            // exception, let the outer generator proceed normally. If
            // context.method was "next", forget context.arg since it has been
            // "consumed" by the delegate iterator. If context.method was
            // "return", allow the original .return call to continue in the
            // outer generator.
            if (context.method !== "return") {
              context.method = "next";
              context.arg = undefined;
            }
          } else {
            // Re-yield the result returned by the delegate method.
            return info;
          }

          // The delegate iterator is finished, so forget it and continue with
          // the outer generator.
          context.delegate = null;
          return ContinueSentinel;
        }

        // Define Generator.prototype.{next,throw,return} in terms of the
        // unified ._invoke helper method.
        defineIteratorMethods(Gp);

        Gp[toStringTagSymbol] = "Generator";

        // A Generator should always return itself as the iterator object when the
        // @@iterator function is called on it. Some browsers' implementations of the
        // iterator prototype chain incorrectly implement this, causing the Generator
        // object to not be returned from this call. This ensures that doesn't happen.
        // See https://github.com/facebook/regenerator/issues/274 for more details.
        Gp[iteratorSymbol] = function () {
          return this;
        };

        Gp.toString = function () {
          return "[object Generator]";
        };

        function pushTryEntry(locs) {
          var entry = { tryLoc: locs[0] };

          if (1 in locs) {
            entry.catchLoc = locs[1];
          }

          if (2 in locs) {
            entry.finallyLoc = locs[2];
            entry.afterLoc = locs[3];
          }

          this.tryEntries.push(entry);
        }

        function resetTryEntry(entry) {
          var record = entry.completion || {};
          record.type = "normal";
          delete record.arg;
          entry.completion = record;
        }

        function Context(tryLocsList) {
          // The root entry object (effectively a try statement without a catch
          // or a finally block) gives us a place to store values thrown from
          // locations where there is no enclosing try statement.
          this.tryEntries = [{ tryLoc: "root" }];
          tryLocsList.forEach(pushTryEntry, this);
          this.reset(true);
        }

        runtime.keys = function (object) {
          var keys = [];
          for (var key in object) {
            keys.push(key);
          }
          keys.reverse();

          // Rather than returning an object with a next method, we keep
          // things simple and return the next function itself.
          return function next() {
            while (keys.length) {
              var key = keys.pop();
              if (key in object) {
                next.value = key;
                next.done = false;
                return next;
              }
            }

            // To avoid creating an additional object, we just hang the .value
            // and .done properties off the next function object itself. This
            // also ensures that the minifier will not anonymize the function.
            next.done = true;
            return next;
          };
        };

        function values(iterable) {
          if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) {
              return iteratorMethod.call(iterable);
            }

            if (typeof iterable.next === "function") {
              return iterable;
            }

            if (!isNaN(iterable.length)) {
              var i = -1,
                  next = function next() {
                while (++i < iterable.length) {
                  if (hasOwn.call(iterable, i)) {
                    next.value = iterable[i];
                    next.done = false;
                    return next;
                  }
                }

                next.value = undefined;
                next.done = true;

                return next;
              };

              return next.next = next;
            }
          }

          // Return an iterator with no values.
          return { next: doneResult };
        }
        runtime.values = values;

        function doneResult() {
          return { value: undefined, done: true };
        }

        Context.prototype = {
          constructor: Context,

          reset: function reset(skipTempReset) {
            this.prev = 0;
            this.next = 0;
            // Resetting context._sent for legacy support of Babel's
            // function.sent implementation.
            this.sent = this._sent = undefined;
            this.done = false;
            this.delegate = null;

            this.method = "next";
            this.arg = undefined;

            this.tryEntries.forEach(resetTryEntry);

            if (!skipTempReset) {
              for (var name in this) {
                // Not sure about the optimal order of these conditions:
                if (name.charAt(0) === "t" && hasOwn.call(this, name) && !isNaN(+name.slice(1))) {
                  this[name] = undefined;
                }
              }
            }
          },

          stop: function stop() {
            this.done = true;

            var rootEntry = this.tryEntries[0];
            var rootRecord = rootEntry.completion;
            if (rootRecord.type === "throw") {
              throw rootRecord.arg;
            }

            return this.rval;
          },

          dispatchException: function dispatchException(exception) {
            if (this.done) {
              throw exception;
            }

            var context = this;
            function handle(loc, caught) {
              record.type = "throw";
              record.arg = exception;
              context.next = loc;

              if (caught) {
                // If the dispatched exception was caught by a catch block,
                // then let that catch block handle the exception normally.
                context.method = "next";
                context.arg = undefined;
              }

              return !!caught;
            }

            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
              var entry = this.tryEntries[i];
              var record = entry.completion;

              if (entry.tryLoc === "root") {
                // Exception thrown outside of any try block that could handle
                // it, so set the completion value of the entire function to
                // throw the exception.
                return handle("end");
              }

              if (entry.tryLoc <= this.prev) {
                var hasCatch = hasOwn.call(entry, "catchLoc");
                var hasFinally = hasOwn.call(entry, "finallyLoc");

                if (hasCatch && hasFinally) {
                  if (this.prev < entry.catchLoc) {
                    return handle(entry.catchLoc, true);
                  } else if (this.prev < entry.finallyLoc) {
                    return handle(entry.finallyLoc);
                  }
                } else if (hasCatch) {
                  if (this.prev < entry.catchLoc) {
                    return handle(entry.catchLoc, true);
                  }
                } else if (hasFinally) {
                  if (this.prev < entry.finallyLoc) {
                    return handle(entry.finallyLoc);
                  }
                } else {
                  throw new Error("try statement without catch or finally");
                }
              }
            }
          },

          abrupt: function abrupt(type, arg) {
            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
              var entry = this.tryEntries[i];
              if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                var finallyEntry = entry;
                break;
              }
            }

            if (finallyEntry && (type === "break" || type === "continue") && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc) {
              // Ignore the finally entry if control is not jumping to a
              // location outside the try/catch block.
              finallyEntry = null;
            }

            var record = finallyEntry ? finallyEntry.completion : {};
            record.type = type;
            record.arg = arg;

            if (finallyEntry) {
              this.method = "next";
              this.next = finallyEntry.finallyLoc;
              return ContinueSentinel;
            }

            return this.complete(record);
          },

          complete: function complete(record, afterLoc) {
            if (record.type === "throw") {
              throw record.arg;
            }

            if (record.type === "break" || record.type === "continue") {
              this.next = record.arg;
            } else if (record.type === "return") {
              this.rval = this.arg = record.arg;
              this.method = "return";
              this.next = "end";
            } else if (record.type === "normal" && afterLoc) {
              this.next = afterLoc;
            }

            return ContinueSentinel;
          },

          finish: function finish(finallyLoc) {
            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
              var entry = this.tryEntries[i];
              if (entry.finallyLoc === finallyLoc) {
                this.complete(entry.completion, entry.afterLoc);
                resetTryEntry(entry);
                return ContinueSentinel;
              }
            }
          },

          "catch": function _catch(tryLoc) {
            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
              var entry = this.tryEntries[i];
              if (entry.tryLoc === tryLoc) {
                var record = entry.completion;
                if (record.type === "throw") {
                  var thrown = record.arg;
                  resetTryEntry(entry);
                }
                return thrown;
              }
            }

            // The context.catch method must only be called with a location
            // argument that corresponds to a known catch block.
            throw new Error("illegal catch attempt");
          },

          delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            this.delegate = {
              iterator: values(iterable),
              resultName: resultName,
              nextLoc: nextLoc
            };

            if (this.method === "next") {
              // Deliberately forget the last sent value so that we don't
              // accidentally pass it on to the delegate.
              this.arg = undefined;
            }

            return ContinueSentinel;
          }
        };
      }(
      // Among the various tricks for obtaining a reference to the global
      // object, this seems to be the most reliable technique that does not
      // use indirect eval (which violates Content Security Policy).
      (typeof global === "undefined" ? "undefined" : _typeof(global)) === "object" ? global : (typeof window === "undefined" ? "undefined" : _typeof(window)) === "object" ? window : (typeof self === "undefined" ? "undefined" : _typeof(self)) === "object" ? self : this);
    }).call(this, typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {});
  }, {}], 297: [function (require, module, exports) {
    'use strict';

    require('babel-polyfill');

    var _primo = require('./primo');

    var _primo2 = _interopRequireDefault(_primo);

    var _helper = require('./primo/explore/helper');

    var _helper2 = _interopRequireDefault(_helper);

    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }

    window.Primo = _primo2.default;

    window.setTimeout(function () {
      if (_primo2.default.isDebugEnabled()) {
        var uiURL = 'https://cdn.rawgit.com/mehmetc/primo-explore-dom-ui/fc0868df/js/custom.js';
        //let uiURL = 'http://127.0.0.1:8000/js/custom.js';

        _helper2.default.loadScript(uiURL).then(function () {
          console.log('Injecting UI');
          _primo2.default.explore.ui.toggle();
        });
      }
    }, 2000);
  }, { "./primo": 298, "./primo/explore/helper": 301, "babel-polyfill": 1 }], 298: [function (require, module, exports) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
      value: true
    });

    var _createClass = function () {
      function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
          var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
        }
      }return function (Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
      };
    }();

    var _explore = require('./primo/explore');

    var _explore2 = _interopRequireDefault(_explore);

    var _records = require('./primo/records');

    var _records2 = _interopRequireDefault(_records);

    var _facets = require('./primo/facets');

    var _facets2 = _interopRequireDefault(_facets);

    var _view = require('./primo/view');

    var _view2 = _interopRequireDefault(_view);

    var _user = require('./primo/user');

    var _user2 = _interopRequireDefault(_user);

    var _helper = require('./primo/explore/helper');

    var _helper2 = _interopRequireDefault(_helper);

    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }

    function _classCallCheck(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }

    /**
     * Primo main entry class
     */
    var Primo = function () {
      function Primo() {
        _classCallCheck(this, Primo);
      }

      _createClass(Primo, null, [{
        key: 'isDebugEnabled',

        /**
         * Check if angular.reloadWithDebugInfo() has ran
         * @return {boolean}
         */
        value: function isDebugEnabled() {
          return _helper2.default.isDebugEnabled();
        }

        /**
         * Did the script ran on a Primo site
         * @return {boolean}
         */

      }, {
        key: 'isPrimoAvailable',
        value: function isPrimoAvailable() {
          return _helper2.default.isPrimoAvailable();
        }

        /**
         * This is a proxy class
         * @return {Explore}
         */

      }, {
        key: 'version',

        /**
         * Return version information
         * @return {string}
         */
        get: function get() {
          var _version = "0.0.9";
          return 'Library:' + _version + ' - Primo:' + window.appConfig['system-configuration'].Primo_Version_Number + ':' + window.appConfig['system-configuration'].Primo_HotFix_Number;
        }
      }, {
        key: 'explore',
        get: function get() {
          return _explore2.default;
        }

        /**
         * Get a pointer to available records
         * @return {Records}
         */

      }, {
        key: 'records',
        get: function get() {
          var _this = this;

          return new Promise(function (resolve, reject) {
            resolve(new _records2.default(_this.explore.components));
          });
          //return new Records(this.explore.components);
        }

        /**
         * Get a pointer to available facets
         * @return {Facets}
         */

      }, {
        key: 'facets',
        get: function get() {
          var _this2 = this;

          return new Promise(function (resolve, reject) {
            resolve(new _facets2.default(_this2.explore.components));
          });
          //return new Facets(this.explore.components);
        }

        /**
         * Get a pointer to view related metadata
         * @return {View}
         */

      }, {
        key: 'view',
        get: function get() {
          return new Promise(function (resolve, reject) {
            resolve(new _view2.default());
          });
          //return new View();
        }

        /**
         * Get a pointer to user related metadata
         * @return {User}
         */

      }, {
        key: 'user',
        get: function get() {
          return new Promise(function (resolve, reject) {
            _helper2.default.userDetailsHTTP().then(function (userDetails) {
              _helper2.default.userFinesHTTP().then(function (userFines) {
                _helper2.default.userLoansHTTP().then(function (userLoans) {
                  resolve(new _user2.default({ details: userDetails, fines: userFines, loans: userLoans }));
                });
              });
            });
          });
        }
      }]);

      return Primo;
    }();

    exports.default = Primo;
  }, { "./primo/explore": 299, "./primo/explore/helper": 301, "./primo/facets": 302, "./primo/records": 303, "./primo/user": 304, "./primo/view": 305 }], 299: [function (require, module, exports) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
      value: true
    });

    var _createClass = function () {
      function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
          var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
        }
      }return function (Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
      };
    }();

    var _components = require('./explore/components');

    var _components2 = _interopRequireDefault(_components);

    var _helper = require('./explore/helper');

    var _helper2 = _interopRequireDefault(_helper);

    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }

    function _classCallCheck(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }

    //this is proxy class
    var Explore = function () {
      function Explore() {
        _classCallCheck(this, Explore);
      }

      _createClass(Explore, null, [{
        key: 'components',
        get: function get() {
          var c = new _components2.default();
          _helper2.default.componentNames.forEach(function (selector) {
            c.add(selector);
          });

          return c;
        }
      }, {
        key: 'ui',
        get: function get() {
          if (this._ui === undefined) {
            console.error('This is a stub function call "angular.reloadWithDebugInfo()" to activate UI');
          }
          return this._ui;
        }
      }, {
        key: 'helper',
        get: function get() {
          return _helper2.default;
        }
      }]);

      return Explore;
    }();

    exports.default = Explore;
  }, { "./explore/components": 300, "./explore/helper": 301 }], 300: [function (require, module, exports) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
      value: true
    });

    var _createClass = function () {
      function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
          var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
        }
      }return function (Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
      };
    }();

    var _helper = require('./helper');

    var _helper2 = _interopRequireDefault(_helper);

    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }

    function _classCallCheck(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }

    var cssSelectorGenerator = new (require('../../vendor/css-selector-generator.js').CssSelectorGenerator)();

    var Component = function () {
      function Component(element) {
        _classCallCheck(this, Component);

        this.element = element;
      }

      _createClass(Component, [{
        key: 'blink',
        value: function blink() {
          _helper2.default.blink(this);
        }
      }, {
        key: 'scope',
        value: function scope() {
          if (_helper2.default.isDebugEnabled()) {
            return angular.element(this.element).scope();
          } else {
            console.error('Please run "angular.reloadWithDebugInfo()" first');
          }
        }
      }, {
        key: 'ctrl',
        value: function ctrl() {
          var c = angular.element(this.element).controller(this.name);
          if (c) {
            return c;
          } else {
            console.log('using alternative method to get controller');
            var scope = this.scope();
            if (scope) {
              var scopeChild = scope.$$childTail;
              if (Object.keys(scope).includes('$ctrl')) {
                return scope.$ctrl;
              } else if (Object.keys(scope).includes('ctrl')) {
                return scope.ctrl;
              } else if (scopeChild && Object.keys(scopeChild).includes('$ctrl')) {
                return scopeChild.$ctrl;
              } else if (scopeChild && Object.keys(scopeChild).includes('ctrl')) {
                return scopeChild.ctrl;
              } else {
                console.error('No $ctrl defined');
              }
            }
          }

          return null;
        }
      }, {
        key: 'cssPath',
        get: function get() {
          return cssSelectorGenerator.getSelector(this.element);
        }
      }, {
        key: 'name',
        get: function get() {
          return this.element.localName;
        }
      }]);

      return Component;
    }();

    var Components = function () {
      function Components() {
        _classCallCheck(this, Components);

        this._components = {};
      }

      _createClass(Components, [{
        key: 'add',
        value: function add(selector) {
          var elements = _helper2.default.querySelectorAll(selector);
          var elementsArray = this._components[selector] || [];

          elements.forEach(function (element) {
            elementsArray.push(new Component(element));
          });

          this._components[selector] = elementsArray;

          return elementsArray;
        }
      }, {
        key: 'get',
        value: function get(selector) {
          return this._components[selector] || null;
        }
      }, {
        key: 'keys',
        value: function keys() {
          return Object.keys(this._components);
        }
      }]);

      return Components;
    }();

    exports.default = Components;
  }, { "../../vendor/css-selector-generator.js": 306, "./helper": 301 }], 301: [function (require, module, exports) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
      value: true
    });

    var _createClass = function () {
      function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
          var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
        }
      }return function (Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
      };
    }();

    function _classCallCheck(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }

    var Helper = function () {
      function Helper() {
        _classCallCheck(this, Helper);
      }

      _createClass(Helper, null, [{
        key: 'isDebugEnabled',
        value: function isDebugEnabled() {
          return window.name === 'NG_ENABLE_DEBUG_INFO!' || typeof angular.element(document.querySelector('prm-logo')).scope() != 'undefined' ? true : false;
        }
      }, {
        key: 'isPrimoAvailable',
        value: function isPrimoAvailable() {
          if ('undefined' !== typeof window.angular) {
            if (document.querySelector('primo-explore') !== null) {
              return true;
            }
          }
          return false;
        }
      }, {
        key: 'querySelectorAll',
        value: function querySelectorAll(selector) {
          return Array.from(document.querySelectorAll(selector));
        }
      }, {
        key: 'injector',
        value: function injector() {
          var c = Primo.explore.components.get('primo-explore');
          if (c && c.length > 0) {
            var primoExplore = angular.element(c[0].element);
            var injector = primoExplore.injector();
            if (injector) {
              return injector;
            }
          }

          return null;
        }
      }, {
        key: 'loadScript',
        value: function loadScript(scriptURL) {
          if (window.angular) {
            var appInjector = angular.injector(['ng', 'angularLoad']);
            if (appInjector) {
              var angularLoad = appInjector.get('angularLoad');
              if (angularLoad) {
                return angularLoad.loadScript(scriptURL);
              }
            }
          }
        }
      }, {
        key: 'rootScope',
        value: function rootScope() {
          var injector = this.injector();
          if (injector) {
            var rootScope = injector.get('$rootScope');
            if (rootScope) {
              return rootScope;
            }
          }

          return null;
        }
      }, {
        key: 'userSessionManagerService',
        value: function userSessionManagerService() {
          var rootScope = this.rootScope();
          if (rootScope) {
            return rootScope.$$childHead.$ctrl.userSessionManagerService;
          }

          return null;
        }
      }, {
        key: 'jwtData',
        value: function jwtData() {
          var uSMS = this.userSessionManagerService();
          if (uSMS) {
            var jwtData = uSMS.jwtUtilService.getDecodedToken() || {};
            return jwtData;
          }
        }
      }, {
        key: 'userDetails',
        value: function userDetails() {
          var _this = this;

          return new Promise(function (resolve, reject) {
            _this.userSessionManagerService().$localForage.getItem('userDetails').then(function (userDetails) {
              return resolve(userDetails);
            });
          });
        }
      }, {
        key: 'userDetailsHTTP',
        value: function userDetailsHTTP() {
          var _this2 = this;

          var viewCode = this.jwtData().viewId || window.appConfig['vid'];
          return new Promise(function (resolve, reject) {
            _this2.http.get('/primo_library/libweb/webservices/rest/v1/usersettings?vid=' + viewCode).then(function (userDetails) {
              return resolve(userDetails.data);
            });
          });
        }
      }, {
        key: 'userFinesHTTP',
        value: function userFinesHTTP() {
          var _this3 = this;

          return new Promise(function (resolve, reject) {
            _this3.http.get('/primo_library/libweb/webservices/rest/v1/myaccount/fines').then(function (userFines) {
              try {
                var data = userFines.data;
                if (data.status == 'ok') {
                  var fines = data.data.fines;
                  resolve(fines.fine);
                } else {
                  console.log('No fines');
                  resolve([]);
                }
              } catch (error) {
                resolve([]);
              }
            });
          });
        }
      }, {
        key: 'userLoansHTTP',
        value: function userLoansHTTP() {
          var _this4 = this;

          return new Promise(function (resolve, reject) {
            _this4.http.get('/primo_library/libweb/webservices/rest/v1/myaccount/loans').then(function (userLoans) {
              try {
                var data = userLoans.data;
                if (data.status == 'ok') {
                  var loans = data.data.loans;
                  resolve(loans.loan);
                } else {
                  console.log('No loans');
                  resolve([]);
                }
              } catch (error) {
                resolve([]);
              }
            });
          });
        }
      }, {
        key: 'blink',
        value: function blink(component) {
          var numberOfBlinks = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 4;

          var intervalId = null;
          var borderElement = null;
          var index = Math.floor(Math.random() * (1000 - 1)) + 1;
          var borderSelector = component.element.cssPath + index + 'Rect';

          var createBorderElement = function createBorderElement() {
            if (component && component.element) {
              var elementRect = component.element.getBoundingClientRect();
              var _borderElement = document.createElement('div');
              var _index = Math.floor(Math.random() * (1000 - 1)) + 1;
              _borderElement.setAttribute('id', borderSelector);
              _borderElement.style.border = '3px solid red';
              _borderElement.style.position = 'absolute';
              _borderElement.style.top = elementRect.top + 'px';
              _borderElement.style.height = elementRect.height + 'px';
              _borderElement.style.width = elementRect.width + 'px';
              _borderElement.style.left = elementRect.left + 'px';
              document.body.appendChild(_borderElement);

              return document.querySelector('#' + borderSelector);
            }

            return null;
          };

          var removeBorderElement = function removeBorderElement() {
            if (borderElement) {
              borderElement.remove();
            }
          };

          var blinkBorderElement = function blinkBorderElement() {
            var numberOfBlinks = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 4;

            window.clearInterval(intervalId);

            if (numberOfBlinks < 0) {
              removeBorderElement();
            } else {
              borderElement.style.display = numberOfBlinks % 2 == 0 ? 'none' : 'block';
              numberOfBlinks--;
              intervalId = window.setInterval(blinkBorderElement, 1000, numberOfBlinks);
            }
          };

          borderElement = createBorderElement();
          blinkBorderElement(numberOfBlinks);
        }
      }, {
        key: 'componentNames',
        get: function get() {
          var tags = Array.from(document.getElementsByTagName('*'));
          var componentNames = [];
          var _iteratorNormalCompletion = true;
          var _didIteratorError = false;
          var _iteratorError = undefined;

          try {
            for (var _iterator = tags[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              var tag = _step.value;

              var tagName = tag.localName;
              if (/^prm-/.test(tagName) || /^primo-/.test(tagName)) {
                if (!componentNames.includes(tagName)) {
                  componentNames.push(tagName);
                }
              }
            }
          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion && _iterator.return) {
                _iterator.return();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }

          componentNames = componentNames.sort().filter(function (e, i, a) {
            return i === a.findIndex(function (e2) {
              return e === e2;
            });
          });
          return componentNames;
        }
      }, {
        key: 'http',
        get: function get() {
          var injector = this.injector();
          if (injector) {
            var h = injector.get('$http');
            if (h) {
              return h;
            }
          }

          return null;
        }
      }]);

      return Helper;
    }();

    exports.default = Helper;
  }, {}], 302: [function (require, module, exports) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
      value: true
    });

    var _createClass = function () {
      function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
          var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
        }
      }return function (Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
      };
    }();

    var _components = require('./explore/components');

    var _components2 = _interopRequireDefault(_components);

    var _helper = require('./explore/helper');

    var _helper2 = _interopRequireDefault(_helper);

    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }

    function _classCallCheck(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }

    var Facets = function () {
      function Facets(components) {
        _classCallCheck(this, Facets);

        return this._facets(components);
      }

      _createClass(Facets, [{
        key: '_facets',
        value: function _facets(components) {
          try {
            if (components) {
              var c = components.get('prm-facet-after');
              if (c && c.length > 0) {
                var ctrl = c[0].ctrl;
                return ctrl.facetService.results;
              }
            }
          } catch (e) {
            console.log('trying to get facets through the rootScope');
            try {
              return _helper2.default.userSessionManagerService().searchStateService.resultObject.facets;
            } catch (e) {
              console.error('unable to retrieve facets');
            }
          }

          return [];
        }
      }]);

      return Facets;
    }();

    exports.default = Facets;
  }, { "./explore/components": 300, "./explore/helper": 301 }], 303: [function (require, module, exports) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
      value: true
    });

    var _createClass = function () {
      function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
          var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
        }
      }return function (Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
      };
    }();

    var _components = require('./explore/components');

    var _components2 = _interopRequireDefault(_components);

    var _helper = require('./explore/helper');

    var _helper2 = _interopRequireDefault(_helper);

    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }

    function _classCallCheck(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }

    var Records = function () {
      function Records(components) {
        _classCallCheck(this, Records);

        return this._items(components);
      }

      _createClass(Records, [{
        key: '_items',
        value: function _items(components) {
          try {
            if (components) {
              var c = components.get('prm-search-result-list-after');
              if (c && c.length > 0) {
                var ctrl = c[0].ctrl();
                if (ctrl) {
                  return ctrl.itemlist;
                }
                throw "try again";
              }
            }
          } catch (e) {
            console.log('trying to get records through the rootScope');
            try {
              return _helper2.default.userSessionManagerService().searchStateService.resultObject.data;
            } catch (e) {
              console.error('unable to retrieve items');
            }
          }

          return [];
        }
      }]);

      return Records;
    }();

    exports.default = Records;
  }, { "./explore/components": 300, "./explore/helper": 301 }], 304: [function (require, module, exports) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
      value: true
    });

    var _createClass = function () {
      function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
          var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
        }
      }return function (Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
      };
    }();

    var _helper = require('./explore/helper');

    var _helper2 = _interopRequireDefault(_helper);

    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }

    function _classCallCheck(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }

    var User = function () {
      function User() {
        var user = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _skelUser;

        _classCallCheck(this, User);

        var uSms = _helper2.default.userSessionManagerService();
        var jwtData = _helper2.default.jwtData();
        var self = this;

        return {
          id: jwtData.user || '',
          email: user.details.email || '',
          name: jwtData.userName || 'Guest',
          display_name: uSms.getUserNameForDisplay(),
          isLoggedIn: function isLoggedIn() {
            return uSms.getUserName().length > 0;
          },
          isOnCampus: function isOnCampus() {
            return jwtData.onCampus == "true" ? true : false;
          },
          fines: user.fines,
          loans: user.loans
        };
      }

      _createClass(User, [{
        key: '_skelUser',
        get: function get() {
          return {
            details: {},
            fines: {},
            loans: {}
          };
        }
      }]);

      return User;
    }();

    exports.default = User;
  }, { "./explore/helper": 301 }], 305: [function (require, module, exports) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
      value: true
    });

    var _helper = require('./explore/helper');

    var _helper2 = _interopRequireDefault(_helper);

    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }

    function _classCallCheck(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }

    var View = function View() {
      _classCallCheck(this, View);

      var uSms = _helper2.default.userSessionManagerService();
      var jwtData = _helper2.default.jwtData();

      return {
        code: jwtData.viewId || window.appConfig['vid'],
        institution: {
          code: jwtData.viewInstitutionCode,
          name: window.appConfig['primo-view']['attributes-map'].institution
        },
        interfaceLanguage: uSms.getUserLanguage() || window.appConfig['primo-view']['attributes-map'].interfaceLanguage,
        ip: {
          address: jwtData.ip
        }
      };
    };

    exports.default = View;
  }, { "./explore/helper": 301 }], 306: [function (require, module, exports) {
    'use strict';

    (function () {
      var CssSelectorGenerator,
          root,
          indexOf = [].indexOf || function (item) {
        for (var i = 0, l = this.length; i < l; i++) {
          if (i in this && this[i] === item) return i;
        }return -1;
      };

      CssSelectorGenerator = function () {
        CssSelectorGenerator.prototype.default_options = {
          selectors: ['id', 'class', 'tag', 'nthchild']
        };

        function CssSelectorGenerator(options) {
          if (options == null) {
            options = {};
          }
          this.options = {};
          this.setOptions(this.default_options);
          this.setOptions(options);
        }

        CssSelectorGenerator.prototype.setOptions = function (options) {
          var key, results, val;
          if (options == null) {
            options = {};
          }
          results = [];
          for (key in options) {
            val = options[key];
            if (this.default_options.hasOwnProperty(key)) {
              results.push(this.options[key] = val);
            } else {
              results.push(void 0);
            }
          }
          return results;
        };

        CssSelectorGenerator.prototype.isElement = function (element) {
          return !!((element != null ? element.nodeType : void 0) === 1);
        };

        CssSelectorGenerator.prototype.getParents = function (element) {
          var current_element, result;
          result = [];
          if (this.isElement(element)) {
            current_element = element;
            while (this.isElement(current_element)) {
              result.push(current_element);
              current_element = current_element.parentNode;
            }
          }
          return result;
        };

        CssSelectorGenerator.prototype.getTagSelector = function (element) {
          return this.sanitizeItem(element.tagName.toLowerCase());
        };

        CssSelectorGenerator.prototype.sanitizeItem = function (item) {
          var characters;
          characters = item.split('').map(function (character) {
            if (character === ':') {
              return "\\" + ':'.charCodeAt(0).toString(16).toUpperCase() + " ";
            } else if (/[ !"#$%&'()*+,.\/;<=>?@\[\\\]^`{|}~]/.test(character)) {
              return "\\" + character;
            } else {
              return escape(character).replace(/\%/g, '\\');
            }
          });
          return characters.join('');
        };

        CssSelectorGenerator.prototype.getIdSelector = function (element) {
          var id, sanitized_id;
          id = element.getAttribute('id');
          if (id != null && id !== '' && !/\s/.exec(id) && !/^\d/.exec(id)) {
            sanitized_id = "#" + this.sanitizeItem(id);
            if (element.ownerDocument.querySelectorAll(sanitized_id).length === 1) {
              return sanitized_id;
            }
          }
          return null;
        };

        CssSelectorGenerator.prototype.getClassSelectors = function (element) {
          var class_string, item, result;
          result = [];
          class_string = element.getAttribute('class');
          if (class_string != null) {
            class_string = class_string.replace(/\s+/g, ' ');
            class_string = class_string.replace(/^\s|\s$/g, '');
            if (class_string !== '') {
              result = function () {
                var k, len, ref, results;
                ref = class_string.split(/\s+/);
                results = [];
                for (k = 0, len = ref.length; k < len; k++) {
                  item = ref[k];
                  results.push("." + this.sanitizeItem(item));
                }
                return results;
              }.call(this);
            }
          }
          return result;
        };

        CssSelectorGenerator.prototype.getAttributeSelectors = function (element) {
          var attribute, blacklist, k, len, ref, ref1, result;
          result = [];
          blacklist = ['id', 'class'];
          ref = element.attributes;
          for (k = 0, len = ref.length; k < len; k++) {
            attribute = ref[k];
            if (ref1 = attribute.nodeName, indexOf.call(blacklist, ref1) < 0) {
              result.push("[" + attribute.nodeName + "=" + attribute.nodeValue + "]");
            }
          }
          return result;
        };

        CssSelectorGenerator.prototype.getNthChildSelector = function (element) {
          var counter, k, len, parent_element, sibling, siblings;
          parent_element = element.parentNode;
          if (parent_element != null) {
            counter = 0;
            siblings = parent_element.childNodes;
            for (k = 0, len = siblings.length; k < len; k++) {
              sibling = siblings[k];
              if (this.isElement(sibling)) {
                counter++;
                if (sibling === element) {
                  return ":nth-child(" + counter + ")";
                }
              }
            }
          }
          return null;
        };

        CssSelectorGenerator.prototype.testSelector = function (element, selector) {
          var is_unique, result;
          is_unique = false;
          if (selector != null && selector !== '') {
            result = element.ownerDocument.querySelectorAll(selector);
            if (result.length === 1 && result[0] === element) {
              is_unique = true;
            }
          }
          return is_unique;
        };

        CssSelectorGenerator.prototype.getAllSelectors = function (element) {
          var result;
          result = {
            t: null,
            i: null,
            c: null,
            a: null,
            n: null
          };
          if (indexOf.call(this.options.selectors, 'tag') >= 0) {
            result.t = this.getTagSelector(element);
          }
          if (indexOf.call(this.options.selectors, 'id') >= 0) {
            result.i = this.getIdSelector(element);
          }
          if (indexOf.call(this.options.selectors, 'class') >= 0) {
            result.c = this.getClassSelectors(element);
          }
          if (indexOf.call(this.options.selectors, 'attribute') >= 0) {
            result.a = this.getAttributeSelectors(element);
          }
          if (indexOf.call(this.options.selectors, 'nthchild') >= 0) {
            result.n = this.getNthChildSelector(element);
          }
          return result;
        };

        CssSelectorGenerator.prototype.testUniqueness = function (element, selector) {
          var found_elements, parent;
          parent = element.parentNode;
          found_elements = parent.querySelectorAll(selector);
          return found_elements.length === 1 && found_elements[0] === element;
        };

        CssSelectorGenerator.prototype.testCombinations = function (element, items, tag) {
          var item, k, l, len, len1, ref, ref1;
          ref = this.getCombinations(items);
          for (k = 0, len = ref.length; k < len; k++) {
            item = ref[k];
            if (this.testUniqueness(element, item)) {
              return item;
            }
          }
          if (tag != null) {
            ref1 = items.map(function (item) {
              return tag + item;
            });
            for (l = 0, len1 = ref1.length; l < len1; l++) {
              item = ref1[l];
              if (this.testUniqueness(element, item)) {
                return item;
              }
            }
          }
          return null;
        };

        CssSelectorGenerator.prototype.getUniqueSelector = function (element) {
          var found_selector, k, len, ref, selector_type, selectors;
          selectors = this.getAllSelectors(element);
          ref = this.options.selectors;
          for (k = 0, len = ref.length; k < len; k++) {
            selector_type = ref[k];
            switch (selector_type) {
              case 'id':
                if (selectors.i != null) {
                  return selectors.i;
                }
                break;
              case 'tag':
                if (selectors.t != null) {
                  if (this.testUniqueness(element, selectors.t)) {
                    return selectors.t;
                  }
                }
                break;
              case 'class':
                if (selectors.c != null && selectors.c.length !== 0) {
                  found_selector = this.testCombinations(element, selectors.c, selectors.t);
                  if (found_selector) {
                    return found_selector;
                  }
                }
                break;
              case 'attribute':
                if (selectors.a != null && selectors.a.length !== 0) {
                  found_selector = this.testCombinations(element, selectors.a, selectors.t);
                  if (found_selector) {
                    return found_selector;
                  }
                }
                break;
              case 'nthchild':
                if (selectors.n != null) {
                  return selectors.n;
                }
            }
          }
          return '*';
        };

        CssSelectorGenerator.prototype.getSelector = function (element) {
          var all_selectors, item, k, l, len, len1, parents, result, selector, selectors;
          all_selectors = [];
          parents = this.getParents(element);
          for (k = 0, len = parents.length; k < len; k++) {
            item = parents[k];
            selector = this.getUniqueSelector(item);
            if (selector != null) {
              all_selectors.push(selector);
            }
          }
          selectors = [];
          for (l = 0, len1 = all_selectors.length; l < len1; l++) {
            item = all_selectors[l];
            selectors.unshift(item);
            result = selectors.join(' > ');
            if (this.testSelector(element, result)) {
              return result;
            }
          }
          return null;
        };

        CssSelectorGenerator.prototype.getCombinations = function (items) {
          var i, j, k, l, ref, ref1, result;
          if (items == null) {
            items = [];
          }
          result = [[]];
          for (i = k = 0, ref = items.length - 1; 0 <= ref ? k <= ref : k >= ref; i = 0 <= ref ? ++k : --k) {
            for (j = l = 0, ref1 = result.length - 1; 0 <= ref1 ? l <= ref1 : l >= ref1; j = 0 <= ref1 ? ++l : --l) {
              result.push(result[j].concat(items[i]));
            }
          }
          result.shift();
          result = result.sort(function (a, b) {
            return a.length - b.length;
          });
          result = result.map(function (item) {
            return item.join('');
          });
          return result;
        };

        return CssSelectorGenerator;
      }();

      if (typeof define !== "undefined" && define !== null ? define.amd : void 0) {
        define([], function () {
          return CssSelectorGenerator;
        });
      } else {
        root = typeof exports !== "undefined" && exports !== null ? exports : this;
        root.CssSelectorGenerator = CssSelectorGenerator;
      }
    }).call(undefined);
  }, {}] }, {}, [297]);

angular.module('myILL', []).component('prmLoansOverviewAfter', {
  bindings: { parentCtrl: '<' },
  controller: function controller($scope, $element, $q, $http, illService, illiadOptions) {
    var whitelistGroups = illiadOptions.groups;
    $scope.illBox = false;
    this.$onInit = function () {
      /* from: https://github.com/mehmetc/primo-explore-dom/blob/master/js/primo/explore/helper.js */
      var rootScope = $scope.$root;
      var uSMS = rootScope.$$childHead.$ctrl.userSessionManagerService;
      var jwtData = uSMS.jwtUtilService.getDecodedToken();
      console.log(jwtData);
      var userGroup = parseInt(jwtData.userGroup);
      var user = jwtData.user;
      var check = whitelistGroups.indexOf(userGroup);
      if (check >= 0) {
        $scope.illBox = true;
        $scope.showGlobe = true;
        $scope.boxTitle = illiadOptions.boxTitle;
        $scope.illiadURL = illiadOptions.illiadURL;
        console.log($scope.boxTitle);
        var url = illiadOptions.remoteScript;
        var response = illService.getILLiadData(url, user).then(function (response) {
          console.log(response);
          $scope.articles = response.data.Articles;
          $scope.requests = response.data.Requests;
          if ($scope.requests || $scope.articles) {
            $scope.showGlobe = false;
          }
        });
      }
    };
  },
  template: "<div class=tiles-grid-tile ng-show={{illBox}}>\n              <div class=\"layout-column tile-content\"layout=column>\n                <div class=\"layout-column tile-header\"layout=column>\n                  <div class=\"layout-align-space-between-stretch layout-row\"layout=row layout-align=space-between>\n                    <h2 class=\"header-link light-text\"role=button tabindex=0>\n                      <span>{{boxTitle}}</span>\n                    </h2>\n                  </div>\n                </div>\n                <md-list class=\"layout-column md-primoExplore-theme\"layout=column role=list>\n                </md-list>\n                <div class=\"layout-column layout-align-center-center layout-margin layout-padding message-with-icon\"layout=column layout-align=\"center center\"layout-margin=\"\"layout-padding=\"\">\n                  <img ng-if=\"showGlobe\" src=\"custom/LCC/img/globe.png\">\n                  <div>\n                    <p style='font-size: 18px;font-weight: 400;'>Pending Requests</p>\n                    <illrequest ng-if=\"requests\" ng-repeat=\"y in requests\" item=\"y\"></illrequest>\n                    <div ng-if=\"!requests\">You have no requests.</div>\n                      <div style=\"text-align:center;\">----</div>\n                    <p style='font-size: 18px;font-weight: 400;''>My Articles</p>\n                    <illarticle ng-if=\"articles\" ng-repeat=\"x in articles\" item=\"x\"></illarticle>\n                    <div ng-if=\"!articles\">You have no articles.</div>\n                    <div style=\"text-align:center;\">----</div>\n                    <span>\n                      <a href=\"{{illiadURL}}\" target=\"_blank\">Log into your ILL account</a>\n                       for more information and to place requests.\n                      </span>\n                    </div>\n                  </div>\n                </div>\n              </div>"
}).component('illarticle', {
  bindings: { item: '<' },
  controller: function controller($scope) {

    console.log(this.item);
    //console.log(this.item.index);

    $scope.url = this.item.url;
    $scope.title = this.item.title;
    $scope.item = this.item;
    $scope.jtitle = this.item.jtitle;
    $scope.author = this.item.author;
    $scope.count = this.item.count;
    $scope.expires = this.item.expires;
  },
  template: "<div class='md-list-item-inner' style='padding-bottom:10px;'>\n              <div class='md-list-item-text'>\n                <p style='font-size: 16px;font-weight: 400;letter-spacing: .01em;margin: 0;line-height: 1.2em;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;'><a href='{{url}}' target='_blank'>{{title}}</a></p>\n                <p style='font-size: 14px;letter-spacing: .01em;margin: 3px 0 1px;font-weight: 400;line-height: 1.2em;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;'>{{author}}</p>\n                <p style='font-size: 14px;letter-spacing: .01em;margin: 3px 0 1px;font-weight: 400;line-height: 1.2em;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;'>Expires {{expires}}.</p>\n              </div>\n            </div>"

}).component('illrequest', {
  bindings: { item: '<' },
  controller: function controller($scope) {
    $scope.title = this.item.title;
    $scope.author = this.item.author;
    $scope.count = this.item.count;
  },
  //template:"<p>{{count}}) {{title}}/ {{author}}. </p>"
  template: "<div class='md-list-item-inner' style='padding-bottom:10px;'>\n              <div class='md-list-item-text'>\n                <p style='font-size: 16px;font-weight: 400;letter-spacing: .01em;margin: 0;line-height: 1.2em;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;'>{{title}}</p>\n                <p style='font-size: 14px;letter-spacing: .01em;margin: 3px 0 1px;font-weight: 400;line-height: 1.2em;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;'>{{author}}</p>\n              </div>\n            </div>"
}).factory('illService', ['$http', function ($http) {
  return {
    getILLiadData: function getILLiadData(url, user) {
      return $http({
        method: 'GET',
        url: url,
        params: { 'user': user },
        cache: true
      });
    }
  };
}]);

'use strict';

angular.module('customActions', []);

/* eslint-disable max-len */
angular.module('customActions').component('customAction', {
  bindings: {
    name: '@',
    label: '@',
    icon: '@',
    iconSet: '@',
    link: '@',
    index: '<'
  },
  require: {
    prmActionCtrl: '^prmActionList'
  },
  controller: ['customActions', function (customActions) {
    var _this = this;

    this.$onInit = function () {
      _this.action = {
        name: _this.name,
        label: _this.label,
        index: _this.index,
        icon: {
          icon: _this.icon,
          iconSet: _this.iconSet,
          type: 'svg'
        },
        onToggle: customActions.processLinkTemplate(_this.link, _this.prmActionCtrl.item)
      };
      customActions.addAction(_this.action, _this.prmActionCtrl);
    };
    this.$onDestroy = function () {
      return customActions.removeAction(_this.action, _this.prmActionCtrl);
    };
  }]
});

/* eslint-disable max-len */
angular.module('customActions').factory('customActions', function () {
  return {
    /**
     * Adds an action to the actions menu, including its icon.
     * @param  {object} action  action object
     * @param  {object} ctrl    instance of prmActionCtrl
     */
    // TODO coerce action.index to be <= requiredActionsList.length
    addAction: function addAction(action, ctrl) {
      if (!this.actionExists(action, ctrl)) {
        this.addActionIcon(action, ctrl);
        ctrl.actionListService.requiredActionsList.splice(action.index, 0, action.name);
        ctrl.actionListService.actionsToIndex[action.name] = action.index;
        ctrl.actionListService.onToggle[action.name] = action.onToggle;
        ctrl.actionListService.actionsToDisplay.unshift(action.name);
      }
    },
    /**
     * Removes an action from the actions menu, including its icon.
     * @param  {object} action  action object
     * @param  {object} ctrl    instance of prmActionCtrl
     */
    removeAction: function removeAction(action, ctrl) {
      if (this.actionExists(action, ctrl)) {
        this.removeActionIcon(action, ctrl);
        delete ctrl.actionListService.actionsToIndex[action.name];
        delete ctrl.actionListService.onToggle[action.name];
        var i = ctrl.actionListService.actionsToDisplay.indexOf(action.name);
        ctrl.actionListService.actionsToDisplay.splice(i, 1);
        i = ctrl.actionListService.requiredActionsList.indexOf(action.name);
        ctrl.actionListService.requiredActionsList.splice(i, 1);
      }
    },
    /**
     * Registers an action's icon.
     * Called internally by addAction().
     * @param  {object} action  action object
     * @param  {object} ctrl    instance of prmActionCtrl
     */
    addActionIcon: function addActionIcon(action, ctrl) {
      ctrl.actionLabelNamesMap[action.name] = action.label;
      ctrl.actionIconNamesMap[action.name] = action.name;
      ctrl.actionIcons[action.name] = action.icon;
    },
    /**
     * Deregisters an action's icon.
     * Called internally by removeAction().
     * @param  {object} action  action object
     * @param  {object} ctrl    instance of prmActionCtrl
     */
    removeActionIcon: function removeActionIcon(action, ctrl) {
      delete ctrl.actionLabelNamesMap[action.name];
      delete ctrl.actionIconNamesMap[action.name];
      delete ctrl.actionIcons[action.name];
    },
    /**
     * Check if an action exists.
     * Returns true if action is part of actionsToIndex.
     * @param  {object} action  action object
     * @param  {object} ctrl    instance of prmActionCtrl
     * @return {bool}
     */
    actionExists: function actionExists(action, ctrl) {
      return ctrl.actionListService.actionsToIndex.hasOwnProperty(action.name);
    },
    /**
     * Process a link into a function to call when the action is clicked.
     * The function will open the processed link in a new tab.
     * Will replace {pnx.xxx.xxx} expressions with properties from the item.
     * @param  {string}    link    the original link string from the html
     * @param  {object}    item    the item object obtained from the controller
     * @return {function}          function to call when the action is clicked
     */
    processLinkTemplate: function processLinkTemplate(link, item) {
      var processedLink = link;
      var pnxProperties = link.match(/\{(pnx\..*?)\}/g) || [];
      pnxProperties.forEach(function (property) {
        var value = property.replace(/[{}]/g, '').split('.').reduce(function (o, i) {
          try {
            var h = /(.*)(\[\d\])/.exec(i);
            if (h instanceof Array) {
              return o[h[1]][h[2].replace(/[^\d]/g, '')];
            }
            return o[i];
          } catch (e) {
            return '';
          }
        }, item);
        processedLink = processedLink.replace(property, value);
      });
      return function () {
        return window.open(processedLink, '_blank');
      };
    }
  };
});
'use strict';

angular.module('sendSms', ['ngMaterial', 'primo-explore.components', 'customActions']);

/* eslint-disable max-len */
angular.module('sendSms').component('ocaSendSms', {
  bindings: {
    item: '<',
    finishedSmsEvent: '&'
  },
  template: '\n  <div class="send-actions-content-item" layout="row">\n      <md-content layout-wrap layout-padding layout-fill>\n          <form name="smsForm" novalidate layout="column" layout-align="center center" (submit)="$ctrl.sendSms($event);">\n              <div layout="row" class="layout-full-width" layout-align="center center">\n                  <div flex="20" flex-sm="10" hide-xs></div>\n                  <div class="form-focus service-form" layout-padding flex>\n                      <div layout-margin>\n                          <div layout="column">\n                              <h4 class="md-subhead">Standard message and data rates may apply.</h4>\n                              <md-input-container class="underlined-input md-required"><label>Phone number:</label>\n                                  <input ng-model="$ctrl.phoneNumber" name="phoneNumber" type="text" required ng-pattern="::$ctrl.telRegEx">\n                                  <div ng-messages="smsForm.phoneNumber.$error">\n                                      <div ng-message="pattern, required ">phone number is invalid</div>\n                                  </div>\n                              </md-input-container>\n                              <md-input-container class="md-required"><label>Carrier:</label>\n                                <md-select ng-model="$ctrl.carrier" name="carrier" placeholder="Select a carrier" required>\n                                  <md-option ng-repeat="(carrier, address) in carriers" value="{{ address }}">\n                                    {{ carrier }}\n                                  </md-option>\n                                </md-select>\n                                <div ng-messages="smsForm.carrier.$error">\n                                    <div ng-message="required">please select a carrier</div>\n                                </div>\n                              </md-input-container>\n                              <md-input-container class="underlined-input" ng-if="$ctrl.isCaptcha">\n                                  <div vc-recaptcha key="$ctrl.getCaptchaPublicKey()" on-success="$ctrl.setResponse(response)"></div>\n                                  <span class="recaptcha-error-info" ng-show="smsForm.$submitted && (smsForm.recaptchaResponse.$invalid || smsForm.$error.recaptcha.length)">\n                                    <span translate="captcha.notselected"></span>\n                                  </span>\n                              </md-input-container>\n                          </div>\n                      </div>\n                  </div>\n                  <div flex="20" flex-sm="10" hide-xs></div>\n              </div>\n              <div layout="row">\n                  <div layout="row" layout-align="center" layout-fill>\n                      <md-button type="submit" class="button-with-icon button-large button-confirm" aria-label="Send the result by SMS">\n                          <prm-icon icon-type="svg" svg-icon-set="primo-ui" icon-definition="send"></prm-icon><span translate="email.popup.link.send"></span></md-button>\n                  </div>\n              </div>\n          </form>\n      </md-content>\n  </div>\n  <prm-send-email ng-hide="true"></prm-send-email>\n  <oca-send-sms-after parent-ctrl="$ctrl"></oca-send-sms-after>',
  controller: ['$scope', 'smsOptions', function ($scope, smsOptions) {
    var _this = this;

    this.$onInit = function () {
      $scope.$watch('$$childTail.$ctrl', function (ctrl) {
        return _this.sendEmailService = ctrl.sendEmailService;
      });
      $scope.carriers = smsOptions.smsCarriers;
      _this.carrier = _this.phoneNumber = '';
      _this.telRegEx = /^\d{3}( |-)?\d{3}( |-)?\d{4}$/;
    };
    this.validate = function () {
      return _this.telRegEx.test(_this.phoneNumber) && _this.carrier;
    };
    this.isCaptcha = function () {
      return window.appConfig['system-configuration']['Activate Captcha [Y/N]'] == 'Y';
    };
    this.getCaptchaPublicKey = function () {
      return window.appConfig['system-configuration']['Public Captcha Key'];
    };
    this.setResponse = function (response) {
      return _this.gCaptchaResponse = response;
    };
    this.sendSms = function () {
      if (_this.validate()) {
        _this.sendEmailService.sendEmail([_this.phoneNumber + '@' + _this.carrier], // addresses
        '', // subject
        '', // note
        [_this.item], // items
        _this.gCaptchaResponse // captcha
        ).then(function (msg) {
          return console.log('sms successfully sent', msg);
        }).catch(function (err) {
          return console.error('sms sending failed', err);
        }).finally(function () {
          return _this.finishedSmsEvent();
        });
      }
    };
  }]
}).run(['$templateCache', 'smsOptions', function ($templateCache, smsOptions) {
  $templateCache.put('components/search/actions/actionContainer/action-container.html', '\n  <oca-send-sms ng-if="($ctrl.actionName===\'' + smsOptions.smsAction.name + '\')" finished-sms-event="$ctrl.throwCloseTabsEvent()" item="::$ctrl.item"></oca-send-sms>\n  <prm-send-email ng-if="($ctrl.actionName===\'E-mail\')" (finished-email-event)="$ctrl.throwCloseTabsEvent()" [item]="::$ctrl.item" [toggleform]="::$ctrl.toggleActionCotent" [user]="::\'\'"></prm-send-email>\n  <prm-citation ng-if="($ctrl.actionName===\'Citation\')" [item]="::$ctrl.item" [on-toggle]="::$ctrl.onToggle"></prm-citation>\n  <prm-permalink ng-if="($ctrl.actionName===\'Permalink\')" [item]="::$ctrl.item" [on-toggle]="::$ctrl.onToggle"></prm-permalink>\n  <prm-print-item ng-if="($ctrl.actionName===\'Print\')" (close-tabs-event)="$ctrl.throwCloseTabsEvent()" [item]="::$ctrl.item" [on-toggle]="::$ctrl.onToggle"></prm-print-item>\n  <prm-endnote ng-if="($ctrl.actionName===\'EndNote\')" (close-tabs-event)="$ctrl.throwCloseTabsEvent()" [item]="::$ctrl.item" [on-toggle]="::$ctrl.onToggle"></prm-endnote>\n  <prm-easybib ng-if="($ctrl.actionName===\'EasyBib\')" (close-tabs-event)="$ctrl.throwCloseTabsEvent()" [item]="::$ctrl.item" [on-toggle]="::$ctrl.onToggle"></prm-easybib>\n  <prm-refworks ng-if="($ctrl.actionName===\'RefWorks\')" (close-tabs-event)="$ctrl.throwCloseTabsEvent()" [item]="::$ctrl.item" [on-toggle]="::$ctrl.onToggle"></prm-refworks>\n  <prm-export-ris ng-if="($ctrl.actionName===\'RISPushTo\')" [item]="::$ctrl.item" [on-toggle]="::$ctrl.onToggle"></prm-export-ris>\n  <prm-action-container-after parent-ctrl="$ctrl"></prm-action-container-after>');
}]);

/* eslint-disable max-len */
angular.module('sendSms').component('smsAction', {
  require: {
    prmActionCtrl: '^prmActionList'
  },
  controller: ['customActions', 'smsOptions', function (customActions, smsOptions) {
    var _this2 = this;

    this.$onInit = function () {
      return customActions.addAction(smsOptions.smsAction, _this2.prmActionCtrl);
    };
    this.$onDestroy = function () {
      return customActions.removeAction(smsOptions.smsAction, _this2.prmActionCtrl);
    };
  }]
});

angular.module('sendSms').value('smsOptions', {
  smsAction: {
    name: 'send_sms',
    label: 'SMS',
    index: 9,
    icon: {
      icon: 'ic_smartphone_24px',
      iconSet: 'hardware',
      type: 'svg'
    }
  },
  smsCarriers: {
    'ATT': 'txt.att.net',
    'T-Mobile': 'tmomail.net',
    'Virgin': 'vmobl.com',
    'Sprint': 'messaging.sprintpcs.com',
    'Nextel': 'messaging.nextel.com',
    'Verizon': 'vtext.com',
    'Cricket': 'mms.mycricket.com',
    'Qwest': 'qwestmp.com',
    'Project Fi': 'msg.fi.google.com'
  }
});
})();